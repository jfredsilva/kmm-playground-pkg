#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SharedKitCommon_dto_mediaPendingMediaResourceCreateDto, SharedKitChatMessageCreateDtoCompanion, SharedKitChatMessageCreateDto, SharedKitKotlinEnumCompanion, SharedKitKotlinEnum<E>, SharedKitChatMessageStatus, SharedKitKotlinArray<T>, SharedKitCommon_dto_mediaMediaResourceViewDto, SharedKitKotlinx_datetimeInstant, SharedKitChatMessageViewDtoCompanion, SharedKitChatMessageViewDto, SharedKitChatPresenceCheckDtoCompanion, SharedKitChatPresenceCheckDto, SharedKitChatRoomType, SharedKitChatRoomBoardItemViewDtoCompanion, SharedKitChatRoomBoardItemViewDto, SharedKitChatRoomSourceType, SharedKitChatRoomCreateDtoCompanion, SharedKitChatRoomCreateDto, SharedKitChatRoomEditAdminDtoCompanion, SharedKitChatRoomEditAdminDto, SharedKitChatRoomEditParticipantDtoCompanion, SharedKitChatRoomEditParticipantDto, SharedKitChatRoomUpdateDtoCompanion, SharedKitChatRoomUpdateDto, SharedKitChatRoomViewDtoCompanion, SharedKitChatRoomViewDto, SharedKitMeetingActionDtoCompanion, SharedKitMeetingActionDto, SharedKitCallStatusType, SharedKitMeetingCallStatusViewDtoCompanion, SharedKitMeetingCallStatusViewDto, SharedKitMeetingCandidateDtoCompanion, SharedKitMeetingCandidateDto, SharedKitWebRtcMessageType, SharedKitMeetingMessageDtoCompanion, SharedKitMeetingMessageDto, SharedKitMeetingSessionDto, SharedKitMeetingPeerStatusViewDtoCompanion, SharedKitMeetingPeerStatusViewDto, SharedKitMeetingSessionDtoCompanion, SharedKitMemberViewDto, SharedKitMeetingType, SharedKitMeetingViewDtoCompanion, SharedKitMeetingViewDto, SharedKitMeetingWithInviteesCreateDtoCompanion, SharedKitMeetingWithInviteesCreateDto, SharedKitMemberType, SharedKitMemberViewDtoCompanion, SharedKitUserChatPresenceStatus, SharedKitUserChatStatusUpdateDtoCompanion, SharedKitUserChatStatusUpdateDto, SharedKitUserChatStatusViewDtoCompanion, SharedKitUserChatStatusViewDto, SharedKitNameValuePairDto, SharedKitMediaVisibility, SharedKitMediaOrientation, SharedKitMediaResourceInternalViewDtoCompanion, SharedKitMediaResourceInternalViewDto, SharedKitAudienceStatus, SharedKitAuthTypeCompanion, SharedKitAuthType, SharedKitClientOSCompanion, SharedKitClientOS, SharedKitErrorCode, SharedKitI18nExportType, SharedKitNotificationResourceType, SharedKitNotificationType, SharedKitNotifyTransportType, SharedKitPrivacyMessageAction, SharedKitPropertyAgent, SharedKitPropertyCategory, SharedKitPropertyFilter, SharedKitPropertyScope, SharedKitPropertyType, SharedKitPushMessageSeverityCompanion, SharedKitPushMessageSeverity, SharedKitPushMessageType, SharedKitRoleCompanion, SharedKitRole, SharedKitSharedEntityType, SharedKitUserClaimScope, SharedKitSocialMediaType, SharedKitTemporalRepetitionType, SharedKitKotlinx_datetimeLocalDate, SharedKitHeaders, SharedKitMediaConstants, SharedKitMediaConstantsSTATUS, SharedKitMediaProcessingStatus, SharedKitUuidUuid, SharedKitValues, SharedKitAlertCompanion, SharedKitAlert, SharedKitApsCompanion, SharedKitAps, SharedKitErrorDtoCompanion, SharedKitErrorDto, SharedKitNameValuePairDtoCompanion, SharedKitPushMessageDtoCompanion, SharedKitPushMessageDto, SharedKitPushMessageMediaDtoCompanion, SharedKitPushMessageMediaDto, SharedKitPushMessageTypeDtoCompanion, SharedKitPushMessageTypeDto, SharedKitPushRequestedUserDto, SharedKitPushRequestFriendDtoCompanion, SharedKitPushRequestFriendDto, SharedKitPushRequestedUserDtoCompanion, SharedKitResponseErrorDtoCompanion, SharedKitResponseErrorDto, SharedKitUpdateActiveDtoCompanion, SharedKitUpdateActiveDto, SharedKitAccessCredentialCodeLoginDtoCompanion, SharedKitAccessCredentialCodeLoginDto, SharedKitTemporalPeriodCreateDto, SharedKitCredentialClaimCreateDto, SharedKitAccessCredentialCreateDtoCompanion, SharedKitAccessCredentialCreateDto, SharedKitAccessCredentialCreateInternalDtoCompanion, SharedKitAccessCredentialCreateInternalDto, SharedKitTemporalPeriodViewDto, SharedKitAccessCredentialPreviewDtoCompanion, SharedKitAccessCredentialPreviewDto, SharedKitUserClaimViewDto, SharedKitAccessCredentialViewDtoCompanion, SharedKitAccessCredentialViewDto, SharedKitCredentialClaimCreateDtoCompanion, SharedKitPhoneChangeConfirmationCompanion, SharedKitPhoneChangeConfirmation, SharedKitRequestCodeDtoCompanion, SharedKitRequestCodeDto, SharedKitDBConnectionCreateDtoCompanion, SharedKitDBConnectionCreateDto, SharedKitDBConnectionViewDtoCompanion, SharedKitDBConnectionViewDto, SharedKitAddressValidationDtoCompanion, SharedKitAddressValidationDto, SharedKitPhoneValidationDtoCompanion, SharedKitPhoneValidationDto, SharedKitTimeZoneValidationDtoCompanion, SharedKitTimeZoneValidationDto, SharedKitValidPhoneNumberCompanion, SharedKitValidPhoneNumber, SharedKitGeoPointViewDtoCompanion, SharedKitGeoPointViewDto, SharedKitPropertyCreateDtoCompanion, SharedKitPropertyCreateDto, SharedKitPropertyDistinctViewDtoCompanion, SharedKitPropertyDistinctViewDto, SharedKitPropertyInternalCompanion, SharedKitPropertyInternal, SharedKitPropertyUpdateDtoCompanion, SharedKitPropertyUpdateDto, SharedKitPropertyViewDtoCompanion, SharedKitPropertyViewDto, SharedKitI18nCreateDtoCompanion, SharedKitI18nCreateDto, SharedKitI18nUpdateDtoCompanion, SharedKitI18nUpdateDto, SharedKitI18nViewDtoCompanion, SharedKitI18nViewDto, SharedKitLocaleViewDtoCompanion, SharedKitLocaleViewDto, SharedKitOAuthClientCreateDtoCompanion, SharedKitOAuthClientCreateDto, SharedKitOAuthClientViewDtoCompanion, SharedKitOAuthClientViewDto, SharedKitOAuthErrorViewDtoCompanion, SharedKitOAuthErrorViewDto, SharedKitOAuthTokenRequestDto, SharedKitTokenResponseViewDtoCompanion, SharedKitTokenResponseViewDto, SharedKitRemovedUserDataViewDtoCompanion, SharedKitRemovedUserDataViewDto, SharedKitTemporalPeriodWeekdaysCreateDto, SharedKitTemporalPeriodCreateDtoCompanion, SharedKitTemporalPeriodWeekdaysViewDto, SharedKitTemporalPeriodViewDtoCompanion, SharedKitTemporalPeriodWeekdaysCreateDtoCompanion, SharedKitTemporalPeriodWeekdaysViewDtoCompanion, SharedKitNotificationChannelFactory, SharedKitNotificationSourceDtoCompanion, SharedKitNotificationSourceDto, SharedKitMultipleUsersValidationDtoCompanion, SharedKitMultipleUsersValidationDto, SharedKitRoleViewDtoCompanion, SharedKitRoleViewDto, SharedKitUserAdminCreateDtoCompanion, SharedKitUserAdminCreateDto, SharedKitUserClaimCreateDtoCompanion, SharedKitUserClaimCreateDto, SharedKitUserClaimViewDtoCompanion, SharedKitUserCodeLoginDtoCompanion, SharedKitUserCodeLoginDto, SharedKitUserCreateDtoCompanion, SharedKitUserCreateDto, SharedKitUserCreateProfileInternalDtoCompanion, SharedKitUserCreateProfileInternalDto, SharedKitUserLoginDtoCompanion, SharedKitUserLoginDto, SharedKitUserLogoutInternalDtoCompanion, SharedKitUserLogoutInternalDto, SharedKitUserUpdateDtoCompanion, SharedKitUserUpdateDto, SharedKitUserViewDtoCompanion, SharedKitUserViewDto, SharedKitUserViewInternalDtoCompanion, SharedKitUserViewInternalDto, SharedKitUsersWithClaimRequestDtoCompanion, SharedKitUsersWithClaimRequestDto, SharedKitUsersWithClaimViewDtoCompanion, SharedKitUsersWithClaimViewDto, SharedKitSocialMediaLinkCreateDtoCompanion, SharedKitSocialMediaLinkCreateDto, SharedKitSocialMediaLinkUpdateDtoCompanion, SharedKitSocialMediaLinkUpdateDto, SharedKitSocialMediaLinkViewDtoCompanion, SharedKitSocialMediaLinkViewDto, SharedKitAddressCreateDtoCompanion, SharedKitAddressCreateDto, SharedKitAddressSearchDtoCompanion, SharedKitAddressSearchDto, SharedKitAddressUpdateDtoCompanion, SharedKitAddressUpdateDto, SharedKitAddressViewDtoCompanion, SharedKitAddressViewDto, SharedKitAddressWithContactsCreateDtoCompanion, SharedKitAddressWithContactsCreateDto, SharedKitAddressWithContactsUpdateDtoCompanion, SharedKitAddressWithContactsUpdateDto, SharedKitAddressWithContactsViewDtoCompanion, SharedKitAddressWithContactsViewDto, SharedKitStateCreateDtoCompanion, SharedKitStateCreateDto, SharedKitStateUpdateDtoCompanion, SharedKitStateUpdateDto, SharedKitStateViewDtoCompanion, SharedKitStateViewDto, SharedKitTimeZoneViewDtoCompanion, SharedKitTimeZoneViewDto, SharedKitCountryUserViewDtoCompanion, SharedKitCountryUserViewDto, SharedKitCountryViewDtoCompanion, SharedKitCountryViewDto, SharedKitUserDeviceCredentialCreateDtoCompanion, SharedKitUserDeviceCredentialCreateDto, SharedKitUserDeviceCredentialViewDtoCompanion, SharedKitUserDeviceCredentialViewDto, SharedKitTreeNodeViewLazyDto, SharedKitTreeNodeUpdateDtoCompanion, SharedKitTreeNodeUpdateDto, SharedKitTreeNodeViewDto, SharedKitTreeNodeViewDtoCompanion, SharedKitTreeNodeViewLazyDtoCompanion, SharedKitMediaAuthViewDtoCompanion, SharedKitMediaAuthViewDto, SharedKitMediaViewerCreateDtoCompanion, SharedKitMediaViewerCreateDto, SharedKitPrivacyMessageInternalDtoCompanion, SharedKitPrivacyMessageInternalDto, SharedKitFlag, SharedKitPushMessageType_, SharedKitKotlinx_serialization_jsonJson, SharedKitCommon_dto_mediaPendingMediaResourceCreateDtoCompanion, SharedKitCommon_dto_mediaMediaResourceViewDtoCompanion, SharedKitKotlinx_datetimeInstantCompanion, SharedKitKotlinx_serialization_coreSerializersModule, SharedKitKotlinx_serialization_coreSerialKind, SharedKitKotlinNothing, SharedKitKotlinx_datetimeMonth, SharedKitKotlinx_datetimeLocalDateCompanion, SharedKitKotlinx_datetimeDayOfWeek, SharedKitKotlinByteArray, SharedKitKotlinx_serialization_jsonJsonDefault, SharedKitKotlinx_serialization_jsonJsonElement, SharedKitKotlinx_serialization_jsonJsonConfiguration, SharedKitKotlinByteIterator, SharedKitKotlinx_serialization_jsonJsonElementCompanion;

@protocol SharedKitKotlinx_serialization_coreKSerializer, SharedKitKotlinComparable, SharedKitParcelable, SharedKitKotlinx_serialization_coreEncoder, SharedKitKotlinx_serialization_coreSerialDescriptor, SharedKitKotlinx_serialization_coreSerializationStrategy, SharedKitKotlinx_serialization_coreDecoder, SharedKitKotlinx_serialization_coreDeserializationStrategy, SharedKitPlatform, SharedKitKotlinIterator, SharedKitKotlinx_serialization_coreCompositeEncoder, SharedKitKotlinAnnotation, SharedKitKotlinx_serialization_coreCompositeDecoder, SharedKitKotlinx_serialization_coreSerialFormat, SharedKitKotlinx_serialization_coreStringFormat, SharedKitKotlinx_serialization_coreSerializersModuleCollector, SharedKitKotlinKClass, SharedKitKotlinKDeclarationContainer, SharedKitKotlinKAnnotatedElement, SharedKitKotlinKClassifier;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SharedKitBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SharedKitBase (SharedKitBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SharedKitMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SharedKitMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSharedKitKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SharedKitNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SharedKitByte : SharedKitNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SharedKitUByte : SharedKitNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SharedKitShort : SharedKitNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SharedKitUShort : SharedKitNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SharedKitInt : SharedKitNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SharedKitUInt : SharedKitNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SharedKitLong : SharedKitNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SharedKitULong : SharedKitNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SharedKitFloat : SharedKitNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SharedKitDouble : SharedKitNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SharedKitBoolean : SharedKitNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatMessageCreateDto")))
@interface SharedKitChatMessageCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithTextContent:(NSString * _Nullable)textContent userMentionIds:(NSSet<SharedKitLong *> *)userMentionIds file:(SharedKitCommon_dto_mediaPendingMediaResourceCreateDto * _Nullable)file roomId:(SharedKitLong * _Nullable)roomId __attribute__((swift_name("init(textContent:userMentionIds:file:roomId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatMessageCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatMessageCreateDto *)doCopyTextContent:(NSString * _Nullable)textContent userMentionIds:(NSSet<SharedKitLong *> *)userMentionIds file:(SharedKitCommon_dto_mediaPendingMediaResourceCreateDto * _Nullable)file roomId:(SharedKitLong * _Nullable)roomId __attribute__((swift_name("doCopy(textContent:userMentionIds:file:roomId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitCommon_dto_mediaPendingMediaResourceCreateDto * _Nullable file __attribute__((swift_name("file")));
@property SharedKitLong * _Nullable roomId __attribute__((swift_name("roomId")));
@property NSString * _Nullable textContent __attribute__((swift_name("textContent")));
@property NSSet<SharedKitLong *> *userMentionIds __attribute__((swift_name("userMentionIds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatMessageCreateDto.Companion")))
@interface SharedKitChatMessageCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatMessageCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinComparable")))
@protocol SharedKitKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end

__attribute__((swift_name("KotlinEnum")))
@interface SharedKitKotlinEnum<E> : SharedKitBase <SharedKitKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatMessageStatus")))
@interface SharedKitChatMessageStatus : SharedKitKotlinEnum<SharedKitChatMessageStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitChatMessageStatus *sending __attribute__((swift_name("sending")));
@property (class, readonly) SharedKitChatMessageStatus *sent __attribute__((swift_name("sent")));
@property (class, readonly) SharedKitChatMessageStatus *failed __attribute__((swift_name("failed")));
+ (SharedKitKotlinArray<SharedKitChatMessageStatus *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((swift_name("Parcelable")))
@protocol SharedKitParcelable
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatMessageViewDto")))
@interface SharedKitChatMessageViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id senderId:(SharedKitLong * _Nullable)senderId textContent:(NSString * _Nullable)textContent userMentionIds:(NSSet<SharedKitLong *> *)userMentionIds file:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)file createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt status:(SharedKitChatMessageStatus * _Nullable)status __attribute__((swift_name("init(id:senderId:textContent:userMentionIds:file:createdAt:status:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatMessageViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatMessageViewDto *)doCopyId:(SharedKitLong * _Nullable)id senderId:(SharedKitLong * _Nullable)senderId textContent:(NSString * _Nullable)textContent userMentionIds:(NSSet<SharedKitLong *> *)userMentionIds file:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)file createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt status:(SharedKitChatMessageStatus * _Nullable)status __attribute__((swift_name("doCopy(id:senderId:textContent:userMentionIds:file:createdAt:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable file __attribute__((swift_name("file")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property SharedKitLong * _Nullable senderId __attribute__((swift_name("senderId")));
@property SharedKitChatMessageStatus * _Nullable status __attribute__((swift_name("status")));
@property NSString * _Nullable textContent __attribute__((swift_name("textContent")));
@property NSSet<SharedKitLong *> *userMentionIds __attribute__((swift_name("userMentionIds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatMessageViewDto.Companion")))
@interface SharedKitChatMessageViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatMessageViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatPresenceCheckDto")))
@interface SharedKitChatPresenceCheckDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithUserids:(NSSet<SharedKitLong *> *)userids __attribute__((swift_name("init(userids:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatPresenceCheckDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatPresenceCheckDto *)doCopyUserids:(NSSet<SharedKitLong *> *)userids __attribute__((swift_name("doCopy(userids:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitLong *> *userids __attribute__((swift_name("userids")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatPresenceCheckDto.Companion")))
@interface SharedKitChatPresenceCheckDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatPresenceCheckDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomBoardItemViewDto")))
@interface SharedKitChatRoomBoardItemViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name cover:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)cover type:(SharedKitChatRoomType *)type memberId:(SharedKitLong * _Nullable)memberId roomId:(SharedKitLong * _Nullable)roomId unreadMessageCount:(SharedKitInt * _Nullable)unreadMessageCount lastSenderId:(SharedKitLong * _Nullable)lastSenderId firstParticipantId:(SharedKitLong * _Nullable)firstParticipantId lastMessagePreview:(NSString * _Nullable)lastMessagePreview lastMessageAt:(SharedKitKotlinx_datetimeInstant * _Nullable)lastMessageAt createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt lastMessageFile:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)lastMessageFile __attribute__((swift_name("init(name:cover:type:memberId:roomId:unreadMessageCount:lastSenderId:firstParticipantId:lastMessagePreview:lastMessageAt:createdAt:lastMessageFile:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomBoardItemViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomBoardItemViewDto *)doCopyName:(NSString * _Nullable)name cover:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)cover type:(SharedKitChatRoomType *)type memberId:(SharedKitLong * _Nullable)memberId roomId:(SharedKitLong * _Nullable)roomId unreadMessageCount:(SharedKitInt * _Nullable)unreadMessageCount lastSenderId:(SharedKitLong * _Nullable)lastSenderId firstParticipantId:(SharedKitLong * _Nullable)firstParticipantId lastMessagePreview:(NSString * _Nullable)lastMessagePreview lastMessageAt:(SharedKitKotlinx_datetimeInstant * _Nullable)lastMessageAt createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt lastMessageFile:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)lastMessageFile __attribute__((swift_name("doCopy(name:cover:type:memberId:roomId:unreadMessageCount:lastSenderId:firstParticipantId:lastMessagePreview:lastMessageAt:createdAt:lastMessageFile:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable cover __attribute__((swift_name("cover")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property SharedKitLong * _Nullable firstParticipantId __attribute__((swift_name("firstParticipantId")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable lastMessageAt __attribute__((swift_name("lastMessageAt")));
@property SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable lastMessageFile __attribute__((swift_name("lastMessageFile")));
@property NSString * _Nullable lastMessagePreview __attribute__((swift_name("lastMessagePreview")));
@property SharedKitLong * _Nullable lastSenderId __attribute__((swift_name("lastSenderId")));
@property SharedKitLong * _Nullable memberId __attribute__((swift_name("memberId")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property SharedKitLong * _Nullable roomId __attribute__((swift_name("roomId")));
@property SharedKitChatRoomType *type __attribute__((swift_name("type")));
@property SharedKitInt * _Nullable unreadMessageCount __attribute__((swift_name("unreadMessageCount")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomBoardItemViewDto.Companion")))
@interface SharedKitChatRoomBoardItemViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomBoardItemViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomCreateDto")))
@interface SharedKitChatRoomCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name description:(NSString * _Nullable)description participantIds:(NSSet<SharedKitLong *> *)participantIds externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType type:(SharedKitChatRoomType * _Nullable)type __attribute__((swift_name("init(name:description:participantIds:externalId:sourceType:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomCreateDto *)doCopyName:(NSString * _Nullable)name description:(NSString * _Nullable)description participantIds:(NSSet<SharedKitLong *> *)participantIds externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType type:(SharedKitChatRoomType * _Nullable)type __attribute__((swift_name("doCopy(name:description:participantIds:externalId:sourceType:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (setter=setDescription:) NSString * _Nullable description_ __attribute__((swift_name("description_")));
@property NSString * _Nullable externalId __attribute__((swift_name("externalId")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSSet<SharedKitLong *> *participantIds __attribute__((swift_name("participantIds")));
@property SharedKitChatRoomSourceType * _Nullable sourceType __attribute__((swift_name("sourceType")));
@property SharedKitChatRoomType * _Nullable type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomCreateDto.Companion")))
@interface SharedKitChatRoomCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomEditAdminDto")))
@interface SharedKitChatRoomEditAdminDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithAdminsToRemove:(NSSet<SharedKitLong *> *)adminsToRemove adminsToAdd:(NSSet<SharedKitLong *> *)adminsToAdd __attribute__((swift_name("init(adminsToRemove:adminsToAdd:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomEditAdminDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomEditAdminDto *)doCopyAdminsToRemove:(NSSet<SharedKitLong *> *)adminsToRemove adminsToAdd:(NSSet<SharedKitLong *> *)adminsToAdd __attribute__((swift_name("doCopy(adminsToRemove:adminsToAdd:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitLong *> *adminsToAdd __attribute__((swift_name("adminsToAdd")));
@property NSSet<SharedKitLong *> *adminsToRemove __attribute__((swift_name("adminsToRemove")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomEditAdminDto.Companion")))
@interface SharedKitChatRoomEditAdminDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomEditAdminDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomEditParticipantDto")))
@interface SharedKitChatRoomEditParticipantDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithParticipantsToRemove:(NSSet<SharedKitLong *> *)participantsToRemove participantsToAdd:(NSSet<SharedKitLong *> *)participantsToAdd __attribute__((swift_name("init(participantsToRemove:participantsToAdd:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomEditParticipantDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomEditParticipantDto *)doCopyParticipantsToRemove:(NSSet<SharedKitLong *> *)participantsToRemove participantsToAdd:(NSSet<SharedKitLong *> *)participantsToAdd __attribute__((swift_name("doCopy(participantsToRemove:participantsToAdd:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitLong *> *participantsToAdd __attribute__((swift_name("participantsToAdd")));
@property NSSet<SharedKitLong *> *participantsToRemove __attribute__((swift_name("participantsToRemove")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomEditParticipantDto.Companion")))
@interface SharedKitChatRoomEditParticipantDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomEditParticipantDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomUpdateDto")))
@interface SharedKitChatRoomUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name description:(NSString * _Nullable)description __attribute__((swift_name("init(name:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomUpdateDto *)doCopyName:(NSString * _Nullable)name description:(NSString * _Nullable)description __attribute__((swift_name("doCopy(name:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (setter=setDescription:) NSString * _Nullable description_ __attribute__((swift_name("description_")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomUpdateDto.Companion")))
@interface SharedKitChatRoomUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomViewDto")))
@interface SharedKitChatRoomViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id ownerId:(SharedKitLong * _Nullable)ownerId name:(NSString * _Nullable)name description:(NSString * _Nullable)description participantIds:(NSSet<SharedKitLong *> *)participantIds adminIds:(NSSet<SharedKitLong *> *)adminIds cover:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)cover externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType type:(SharedKitChatRoomType * _Nullable)type __attribute__((swift_name("init(id:ownerId:name:description:participantIds:adminIds:cover:externalId:sourceType:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitChatRoomViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitChatRoomViewDto *)doCopyId:(SharedKitLong * _Nullable)id ownerId:(SharedKitLong * _Nullable)ownerId name:(NSString * _Nullable)name description:(NSString * _Nullable)description participantIds:(NSSet<SharedKitLong *> *)participantIds adminIds:(NSSet<SharedKitLong *> *)adminIds cover:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)cover externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType type:(SharedKitChatRoomType * _Nullable)type __attribute__((swift_name("doCopy(id:ownerId:name:description:participantIds:adminIds:cover:externalId:sourceType:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitLong *> *adminIds __attribute__((swift_name("adminIds")));
@property SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable cover __attribute__((swift_name("cover")));
@property (setter=setDescription:) NSString * _Nullable description_ __attribute__((swift_name("description_")));
@property NSString * _Nullable externalId __attribute__((swift_name("externalId")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property SharedKitLong * _Nullable ownerId __attribute__((swift_name("ownerId")));
@property NSSet<SharedKitLong *> *participantIds __attribute__((swift_name("participantIds")));
@property SharedKitChatRoomSourceType * _Nullable sourceType __attribute__((swift_name("sourceType")));
@property SharedKitChatRoomType * _Nullable type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomViewDto.Companion")))
@interface SharedKitChatRoomViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitChatRoomViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingActionDto")))
@interface SharedKitMeetingActionDto : SharedKitBase
- (instancetype)initWithType:(NSString *)type status:(SharedKitBoolean * _Nullable)status __attribute__((swift_name("init(type:status:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingActionDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingActionDto *)doCopyType:(NSString *)type status:(SharedKitBoolean * _Nullable)status __attribute__((swift_name("doCopy(type:status:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable status __attribute__((swift_name("status")));
@property NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingActionDto.Companion")))
@interface SharedKitMeetingActionDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingActionDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingCallStatusViewDto")))
@interface SharedKitMeetingCallStatusViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithType:(SharedKitCallStatusType *)type toPeerId:(NSString * _Nullable)toPeerId fromPeerId:(NSString * _Nullable)fromPeerId meetingId:(SharedKitLong * _Nullable)meetingId fromMemberId:(SharedKitLong * _Nullable)fromMemberId toMemberId:(SharedKitLong * _Nullable)toMemberId timestamp:(SharedKitLong * _Nullable)timestamp __attribute__((swift_name("init(type:toPeerId:fromPeerId:meetingId:fromMemberId:toMemberId:timestamp:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingCallStatusViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingCallStatusViewDto *)doCopyType:(SharedKitCallStatusType *)type toPeerId:(NSString * _Nullable)toPeerId fromPeerId:(NSString * _Nullable)fromPeerId meetingId:(SharedKitLong * _Nullable)meetingId fromMemberId:(SharedKitLong * _Nullable)fromMemberId toMemberId:(SharedKitLong * _Nullable)toMemberId timestamp:(SharedKitLong * _Nullable)timestamp __attribute__((swift_name("doCopy(type:toPeerId:fromPeerId:meetingId:fromMemberId:toMemberId:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitLong * _Nullable fromMemberId __attribute__((swift_name("fromMemberId")));
@property NSString * _Nullable fromPeerId __attribute__((swift_name("fromPeerId")));
@property SharedKitLong * _Nullable meetingId __attribute__((swift_name("meetingId")));
@property SharedKitLong * _Nullable timestamp __attribute__((swift_name("timestamp")));
@property SharedKitLong * _Nullable toMemberId __attribute__((swift_name("toMemberId")));
@property NSString * _Nullable toPeerId __attribute__((swift_name("toPeerId")));
@property SharedKitCallStatusType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingCallStatusViewDto.Companion")))
@interface SharedKitMeetingCallStatusViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingCallStatusViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingCandidateDto")))
@interface SharedKitMeetingCandidateDto : SharedKitBase
- (instancetype)initWithCandidate:(NSString *)candidate sdpMLineIndex:(int32_t)sdpMLineIndex sdpMid:(NSString * _Nullable)sdpMid __attribute__((swift_name("init(candidate:sdpMLineIndex:sdpMid:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingCandidateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingCandidateDto *)doCopyCandidate:(NSString *)candidate sdpMLineIndex:(int32_t)sdpMLineIndex sdpMid:(NSString * _Nullable)sdpMid __attribute__((swift_name("doCopy(candidate:sdpMLineIndex:sdpMid:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *candidate __attribute__((swift_name("candidate")));
@property (readonly) int32_t sdpMLineIndex __attribute__((swift_name("sdpMLineIndex")));
@property (readonly) NSString * _Nullable sdpMid __attribute__((swift_name("sdpMid")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingCandidateDto.Companion")))
@interface SharedKitMeetingCandidateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingCandidateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingMessageDto")))
@interface SharedKitMeetingMessageDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithType:(SharedKitWebRtcMessageType *)type payload:(NSString *)payload toPeerId:(NSString * _Nullable)toPeerId fromPeerId:(NSString * _Nullable)fromPeerId meetingId:(SharedKitLong * _Nullable)meetingId fromMemberId:(SharedKitLong * _Nullable)fromMemberId toMemberId:(SharedKitLong * _Nullable)toMemberId __attribute__((swift_name("init(type:payload:toPeerId:fromPeerId:meetingId:fromMemberId:toMemberId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingMessageDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingActionDto * _Nullable)action __attribute__((swift_name("action()")));
- (SharedKitMeetingMessageDto *)doCopyType:(SharedKitWebRtcMessageType *)type payload:(NSString *)payload toPeerId:(NSString * _Nullable)toPeerId fromPeerId:(NSString * _Nullable)fromPeerId meetingId:(SharedKitLong * _Nullable)meetingId fromMemberId:(SharedKitLong * _Nullable)fromMemberId toMemberId:(SharedKitLong * _Nullable)toMemberId __attribute__((swift_name("doCopy(type:payload:toPeerId:fromPeerId:meetingId:fromMemberId:toMemberId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedKitMeetingCandidateDto * _Nullable)iceCandidate __attribute__((swift_name("iceCandidate()")));
- (NSArray<SharedKitMeetingCandidateDto *> *)removedIceCandidates __attribute__((swift_name("removedIceCandidates()")));
- (SharedKitMeetingSessionDto * _Nullable)sessionDescription __attribute__((swift_name("sessionDescription()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitLong * _Nullable fromMemberId __attribute__((swift_name("fromMemberId")));
@property NSString * _Nullable fromPeerId __attribute__((swift_name("fromPeerId")));
@property SharedKitLong * _Nullable meetingId __attribute__((swift_name("meetingId")));
@property NSString *payload __attribute__((swift_name("payload")));
@property SharedKitLong * _Nullable toMemberId __attribute__((swift_name("toMemberId")));
@property NSString * _Nullable toPeerId __attribute__((swift_name("toPeerId")));
@property SharedKitWebRtcMessageType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingMessageDto.Companion")))
@interface SharedKitMeetingMessageDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingMessageDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingPeerStatusViewDto")))
@interface SharedKitMeetingPeerStatusViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithMeetingId:(SharedKitLong * _Nullable)meetingId peerId:(NSString * _Nullable)peerId memberId:(SharedKitLong * _Nullable)memberId roomId:(SharedKitLong * _Nullable)roomId type:(SharedKitCallStatusType * _Nullable)type __attribute__((swift_name("init(meetingId:peerId:memberId:roomId:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingPeerStatusViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingPeerStatusViewDto *)doCopyMeetingId:(SharedKitLong * _Nullable)meetingId peerId:(NSString * _Nullable)peerId memberId:(SharedKitLong * _Nullable)memberId roomId:(SharedKitLong * _Nullable)roomId type:(SharedKitCallStatusType * _Nullable)type __attribute__((swift_name("doCopy(meetingId:peerId:memberId:roomId:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitLong * _Nullable meetingId __attribute__((swift_name("meetingId")));
@property SharedKitLong * _Nullable memberId __attribute__((swift_name("memberId")));
@property NSString * _Nullable peerId __attribute__((swift_name("peerId")));
@property SharedKitLong * _Nullable roomId __attribute__((swift_name("roomId")));
@property SharedKitCallStatusType * _Nullable type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingPeerStatusViewDto.Companion")))
@interface SharedKitMeetingPeerStatusViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingPeerStatusViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingSessionDto")))
@interface SharedKitMeetingSessionDto : SharedKitBase
- (instancetype)initWithSdp:(NSString *)sdp type:(NSString *)type offerId:(NSString * _Nullable)offerId __attribute__((swift_name("init(sdp:type:offerId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingSessionDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingSessionDto *)doCopySdp:(NSString *)sdp type:(NSString *)type offerId:(NSString * _Nullable)offerId __attribute__((swift_name("doCopy(sdp:type:offerId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable offerId __attribute__((swift_name("offerId")));
@property (readonly) NSString *sdp __attribute__((swift_name("sdp")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingSessionDto.Companion")))
@interface SharedKitMeetingSessionDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingSessionDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingViewDto")))
@interface SharedKitMeetingViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name memberId:(SharedKitLong * _Nullable)memberId attendeeId:(NSString * _Nullable)attendeeId turnServer:(NSString * _Nullable)turnServer turnUsername:(NSString * _Nullable)turnUsername turnPassword:(NSString * _Nullable)turnPassword stunServer:(NSString * _Nullable)stunServer stunUsername:(NSString * _Nullable)stunUsername stunPassword:(NSString * _Nullable)stunPassword roomId:(SharedKitLong * _Nullable)roomId creatorId:(SharedKitLong * _Nullable)creatorId participantIds:(NSSet<SharedKitLong *> *)participantIds inviteeIds:(NSSet<SharedKitLong *> *)inviteeIds members:(NSSet<SharedKitMemberViewDto *> *)members type:(SharedKitMeetingType *)type creatorPeerId:(NSString * _Nullable)creatorPeerId callerMemberId:(SharedKitLong * _Nullable)callerMemberId callerMemberName:(NSString * _Nullable)callerMemberName __attribute__((swift_name("init(id:name:memberId:attendeeId:turnServer:turnUsername:turnPassword:stunServer:stunUsername:stunPassword:roomId:creatorId:participantIds:inviteeIds:members:type:creatorPeerId:callerMemberId:callerMemberName:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingViewDto *)doCopyId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name memberId:(SharedKitLong * _Nullable)memberId attendeeId:(NSString * _Nullable)attendeeId turnServer:(NSString * _Nullable)turnServer turnUsername:(NSString * _Nullable)turnUsername turnPassword:(NSString * _Nullable)turnPassword stunServer:(NSString * _Nullable)stunServer stunUsername:(NSString * _Nullable)stunUsername stunPassword:(NSString * _Nullable)stunPassword roomId:(SharedKitLong * _Nullable)roomId creatorId:(SharedKitLong * _Nullable)creatorId participantIds:(NSSet<SharedKitLong *> *)participantIds inviteeIds:(NSSet<SharedKitLong *> *)inviteeIds members:(NSSet<SharedKitMemberViewDto *> *)members type:(SharedKitMeetingType *)type creatorPeerId:(NSString * _Nullable)creatorPeerId callerMemberId:(SharedKitLong * _Nullable)callerMemberId callerMemberName:(NSString * _Nullable)callerMemberName __attribute__((swift_name("doCopy(id:name:memberId:attendeeId:turnServer:turnUsername:turnPassword:stunServer:stunUsername:stunPassword:roomId:creatorId:participantIds:inviteeIds:members:type:creatorPeerId:callerMemberId:callerMemberName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable attendeeId __attribute__((swift_name("attendeeId")));
@property SharedKitLong * _Nullable callerMemberId __attribute__((swift_name("callerMemberId")));
@property NSString * _Nullable callerMemberName __attribute__((swift_name("callerMemberName")));
@property SharedKitLong * _Nullable creatorId __attribute__((swift_name("creatorId")));
@property NSString * _Nullable creatorPeerId __attribute__((swift_name("creatorPeerId")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSSet<SharedKitLong *> *inviteeIds __attribute__((swift_name("inviteeIds")));
@property SharedKitLong * _Nullable memberId __attribute__((swift_name("memberId")));
@property NSSet<SharedKitMemberViewDto *> *members __attribute__((swift_name("members")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSSet<SharedKitLong *> *participantIds __attribute__((swift_name("participantIds")));
@property SharedKitLong * _Nullable roomId __attribute__((swift_name("roomId")));
@property NSString * _Nullable stunPassword __attribute__((swift_name("stunPassword")));
@property NSString * _Nullable stunServer __attribute__((swift_name("stunServer")));
@property NSString * _Nullable stunUsername __attribute__((swift_name("stunUsername")));
@property NSString * _Nullable turnPassword __attribute__((swift_name("turnPassword")));
@property NSString * _Nullable turnServer __attribute__((swift_name("turnServer")));
@property NSString * _Nullable turnUsername __attribute__((swift_name("turnUsername")));
@property SharedKitMeetingType *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingViewDto.Companion")))
@interface SharedKitMeetingViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingWithInviteesCreateDto")))
@interface SharedKitMeetingWithInviteesCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithInviteeIds:(NSSet<SharedKitLong *> *)inviteeIds externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType name:(NSString * _Nullable)name ownerId:(SharedKitLong * _Nullable)ownerId __attribute__((swift_name("init(inviteeIds:externalId:sourceType:name:ownerId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMeetingWithInviteesCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMeetingWithInviteesCreateDto *)doCopyInviteeIds:(NSSet<SharedKitLong *> *)inviteeIds externalId:(NSString * _Nullable)externalId sourceType:(SharedKitChatRoomSourceType * _Nullable)sourceType name:(NSString * _Nullable)name ownerId:(SharedKitLong * _Nullable)ownerId __attribute__((swift_name("doCopy(inviteeIds:externalId:sourceType:name:ownerId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable externalId __attribute__((swift_name("externalId")));
@property NSSet<SharedKitLong *> *inviteeIds __attribute__((swift_name("inviteeIds")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property SharedKitLong * _Nullable ownerId __attribute__((swift_name("ownerId")));
@property SharedKitChatRoomSourceType * _Nullable sourceType __attribute__((swift_name("sourceType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingWithInviteesCreateDto.Companion")))
@interface SharedKitMeetingWithInviteesCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMeetingWithInviteesCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberViewDto")))
@interface SharedKitMemberViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name userId:(SharedKitLong * _Nullable)userId title:(NSString * _Nullable)title memberType:(SharedKitMemberType * _Nullable)memberType call:(SharedKitBoolean * _Nullable)call message:(SharedKitBoolean * _Nullable)message avatar:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)avatar peerId:(NSString * _Nullable)peerId __attribute__((swift_name("init(id:name:userId:title:memberType:call:message:avatar:peerId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMemberViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMemberViewDto *)doCopyId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name userId:(SharedKitLong * _Nullable)userId title:(NSString * _Nullable)title memberType:(SharedKitMemberType * _Nullable)memberType call:(SharedKitBoolean * _Nullable)call message:(SharedKitBoolean * _Nullable)message avatar:(SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable)avatar peerId:(NSString * _Nullable)peerId __attribute__((swift_name("doCopy(id:name:userId:title:memberType:call:message:avatar:peerId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitCommon_dto_mediaMediaResourceViewDto * _Nullable avatar __attribute__((swift_name("avatar")));
@property SharedKitBoolean * _Nullable call __attribute__((swift_name("call")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property SharedKitMemberType * _Nullable memberType __attribute__((swift_name("memberType")));
@property (readonly) SharedKitBoolean * _Nullable message __attribute__((swift_name("message")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable peerId __attribute__((swift_name("peerId")));
@property NSString * _Nullable title __attribute__((swift_name("title")));
@property SharedKitLong * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberViewDto.Companion")))
@interface SharedKitMemberViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMemberViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserChatStatusUpdateDto")))
@interface SharedKitUserChatStatusUpdateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithStatus:(SharedKitUserChatPresenceStatus * _Nullable)status textStatus:(NSString * _Nullable)textStatus __attribute__((swift_name("init(status:textStatus:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserChatStatusUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserChatStatusUpdateDto *)doCopyStatus:(SharedKitUserChatPresenceStatus * _Nullable)status textStatus:(NSString * _Nullable)textStatus __attribute__((swift_name("doCopy(status:textStatus:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitUserChatPresenceStatus * _Nullable status __attribute__((swift_name("status")));
@property NSString * _Nullable textStatus __attribute__((swift_name("textStatus")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserChatStatusUpdateDto.Companion")))
@interface SharedKitUserChatStatusUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserChatStatusUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserChatStatusViewDto")))
@interface SharedKitUserChatStatusViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithUserid:(SharedKitLong * _Nullable)userid status:(SharedKitUserChatPresenceStatus * _Nullable)status textStatus:(NSString * _Nullable)textStatus __attribute__((swift_name("init(userid:status:textStatus:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserChatStatusViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserChatStatusViewDto *)doCopyUserid:(SharedKitLong * _Nullable)userid status:(SharedKitUserChatPresenceStatus * _Nullable)status textStatus:(NSString * _Nullable)textStatus __attribute__((swift_name("doCopy(userid:status:textStatus:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitUserChatPresenceStatus * _Nullable status __attribute__((swift_name("status")));
@property NSString * _Nullable textStatus __attribute__((swift_name("textStatus")));
@property SharedKitLong * _Nullable userid __attribute__((swift_name("userid")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserChatStatusViewDto.Companion")))
@interface SharedKitUserChatStatusViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserChatStatusViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CallStatusType")))
@interface SharedKitCallStatusType : SharedKitKotlinEnum<SharedKitCallStatusType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitCallStatusType *ringing __attribute__((swift_name("ringing")));
@property (class, readonly) SharedKitCallStatusType *skipping __attribute__((swift_name("skipping")));
@property (class, readonly) SharedKitCallStatusType *active __attribute__((swift_name("active")));
@property (class, readonly) SharedKitCallStatusType *troubleshooting __attribute__((swift_name("troubleshooting")));
@property (class, readonly) SharedKitCallStatusType *leaving __attribute__((swift_name("leaving")));
+ (SharedKitKotlinArray<SharedKitCallStatusType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomSourceType")))
@interface SharedKitChatRoomSourceType : SharedKitKotlinEnum<SharedKitChatRoomSourceType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitChatRoomSourceType *chat __attribute__((swift_name("chat")));
@property (class, readonly) SharedKitChatRoomSourceType *group __attribute__((swift_name("group")));
@property (class, readonly) SharedKitChatRoomSourceType *event __attribute__((swift_name("event")));
+ (SharedKitKotlinArray<SharedKitChatRoomSourceType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ChatRoomType")))
@interface SharedKitChatRoomType : SharedKitKotlinEnum<SharedKitChatRoomType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitChatRoomType *singleConversation __attribute__((swift_name("singleConversation")));
@property (class, readonly) SharedKitChatRoomType *groupConversation __attribute__((swift_name("groupConversation")));
@property (class, readonly) SharedKitChatRoomType *internalConversation __attribute__((swift_name("internalConversation")));
+ (SharedKitKotlinArray<SharedKitChatRoomType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingType")))
@interface SharedKitMeetingType : SharedKitKotlinEnum<SharedKitMeetingType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMeetingType *video __attribute__((swift_name("video")));
@property (class, readonly) SharedKitMeetingType *audio __attribute__((swift_name("audio")));
+ (SharedKitKotlinArray<SharedKitMeetingType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MemberType")))
@interface SharedKitMemberType : SharedKitKotlinEnum<SharedKitMemberType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMemberType *user __attribute__((swift_name("user")));
@property (class, readonly) SharedKitMemberType *device __attribute__((swift_name("device")));
+ (SharedKitKotlinArray<SharedKitMemberType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserChatPresenceStatus")))
@interface SharedKitUserChatPresenceStatus : SharedKitKotlinEnum<SharedKitUserChatPresenceStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitUserChatPresenceStatus *online __attribute__((swift_name("online")));
@property (class, readonly) SharedKitUserChatPresenceStatus *away __attribute__((swift_name("away")));
@property (class, readonly) SharedKitUserChatPresenceStatus *offline __attribute__((swift_name("offline")));
+ (SharedKitKotlinArray<SharedKitUserChatPresenceStatus *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WebRtcMessageType")))
@interface SharedKitWebRtcMessageType : SharedKitKotlinEnum<SharedKitWebRtcMessageType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitWebRtcMessageType *action __attribute__((swift_name("action")));
@property (class, readonly) SharedKitWebRtcMessageType *icecandidate __attribute__((swift_name("icecandidate")));
@property (class, readonly) SharedKitWebRtcMessageType *removedicecandidates __attribute__((swift_name("removedicecandidates")));
@property (class, readonly) SharedKitWebRtcMessageType *sessiondescription __attribute__((swift_name("sessiondescription")));
+ (SharedKitKotlinArray<SharedKitWebRtcMessageType *> *)values __attribute__((swift_name("values()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaResourceInternalViewDto")))
@interface SharedKitMediaResourceInternalViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithContentType:(NSString * _Nullable)contentType filename:(NSString * _Nullable)filename originalFilename:(NSString * _Nullable)originalFilename customPath:(NSString * _Nullable)customPath groupOrder:(SharedKitInt * _Nullable)groupOrder dominantColor:(NSString * _Nullable)dominantColor fileChecksum:(NSString * _Nullable)fileChecksum metadata:(NSArray<SharedKitNameValuePairDto *> * _Nullable)metadata mediaProfile:(NSString * _Nullable)mediaProfile visibility:(SharedKitMediaVisibility * _Nullable)visibility processingError:(BOOL)processingError orientation:(SharedKitMediaOrientation * _Nullable)orientation size:(SharedKitLong * _Nullable)size thumbnails:(SharedKitBoolean * _Nullable)thumbnails __attribute__((swift_name("init(contentType:filename:originalFilename:customPath:groupOrder:dominantColor:fileChecksum:metadata:mediaProfile:visibility:processingError:orientation:size:thumbnails:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMediaResourceInternalViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMediaResourceInternalViewDto *)doCopyContentType:(NSString * _Nullable)contentType filename:(NSString * _Nullable)filename originalFilename:(NSString * _Nullable)originalFilename customPath:(NSString * _Nullable)customPath groupOrder:(SharedKitInt * _Nullable)groupOrder dominantColor:(NSString * _Nullable)dominantColor fileChecksum:(NSString * _Nullable)fileChecksum metadata:(NSArray<SharedKitNameValuePairDto *> * _Nullable)metadata mediaProfile:(NSString * _Nullable)mediaProfile visibility:(SharedKitMediaVisibility * _Nullable)visibility processingError:(BOOL)processingError orientation:(SharedKitMediaOrientation * _Nullable)orientation size:(SharedKitLong * _Nullable)size thumbnails:(SharedKitBoolean * _Nullable)thumbnails __attribute__((swift_name("doCopy(contentType:filename:originalFilename:customPath:groupOrder:dominantColor:fileChecksum:metadata:mediaProfile:visibility:processingError:orientation:size:thumbnails:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable contentType __attribute__((swift_name("contentType")));
@property NSString * _Nullable customPath __attribute__((swift_name("customPath")));
@property NSString * _Nullable dominantColor __attribute__((swift_name("dominantColor")));
@property NSString * _Nullable fileChecksum __attribute__((swift_name("fileChecksum")));
@property NSString * _Nullable filename __attribute__((swift_name("filename")));
@property SharedKitInt * _Nullable groupOrder __attribute__((swift_name("groupOrder")));
@property NSString * _Nullable mediaProfile __attribute__((swift_name("mediaProfile")));
@property NSArray<SharedKitNameValuePairDto *> * _Nullable metadata __attribute__((swift_name("metadata")));
@property SharedKitMediaOrientation * _Nullable orientation __attribute__((swift_name("orientation")));
@property NSString * _Nullable originalFilename __attribute__((swift_name("originalFilename")));
@property BOOL processingError __attribute__((swift_name("processingError")));
@property SharedKitLong * _Nullable size __attribute__((swift_name("size")));
@property SharedKitBoolean * _Nullable thumbnails __attribute__((swift_name("thumbnails")));
@property SharedKitMediaVisibility * _Nullable visibility __attribute__((swift_name("visibility")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaResourceInternalViewDto.Companion")))
@interface SharedKitMediaResourceInternalViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMediaResourceInternalViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaOrientation")))
@interface SharedKitMediaOrientation : SharedKitKotlinEnum<SharedKitMediaOrientation *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMediaOrientation *portrait __attribute__((swift_name("portrait")));
@property (class, readonly) SharedKitMediaOrientation *landscape __attribute__((swift_name("landscape")));
+ (SharedKitKotlinArray<SharedKitMediaOrientation *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaVisibility")))
@interface SharedKitMediaVisibility : SharedKitKotlinEnum<SharedKitMediaVisibility *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMediaVisibility *public_ __attribute__((swift_name("public_")));
@property (class, readonly) SharedKitMediaVisibility *authenticated __attribute__((swift_name("authenticated")));
@property (class, readonly) SharedKitMediaVisibility *user __attribute__((swift_name("user")));
@property (class, readonly) SharedKitMediaVisibility *admin __attribute__((swift_name("admin")));
+ (SharedKitKotlinArray<SharedKitMediaVisibility *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AudienceStatus")))
@interface SharedKitAudienceStatus : SharedKitKotlinEnum<SharedKitAudienceStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitAudienceStatus *everyone __attribute__((swift_name("everyone")));
@property (class, readonly) SharedKitAudienceStatus *friends __attribute__((swift_name("friends")));
@property (class, readonly) SharedKitAudienceStatus *groups __attribute__((swift_name("groups")));
+ (SharedKitKotlinArray<SharedKitAudienceStatus *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthType")))
@interface SharedKitAuthType : SharedKitKotlinEnum<SharedKitAuthType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKitAuthTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SharedKitAuthType *user __attribute__((swift_name("user")));
@property (class, readonly) SharedKitAuthType *accessCredential __attribute__((swift_name("accessCredential")));
@property (class, readonly) SharedKitAuthType *userDeviceCredential __attribute__((swift_name("userDeviceCredential")));
@property (class, readonly) SharedKitAuthType *mediaViewer __attribute__((swift_name("mediaViewer")));
+ (SharedKitKotlinArray<SharedKitAuthType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AuthType.Companion")))
@interface SharedKitAuthTypeCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAuthTypeCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedKitAuthType *)fromClaimClaim:(id _Nullable)claim __attribute__((swift_name("fromClaim(claim:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientOS")))
@interface SharedKitClientOS : SharedKitKotlinEnum<SharedKitClientOS *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKitClientOSCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SharedKitClientOS *ios __attribute__((swift_name("ios")));
@property (class, readonly) SharedKitClientOS *android __attribute__((swift_name("android")));
@property (class, readonly) SharedKitClientOS *web __attribute__((swift_name("web")));
@property (class, readonly) SharedKitClientOS *unknown __attribute__((swift_name("unknown")));
@property (class, readonly) SharedKitClientOS *huawei __attribute__((swift_name("huawei")));
@property (class, readonly) SharedKitClientOS *safari __attribute__((swift_name("safari")));
+ (SharedKitKotlinArray<SharedKitClientOS *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ClientOS.Companion")))
@interface SharedKitClientOSCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitClientOSCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedKitClientOS *)fromUserAgentUserAgent:(NSString * _Nullable)userAgent __attribute__((swift_name("fromUserAgent(userAgent:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorCode")))
@interface SharedKitErrorCode : SharedKitKotlinEnum<SharedKitErrorCode *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitErrorCode *badRequest __attribute__((swift_name("badRequest")));
@property (class, readonly) SharedKitErrorCode *fileIoError __attribute__((swift_name("fileIoError")));
@property (class, readonly) SharedKitErrorCode *emptySortField __attribute__((swift_name("emptySortField")));
@property (class, readonly) SharedKitErrorCode *incompleteCoordinates __attribute__((swift_name("incompleteCoordinates")));
@property (class, readonly) SharedKitErrorCode *invalidBeaconConfiguration __attribute__((swift_name("invalidBeaconConfiguration")));
@property (class, readonly) SharedKitErrorCode *invalidFeatureType __attribute__((swift_name("invalidFeatureType")));
@property (class, readonly) SharedKitErrorCode *invalidOldPassword __attribute__((swift_name("invalidOldPassword")));
@property (class, readonly) SharedKitErrorCode *invalidPasswordFormat __attribute__((swift_name("invalidPasswordFormat")));
@property (class, readonly) SharedKitErrorCode *invalidQueryFilter __attribute__((swift_name("invalidQueryFilter")));
@property (class, readonly) SharedKitErrorCode *invalidSortDirection __attribute__((swift_name("invalidSortDirection")));
@property (class, readonly) SharedKitErrorCode *invalidSortField __attribute__((swift_name("invalidSortField")));
@property (class, readonly) SharedKitErrorCode *invalidTimeZone __attribute__((swift_name("invalidTimeZone")));
@property (class, readonly) SharedKitErrorCode *invalidProductColor __attribute__((swift_name("invalidProductColor")));
@property (class, readonly) SharedKitErrorCode *invalidProductSize __attribute__((swift_name("invalidProductSize")));
@property (class, readonly) SharedKitErrorCode *invalidDeviceWriteField __attribute__((swift_name("invalidDeviceWriteField")));
@property (class, readonly) SharedKitErrorCode *invalidDeviceActionValue __attribute__((swift_name("invalidDeviceActionValue")));
@property (class, readonly) SharedKitErrorCode *unreachableMacroTrigger __attribute__((swift_name("unreachableMacroTrigger")));
@property (class, readonly) SharedKitErrorCode *invalidDeviceReadField __attribute__((swift_name("invalidDeviceReadField")));
@property (class, readonly) SharedKitErrorCode *invalidState __attribute__((swift_name("invalidState")));
@property (class, readonly) SharedKitErrorCode *errorDeletingItem __attribute__((swift_name("errorDeletingItem")));
@property (class, readonly) SharedKitErrorCode *fileTypeNotSupported __attribute__((swift_name("fileTypeNotSupported")));
@property (class, readonly) SharedKitErrorCode *imageIsTooSmall __attribute__((swift_name("imageIsTooSmall")));
@property (class, readonly) SharedKitErrorCode *errorCalculatingChecksum __attribute__((swift_name("errorCalculatingChecksum")));
@property (class, readonly) SharedKitErrorCode *invalidFile __attribute__((swift_name("invalidFile")));
@property (class, readonly) SharedKitErrorCode *originalFileCreation __attribute__((swift_name("originalFileCreation")));
@property (class, readonly) SharedKitErrorCode *thumbnailCreationError __attribute__((swift_name("thumbnailCreationError")));
@property (class, readonly) SharedKitErrorCode *errorExtractingMetadata __attribute__((swift_name("errorExtractingMetadata")));
@property (class, readonly) SharedKitErrorCode *errorProcessingVideo __attribute__((swift_name("errorProcessingVideo")));
@property (class, readonly) SharedKitErrorCode *invalidHashAlgorithm __attribute__((swift_name("invalidHashAlgorithm")));
@property (class, readonly) SharedKitErrorCode *invalidPassNullorempty __attribute__((swift_name("invalidPassNullorempty")));
@property (class, readonly) SharedKitErrorCode *invalidRstpFeedAddress __attribute__((swift_name("invalidRstpFeedAddress")));
@property (class, readonly) SharedKitErrorCode *missingPushTopic __attribute__((swift_name("missingPushTopic")));
@property (class, readonly) SharedKitErrorCode *missingGeoLocation __attribute__((swift_name("missingGeoLocation")));
@property (class, readonly) SharedKitErrorCode *missingRequiredBeacon __attribute__((swift_name("missingRequiredBeacon")));
@property (class, readonly) SharedKitErrorCode *requiredField __attribute__((swift_name("requiredField")));
@property (class, readonly) SharedKitErrorCode *toFarAway __attribute__((swift_name("toFarAway")));
@property (class, readonly) SharedKitErrorCode *subscriptionAlreadyCanceled __attribute__((swift_name("subscriptionAlreadyCanceled")));
@property (class, readonly) SharedKitErrorCode *subscriptionAlreadyInProgress __attribute__((swift_name("subscriptionAlreadyInProgress")));
@property (class, readonly) SharedKitErrorCode *alreadyHasSubscriptionActive __attribute__((swift_name("alreadyHasSubscriptionActive")));
@property (class, readonly) SharedKitErrorCode *invalidCode __attribute__((swift_name("invalidCode")));
@property (class, readonly) SharedKitErrorCode *invalidOauthRequest __attribute__((swift_name("invalidOauthRequest")));
@property (class, readonly) SharedKitErrorCode *invalidOauthGrant __attribute__((swift_name("invalidOauthGrant")));
@property (class, readonly) SharedKitErrorCode *invalidSchedule __attribute__((swift_name("invalidSchedule")));
@property (class, readonly) SharedKitErrorCode *invalidProxySizeSpecification __attribute__((swift_name("invalidProxySizeSpecification")));
@property (class, readonly) SharedKitErrorCode *invalidMonitoredServiceUrl __attribute__((swift_name("invalidMonitoredServiceUrl")));
@property (class, readonly) SharedKitErrorCode *invalidEcosystemLabel __attribute__((swift_name("invalidEcosystemLabel")));
@property (class, readonly) SharedKitErrorCode *invalidPropertyName __attribute__((swift_name("invalidPropertyName")));
@property (class, readonly) SharedKitErrorCode *invalidPropertyLevelPath __attribute__((swift_name("invalidPropertyLevelPath")));
@property (class, readonly) SharedKitErrorCode *userNotAuthorized __attribute__((swift_name("userNotAuthorized")));
@property (class, readonly) SharedKitErrorCode *invalidOauthClient __attribute__((swift_name("invalidOauthClient")));
@property (class, readonly) SharedKitErrorCode *forbidden __attribute__((swift_name("forbidden")));
@property (class, readonly) SharedKitErrorCode *invalidRefresh __attribute__((swift_name("invalidRefresh")));
@property (class, readonly) SharedKitErrorCode *invalidUser __attribute__((swift_name("invalidUser")));
@property (class, readonly) SharedKitErrorCode *validationCodeExpired __attribute__((swift_name("validationCodeExpired")));
@property (class, readonly) SharedKitErrorCode *pendingUploadNotFound __attribute__((swift_name("pendingUploadNotFound")));
@property (class, readonly) SharedKitErrorCode *tooManyRequests __attribute__((swift_name("tooManyRequests")));
@property (class, readonly) SharedKitErrorCode *disabledDevice __attribute__((swift_name("disabledDevice")));
@property (class, readonly) SharedKitErrorCode *accessCredentialNotFound __attribute__((swift_name("accessCredentialNotFound")));
@property (class, readonly) SharedKitErrorCode *bookingNotFound __attribute__((swift_name("bookingNotFound")));
@property (class, readonly) SharedKitErrorCode *buildingNotFound __attribute__((swift_name("buildingNotFound")));
@property (class, readonly) SharedKitErrorCode *claimNotFound __attribute__((swift_name("claimNotFound")));
@property (class, readonly) SharedKitErrorCode *configNotFound __attribute__((swift_name("configNotFound")));
@property (class, readonly) SharedKitErrorCode *countryNotFound __attribute__((swift_name("countryNotFound")));
@property (class, readonly) SharedKitErrorCode *chatRoomNotFound __attribute__((swift_name("chatRoomNotFound")));
@property (class, readonly) SharedKitErrorCode *chatMessageNotFound __attribute__((swift_name("chatMessageNotFound")));
@property (class, readonly) SharedKitErrorCode *featureDeviceNotFound __attribute__((swift_name("featureDeviceNotFound")));
@property (class, readonly) SharedKitErrorCode *firmwareVersionNotFound __attribute__((swift_name("firmwareVersionNotFound")));
@property (class, readonly) SharedKitErrorCode *permissionNotFound __attribute__((swift_name("permissionNotFound")));
@property (class, readonly) SharedKitErrorCode *permissionRuleNotFound __attribute__((swift_name("permissionRuleNotFound")));
@property (class, readonly) SharedKitErrorCode *countryTimeZoneNotFound __attribute__((swift_name("countryTimeZoneNotFound")));
@property (class, readonly) SharedKitErrorCode *mediaResourceMultipleNotFound __attribute__((swift_name("mediaResourceMultipleNotFound")));
@property (class, readonly) SharedKitErrorCode *mediaResourceNotFound __attribute__((swift_name("mediaResourceNotFound")));
@property (class, readonly) SharedKitErrorCode *microserviceEntityNotFound __attribute__((swift_name("microserviceEntityNotFound")));
@property (class, readonly) SharedKitErrorCode *priorityCountryNotFound __attribute__((swift_name("priorityCountryNotFound")));
@property (class, readonly) SharedKitErrorCode *spaceNotFound __attribute__((swift_name("spaceNotFound")));
@property (class, readonly) SharedKitErrorCode *roleNotFound __attribute__((swift_name("roleNotFound")));
@property (class, readonly) SharedKitErrorCode *stateNotFound __attribute__((swift_name("stateNotFound")));
@property (class, readonly) SharedKitErrorCode *subscriptionPlanNotFound __attribute__((swift_name("subscriptionPlanNotFound")));
@property (class, readonly) SharedKitErrorCode *subscriptionTypeNotFound __attribute__((swift_name("subscriptionTypeNotFound")));
@property (class, readonly) SharedKitErrorCode *userGroupNotFound __attribute__((swift_name("userGroupNotFound")));
@property (class, readonly) SharedKitErrorCode *userSubscriptionNotFound __attribute__((swift_name("userSubscriptionNotFound")));
@property (class, readonly) SharedKitErrorCode *zipNotFound __attribute__((swift_name("zipNotFound")));
@property (class, readonly) SharedKitErrorCode *politicalProfileNotFound __attribute__((swift_name("politicalProfileNotFound")));
@property (class, readonly) SharedKitErrorCode *professionalProfileNotFound __attribute__((swift_name("professionalProfileNotFound")));
@property (class, readonly) SharedKitErrorCode *sharedProfileNotFound __attribute__((swift_name("sharedProfileNotFound")));
@property (class, readonly) SharedKitErrorCode *politicalPartyNotFound __attribute__((swift_name("politicalPartyNotFound")));
@property (class, readonly) SharedKitErrorCode *committeeNotFound __attribute__((swift_name("committeeNotFound")));
@property (class, readonly) SharedKitErrorCode *salutationNotFound __attribute__((swift_name("salutationNotFound")));
@property (class, readonly) SharedKitErrorCode *subCommitteeNotFound __attribute__((swift_name("subCommitteeNotFound")));
@property (class, readonly) SharedKitErrorCode *socialProfileNotFound __attribute__((swift_name("socialProfileNotFound")));
@property (class, readonly) SharedKitErrorCode *socialUserNotFound __attribute__((swift_name("socialUserNotFound")));
@property (class, readonly) SharedKitErrorCode *socialGroupNotFound __attribute__((swift_name("socialGroupNotFound")));
@property (class, readonly) SharedKitErrorCode *socialEventRegistrationNotFound __attribute__((swift_name("socialEventRegistrationNotFound")));
@property (class, readonly) SharedKitErrorCode *postNotFound __attribute__((swift_name("postNotFound")));
@property (class, readonly) SharedKitErrorCode *commentNotFound __attribute__((swift_name("commentNotFound")));
@property (class, readonly) SharedKitErrorCode *parentCommentNotFound __attribute__((swift_name("parentCommentNotFound")));
@property (class, readonly) SharedKitErrorCode *eventNotFound __attribute__((swift_name("eventNotFound")));
@property (class, readonly) SharedKitErrorCode *zoneNotFound __attribute__((swift_name("zoneNotFound")));
@property (class, readonly) SharedKitErrorCode *friendRequestNotFound __attribute__((swift_name("friendRequestNotFound")));
@property (class, readonly) SharedKitErrorCode *joinRequestNotFound __attribute__((swift_name("joinRequestNotFound")));
@property (class, readonly) SharedKitErrorCode *joinInviteNotFound __attribute__((swift_name("joinInviteNotFound")));
@property (class, readonly) SharedKitErrorCode *friendNotFound __attribute__((swift_name("friendNotFound")));
@property (class, readonly) SharedKitErrorCode *userNotFound __attribute__((swift_name("userNotFound")));
@property (class, readonly) SharedKitErrorCode *customerNotFound __attribute__((swift_name("customerNotFound")));
@property (class, readonly) SharedKitErrorCode *productCategoryNotFound __attribute__((swift_name("productCategoryNotFound")));
@property (class, readonly) SharedKitErrorCode *productCategoryParentNotFound __attribute__((swift_name("productCategoryParentNotFound")));
@property (class, readonly) SharedKitErrorCode *productNotFound __attribute__((swift_name("productNotFound")));
@property (class, readonly) SharedKitErrorCode *shoppingCartNotFound __attribute__((swift_name("shoppingCartNotFound")));
@property (class, readonly) SharedKitErrorCode *taxNotFound __attribute__((swift_name("taxNotFound")));
@property (class, readonly) SharedKitErrorCode *organizationNotfound __attribute__((swift_name("organizationNotfound")));
@property (class, readonly) SharedKitErrorCode *organizationCategoryNotfound __attribute__((swift_name("organizationCategoryNotfound")));
@property (class, readonly) SharedKitErrorCode *organizationBiographyNotfound __attribute__((swift_name("organizationBiographyNotfound")));
@property (class, readonly) SharedKitErrorCode *organizationTypeNotfound __attribute__((swift_name("organizationTypeNotfound")));
@property (class, readonly) SharedKitErrorCode *redirectNotFound __attribute__((swift_name("redirectNotFound")));
@property (class, readonly) SharedKitErrorCode *responsiblePersonNotfound __attribute__((swift_name("responsiblePersonNotfound")));
@property (class, readonly) SharedKitErrorCode *processingJobNotValid __attribute__((swift_name("processingJobNotValid")));
@property (class, readonly) SharedKitErrorCode *mediaProdileNotFound __attribute__((swift_name("mediaProdileNotFound")));
@property (class, readonly) SharedKitErrorCode *mediaProfileTransformationNotFound __attribute__((swift_name("mediaProfileTransformationNotFound")));
@property (class, readonly) SharedKitErrorCode *mediaResourceNotReady __attribute__((swift_name("mediaResourceNotReady")));
@property (class, readonly) SharedKitErrorCode *streamingResourceNotFound __attribute__((swift_name("streamingResourceNotFound")));
@property (class, readonly) SharedKitErrorCode *cameraNotFound __attribute__((swift_name("cameraNotFound")));
@property (class, readonly) SharedKitErrorCode *bridgeNotFound __attribute__((swift_name("bridgeNotFound")));
@property (class, readonly) SharedKitErrorCode *documentNotFound __attribute__((swift_name("documentNotFound")));
@property (class, readonly) SharedKitErrorCode *userPrivacyInfoNotFound __attribute__((swift_name("userPrivacyInfoNotFound")));
@property (class, readonly) SharedKitErrorCode *privacyTermNotFound __attribute__((swift_name("privacyTermNotFound")));
@property (class, readonly) SharedKitErrorCode *legalTopicNotFound __attribute__((swift_name("legalTopicNotFound")));
@property (class, readonly) SharedKitErrorCode *legalTopicHasNoDocuments __attribute__((swift_name("legalTopicHasNoDocuments")));
@property (class, readonly) SharedKitErrorCode *legalDocumentNotFound __attribute__((swift_name("legalDocumentNotFound")));
@property (class, readonly) SharedKitErrorCode *faceNotRecognized __attribute__((swift_name("faceNotRecognized")));
@property (class, readonly) SharedKitErrorCode *cctvEventNotFound __attribute__((swift_name("cctvEventNotFound")));
@property (class, readonly) SharedKitErrorCode *notificationNotFound __attribute__((swift_name("notificationNotFound")));
@property (class, readonly) SharedKitErrorCode *ticketNotFound __attribute__((swift_name("ticketNotFound")));
@property (class, readonly) SharedKitErrorCode *ticketStatusNotFound __attribute__((swift_name("ticketStatusNotFound")));
@property (class, readonly) SharedKitErrorCode *ticketTypeNotFound __attribute__((swift_name("ticketTypeNotFound")));
@property (class, readonly) SharedKitErrorCode *cctvRecordingNotFound __attribute__((swift_name("cctvRecordingNotFound")));
@property (class, readonly) SharedKitErrorCode *vehicleTrackingPlateNotFound __attribute__((swift_name("vehicleTrackingPlateNotFound")));
@property (class, readonly) SharedKitErrorCode *vehicleModelNotFound __attribute__((swift_name("vehicleModelNotFound")));
@property (class, readonly) SharedKitErrorCode *preferredEntityNotFound __attribute__((swift_name("preferredEntityNotFound")));
@property (class, readonly) SharedKitErrorCode *ecosystemNodeNotFound __attribute__((swift_name("ecosystemNodeNotFound")));
@property (class, readonly) SharedKitErrorCode *ecosystemNodeRelationNotFound __attribute__((swift_name("ecosystemNodeRelationNotFound")));
@property (class, readonly) SharedKitErrorCode *locationNotFound __attribute__((swift_name("locationNotFound")));
@property (class, readonly) SharedKitErrorCode *monitoredServiceNotFound __attribute__((swift_name("monitoredServiceNotFound")));
@property (class, readonly) SharedKitErrorCode *propertyNotFound __attribute__((swift_name("propertyNotFound")));
@property (class, readonly) SharedKitErrorCode *ecosystemTemplateNotFound __attribute__((swift_name("ecosystemTemplateNotFound")));
@property (class, readonly) SharedKitErrorCode *meetingNotFound __attribute__((swift_name("meetingNotFound")));
@property (class, readonly) SharedKitErrorCode *chokerNotFound __attribute__((swift_name("chokerNotFound")));
@property (class, readonly) SharedKitErrorCode *locationFilterNotFound __attribute__((swift_name("locationFilterNotFound")));
@property (class, readonly) SharedKitErrorCode *invoiceNotFound __attribute__((swift_name("invoiceNotFound")));
@property (class, readonly) SharedKitErrorCode *creditNoteNotFound __attribute__((swift_name("creditNoteNotFound")));
@property (class, readonly) SharedKitErrorCode *paymentMethodNotFound __attribute__((swift_name("paymentMethodNotFound")));
@property (class, readonly) SharedKitErrorCode *localeNotFound __attribute__((swift_name("localeNotFound")));
@property (class, readonly) SharedKitErrorCode *exportTypeNotFound __attribute__((swift_name("exportTypeNotFound")));
@property (class, readonly) SharedKitErrorCode *duplicatedBuilding __attribute__((swift_name("duplicatedBuilding")));
@property (class, readonly) SharedKitErrorCode *duplicatedCredential __attribute__((swift_name("duplicatedCredential")));
@property (class, readonly) SharedKitErrorCode *duplicatedDevice __attribute__((swift_name("duplicatedDevice")));
@property (class, readonly) SharedKitErrorCode *duplicatedFeaturePermission __attribute__((swift_name("duplicatedFeaturePermission")));
@property (class, readonly) SharedKitErrorCode *duplicatedFirmwareVersion __attribute__((swift_name("duplicatedFirmwareVersion")));
@property (class, readonly) SharedKitErrorCode *duplicatedSpace __attribute__((swift_name("duplicatedSpace")));
@property (class, readonly) SharedKitErrorCode *duplicatedState __attribute__((swift_name("duplicatedState")));
@property (class, readonly) SharedKitErrorCode *duplicatedEmail __attribute__((swift_name("duplicatedEmail")));
@property (class, readonly) SharedKitErrorCode *duplicatedPhone __attribute__((swift_name("duplicatedPhone")));
@property (class, readonly) SharedKitErrorCode *duplicatedSocialProfile __attribute__((swift_name("duplicatedSocialProfile")));
@property (class, readonly) SharedKitErrorCode *duplicatedSocialUser __attribute__((swift_name("duplicatedSocialUser")));
@property (class, readonly) SharedKitErrorCode *duplicatedSocialEventRegistration __attribute__((swift_name("duplicatedSocialEventRegistration")));
@property (class, readonly) SharedKitErrorCode *duplicatedFriend __attribute__((swift_name("duplicatedFriend")));
@property (class, readonly) SharedKitErrorCode *duplicatedFriendRequest __attribute__((swift_name("duplicatedFriendRequest")));
@property (class, readonly) SharedKitErrorCode *duplicatedBelongsTo __attribute__((swift_name("duplicatedBelongsTo")));
@property (class, readonly) SharedKitErrorCode *duplicatedGroupJoinRequest __attribute__((swift_name("duplicatedGroupJoinRequest")));
@property (class, readonly) SharedKitErrorCode *duplicatedGroupJoinInvite __attribute__((swift_name("duplicatedGroupJoinInvite")));
@property (class, readonly) SharedKitErrorCode *duplicatedPriorityCountry __attribute__((swift_name("duplicatedPriorityCountry")));
@property (class, readonly) SharedKitErrorCode *duplicatedPriorityCountryName __attribute__((swift_name("duplicatedPriorityCountryName")));
@property (class, readonly) SharedKitErrorCode *duplicatedPriorityCountrySequence __attribute__((swift_name("duplicatedPriorityCountrySequence")));
@property (class, readonly) SharedKitErrorCode *duplicatedSubscriptionType __attribute__((swift_name("duplicatedSubscriptionType")));
@property (class, readonly) SharedKitErrorCode *buildingDeleteWithChildren __attribute__((swift_name("buildingDeleteWithChildren")));
@property (class, readonly) SharedKitErrorCode *priorityCountryDeleteActive __attribute__((swift_name("priorityCountryDeleteActive")));
@property (class, readonly) SharedKitErrorCode *duplicatedShoppingCart __attribute__((swift_name("duplicatedShoppingCart")));
@property (class, readonly) SharedKitErrorCode *duplicatedCustomerEmail __attribute__((swift_name("duplicatedCustomerEmail")));
@property (class, readonly) SharedKitErrorCode *duplicatedCustomerVatId __attribute__((swift_name("duplicatedCustomerVatId")));
@property (class, readonly) SharedKitErrorCode *duplicatedProductCategory __attribute__((swift_name("duplicatedProductCategory")));
@property (class, readonly) SharedKitErrorCode *duplicatedProduct __attribute__((swift_name("duplicatedProduct")));
@property (class, readonly) SharedKitErrorCode *duplicatedRedirectLink __attribute__((swift_name("duplicatedRedirectLink")));
@property (class, readonly) SharedKitErrorCode *duplicatedResourceDomain __attribute__((swift_name("duplicatedResourceDomain")));
@property (class, readonly) SharedKitErrorCode *duplicatedStoreCategory __attribute__((swift_name("duplicatedStoreCategory")));
@property (class, readonly) SharedKitErrorCode *duplicatedStore __attribute__((swift_name("duplicatedStore")));
@property (class, readonly) SharedKitErrorCode *duplicatedCommittee __attribute__((swift_name("duplicatedCommittee")));
@property (class, readonly) SharedKitErrorCode *duplicatedSalutation __attribute__((swift_name("duplicatedSalutation")));
@property (class, readonly) SharedKitErrorCode *duplicatedPoliticalParty __attribute__((swift_name("duplicatedPoliticalParty")));
@property (class, readonly) SharedKitErrorCode *duplicatedSharedProfile __attribute__((swift_name("duplicatedSharedProfile")));
@property (class, readonly) SharedKitErrorCode *duplicatedTax __attribute__((swift_name("duplicatedTax")));
@property (class, readonly) SharedKitErrorCode *duplicatedUser __attribute__((swift_name("duplicatedUser")));
@property (class, readonly) SharedKitErrorCode *duplicatedUserInGroup __attribute__((swift_name("duplicatedUserInGroup")));
@property (class, readonly) SharedKitErrorCode *duplicatedUserGroup __attribute__((swift_name("duplicatedUserGroup")));
@property (class, readonly) SharedKitErrorCode *childAsParent __attribute__((swift_name("childAsParent")));
@property (class, readonly) SharedKitErrorCode *organizationDuplicated __attribute__((swift_name("organizationDuplicated")));
@property (class, readonly) SharedKitErrorCode *organizationTypeDuplicated __attribute__((swift_name("organizationTypeDuplicated")));
@property (class, readonly) SharedKitErrorCode *organizationCategoryDuplicated __attribute__((swift_name("organizationCategoryDuplicated")));
@property (class, readonly) SharedKitErrorCode *mediaProfileDuplicated __attribute__((swift_name("mediaProfileDuplicated")));
@property (class, readonly) SharedKitErrorCode *mediaProfileTransformationsDuplicated __attribute__((swift_name("mediaProfileTransformationsDuplicated")));
@property (class, readonly) SharedKitErrorCode *mediaDuplicatedForSameEntity __attribute__((swift_name("mediaDuplicatedForSameEntity")));
@property (class, readonly) SharedKitErrorCode *cameraDuplicated __attribute__((swift_name("cameraDuplicated")));
@property (class, readonly) SharedKitErrorCode *documentDuplicated __attribute__((swift_name("documentDuplicated")));
@property (class, readonly) SharedKitErrorCode *duplicatedUserPrivacyInfo __attribute__((swift_name("duplicatedUserPrivacyInfo")));
@property (class, readonly) SharedKitErrorCode *userPrivacyDataInProcess __attribute__((swift_name("userPrivacyDataInProcess")));
@property (class, readonly) SharedKitErrorCode *duplicatedPrivacyTerm __attribute__((swift_name("duplicatedPrivacyTerm")));
@property (class, readonly) SharedKitErrorCode *duplicatedLegalTopic __attribute__((swift_name("duplicatedLegalTopic")));
@property (class, readonly) SharedKitErrorCode *duplicatedLegalDocument __attribute__((swift_name("duplicatedLegalDocument")));
@property (class, readonly) SharedKitErrorCode *duplicatedClientId __attribute__((swift_name("duplicatedClientId")));
@property (class, readonly) SharedKitErrorCode *duplicatedTicket __attribute__((swift_name("duplicatedTicket")));
@property (class, readonly) SharedKitErrorCode *duplicatedTicketStatus __attribute__((swift_name("duplicatedTicketStatus")));
@property (class, readonly) SharedKitErrorCode *duplicatedTicketType __attribute__((swift_name("duplicatedTicketType")));
@property (class, readonly) SharedKitErrorCode *duplicatedVehicleTrackingUser __attribute__((swift_name("duplicatedVehicleTrackingUser")));
@property (class, readonly) SharedKitErrorCode *duplicatedVehicleTrackingPlate __attribute__((swift_name("duplicatedVehicleTrackingPlate")));
@property (class, readonly) SharedKitErrorCode *duplicatedZone __attribute__((swift_name("duplicatedZone")));
@property (class, readonly) SharedKitErrorCode *preferredEntityDuplicated __attribute__((swift_name("preferredEntityDuplicated")));
@property (class, readonly) SharedKitErrorCode *snManagerRoleAlreadyAssigned __attribute__((swift_name("snManagerRoleAlreadyAssigned")));
@property (class, readonly) SharedKitErrorCode *duplicatedEcosystemNode __attribute__((swift_name("duplicatedEcosystemNode")));
@property (class, readonly) SharedKitErrorCode *duplicatedEcosystemNodeRelation __attribute__((swift_name("duplicatedEcosystemNodeRelation")));
@property (class, readonly) SharedKitErrorCode *duplicatedLocation __attribute__((swift_name("duplicatedLocation")));
@property (class, readonly) SharedKitErrorCode *duplicatedProperty __attribute__((swift_name("duplicatedProperty")));
@property (class, readonly) SharedKitErrorCode *multipleDeletePropertyMatches __attribute__((swift_name("multipleDeletePropertyMatches")));
@property (class, readonly) SharedKitErrorCode *duplicatedEcosystemTemplate __attribute__((swift_name("duplicatedEcosystemTemplate")));
@property (class, readonly) SharedKitErrorCode *duplicatedEcosystemTemplateProperty __attribute__((swift_name("duplicatedEcosystemTemplateProperty")));
@property (class, readonly) SharedKitErrorCode *duplicatedLocationFilter __attribute__((swift_name("duplicatedLocationFilter")));
@property (class, readonly) SharedKitErrorCode *duplicatedUserDevice __attribute__((swift_name("duplicatedUserDevice")));
@property (class, readonly) SharedKitErrorCode *duplicatedEditorRole __attribute__((swift_name("duplicatedEditorRole")));
@property (class, readonly) SharedKitErrorCode *activeCommittee __attribute__((swift_name("activeCommittee")));
@property (class, readonly) SharedKitErrorCode *bookingNotHappeningNow __attribute__((swift_name("bookingNotHappeningNow")));
@property (class, readonly) SharedKitErrorCode *invalidDates __attribute__((swift_name("invalidDates")));
@property (class, readonly) SharedKitErrorCode *endDateBeforeStartDate __attribute__((swift_name("endDateBeforeStartDate")));
@property (class, readonly) SharedKitErrorCode *invalidMediaProxy __attribute__((swift_name("invalidMediaProxy")));
@property (class, readonly) SharedKitErrorCode *requiredMediaProxy __attribute__((swift_name("requiredMediaProxy")));
@property (class, readonly) SharedKitErrorCode *spaceAlreadyBooked __attribute__((swift_name("spaceAlreadyBooked")));
@property (class, readonly) SharedKitErrorCode *tooManyAttendees __attribute__((swift_name("tooManyAttendees")));
@property (class, readonly) SharedKitErrorCode *closedFriendRequest __attribute__((swift_name("closedFriendRequest")));
@property (class, readonly) SharedKitErrorCode *productCategoryAddSelf __attribute__((swift_name("productCategoryAddSelf")));
@property (class, readonly) SharedKitErrorCode *productCategoryDelete __attribute__((swift_name("productCategoryDelete")));
@property (class, readonly) SharedKitErrorCode *productNotReadyForSale __attribute__((swift_name("productNotReadyForSale")));
@property (class, readonly) SharedKitErrorCode *missingEndDate __attribute__((swift_name("missingEndDate")));
@property (class, readonly) SharedKitErrorCode *missingOtherSocialMediaType __attribute__((swift_name("missingOtherSocialMediaType")));
@property (class, readonly) SharedKitErrorCode *socialGroupMinimumManagers __attribute__((swift_name("socialGroupMinimumManagers")));
@property (class, readonly) SharedKitErrorCode *snRemoveSelfManager __attribute__((swift_name("snRemoveSelfManager")));
@property (class, readonly) SharedKitErrorCode *snManagerRoleRequired __attribute__((swift_name("snManagerRoleRequired")));
@property (class, readonly) SharedKitErrorCode *socialGroupNotPublic __attribute__((swift_name("socialGroupNotPublic")));
@property (class, readonly) SharedKitErrorCode *socialUserNotGroupMember __attribute__((swift_name("socialUserNotGroupMember")));
@property (class, readonly) SharedKitErrorCode *socialEventStartDateLocked __attribute__((swift_name("socialEventStartDateLocked")));
@property (class, readonly) SharedKitErrorCode *socialEventAlreadyOccurred __attribute__((swift_name("socialEventAlreadyOccurred")));
@property (class, readonly) SharedKitErrorCode *socialEventInvalidGuestsNumber __attribute__((swift_name("socialEventInvalidGuestsNumber")));
@property (class, readonly) SharedKitErrorCode *socialEventMaxOccupancy __attribute__((swift_name("socialEventMaxOccupancy")));
@property (class, readonly) SharedKitErrorCode *privatePostHasNoTarget __attribute__((swift_name("privatePostHasNoTarget")));
@property (class, readonly) SharedKitErrorCode *invalidFriendRequest __attribute__((swift_name("invalidFriendRequest")));
@property (class, readonly) SharedKitErrorCode *invalidParentCommentDepth __attribute__((swift_name("invalidParentCommentDepth")));
@property (class, readonly) SharedKitErrorCode *organizationInUse __attribute__((swift_name("organizationInUse")));
@property (class, readonly) SharedKitErrorCode *addressMissing __attribute__((swift_name("addressMissing")));
@property (class, readonly) SharedKitErrorCode *profileStillInUse __attribute__((swift_name("profileStillInUse")));
@property (class, readonly) SharedKitErrorCode *invalidVideoSize __attribute__((swift_name("invalidVideoSize")));
@property (class, readonly) SharedKitErrorCode *streamingError __attribute__((swift_name("streamingError")));
@property (class, readonly) SharedKitErrorCode *cameraNotRecording __attribute__((swift_name("cameraNotRecording")));
@property (class, readonly) SharedKitErrorCode *cameraNotStreaming __attribute__((swift_name("cameraNotStreaming")));
@property (class, readonly) SharedKitErrorCode *chatOwnerCannotRemoveHimself __attribute__((swift_name("chatOwnerCannotRemoveHimself")));
@property (class, readonly) SharedKitErrorCode *chatParticipantsAreNotEnough __attribute__((swift_name("chatParticipantsAreNotEnough")));
@property (class, readonly) SharedKitErrorCode *addAndRemoveSameChatParticipant __attribute__((swift_name("addAndRemoveSameChatParticipant")));
@property (class, readonly) SharedKitErrorCode *createMeetingWithoutOwner __attribute__((swift_name("createMeetingWithoutOwner")));
@property (class, readonly) SharedKitErrorCode *folderWithChildrenCannotBeDeleted __attribute__((swift_name("folderWithChildrenCannotBeDeleted")));
@property (class, readonly) SharedKitErrorCode *roleCannotBeAssigned __attribute__((swift_name("roleCannotBeAssigned")));
@property (class, readonly) SharedKitErrorCode *byteRangeNotExpected __attribute__((swift_name("byteRangeNotExpected")));
@property (class, readonly) SharedKitErrorCode *invalidByteRange __attribute__((swift_name("invalidByteRange")));
@property (class, readonly) SharedKitErrorCode *cannotUpdateChatName __attribute__((swift_name("cannotUpdateChatName")));
@property (class, readonly) SharedKitErrorCode *cannotUpdateChatCover __attribute__((swift_name("cannotUpdateChatCover")));
@property (class, readonly) SharedKitErrorCode *cannotAddParticipantsToGroup __attribute__((swift_name("cannotAddParticipantsToGroup")));
@property (class, readonly) SharedKitErrorCode *chatroomMustHaveAtLeastOneAdmin __attribute__((swift_name("chatroomMustHaveAtLeastOneAdmin")));
@property (class, readonly) SharedKitErrorCode *chatroomWith2participantsCannotHaveName __attribute__((swift_name("chatroomWith2participantsCannotHaveName")));
@property (class, readonly) SharedKitErrorCode *spaceWithChildren __attribute__((swift_name("spaceWithChildren")));
@property (class, readonly) SharedKitErrorCode *startDateCannotBeChangedToPast __attribute__((swift_name("startDateCannotBeChangedToPast")));
@property (class, readonly) SharedKitErrorCode *invalidRedirectLink __attribute__((swift_name("invalidRedirectLink")));
@property (class, readonly) SharedKitErrorCode *invalidMqttUsername __attribute__((swift_name("invalidMqttUsername")));
@property (class, readonly) SharedKitErrorCode *invalidFirmwareVersion __attribute__((swift_name("invalidFirmwareVersion")));
@property (class, readonly) SharedKitErrorCode *rulesOnlyOnWrite __attribute__((swift_name("rulesOnlyOnWrite")));
@property (class, readonly) SharedKitErrorCode *emptySchedule __attribute__((swift_name("emptySchedule")));
@property (class, readonly) SharedKitErrorCode *userPrivacyDataExportTooOften __attribute__((swift_name("userPrivacyDataExportTooOften")));
@property (class, readonly) SharedKitErrorCode *unsupportedCurrency __attribute__((swift_name("unsupportedCurrency")));
@property (class, readonly) SharedKitErrorCode *emailMissing __attribute__((swift_name("emailMissing")));
@property (class, readonly) SharedKitErrorCode *invalidSubscriptionPlanChange __attribute__((swift_name("invalidSubscriptionPlanChange")));
@property (class, readonly) SharedKitErrorCode *missingDimmerConfig __attribute__((swift_name("missingDimmerConfig")));
@property (class, readonly) SharedKitErrorCode *missingRelayConfig __attribute__((swift_name("missingRelayConfig")));
@property (class, readonly) SharedKitErrorCode *missingRelayPinInputTwo __attribute__((swift_name("missingRelayPinInputTwo")));
@property (class, readonly) SharedKitErrorCode *missingPinRelayTwo __attribute__((swift_name("missingPinRelayTwo")));
@property (class, readonly) SharedKitErrorCode *duplicatedPinConfig __attribute__((swift_name("duplicatedPinConfig")));
@property (class, readonly) SharedKitErrorCode *deviceNotFound __attribute__((swift_name("deviceNotFound")));
@property (class, readonly) SharedKitErrorCode *errorProcessingFace __attribute__((swift_name("errorProcessingFace")));
@property (class, readonly) SharedKitErrorCode *invalidPictureNoFaceFound __attribute__((swift_name("invalidPictureNoFaceFound")));
@property (class, readonly) SharedKitErrorCode *invalidPictureMoreThan1FaceFound __attribute__((swift_name("invalidPictureMoreThan1FaceFound")));
@property (class, readonly) SharedKitErrorCode *errorDeletingFace __attribute__((swift_name("errorDeletingFace")));
@property (class, readonly) SharedKitErrorCode *invalidTenantConfiguration __attribute__((swift_name("invalidTenantConfiguration")));
@property (class, readonly) SharedKitErrorCode *missingLegalDocumentMediaResources __attribute__((swift_name("missingLegalDocumentMediaResources")));
@property (class, readonly) SharedKitErrorCode *missingDescriptionOtherGender __attribute__((swift_name("missingDescriptionOtherGender")));
@property (class, readonly) SharedKitErrorCode *subscriptionTypeInUse __attribute__((swift_name("subscriptionTypeInUse")));
@property (class, readonly) SharedKitErrorCode *invalidSubscriptionPlanPrice __attribute__((swift_name("invalidSubscriptionPlanPrice")));
@property (class, readonly) SharedKitErrorCode *salutationInUse __attribute__((swift_name("salutationInUse")));
@property (class, readonly) SharedKitErrorCode *deleteInitialTicketStatus __attribute__((swift_name("deleteInitialTicketStatus")));
@property (class, readonly) SharedKitErrorCode *invalidPeriodDuration __attribute__((swift_name("invalidPeriodDuration")));
@property (class, readonly) SharedKitErrorCode *unsupportedClaim __attribute__((swift_name("unsupportedClaim")));
@property (class, readonly) SharedKitErrorCode *parentAndChildSelected __attribute__((swift_name("parentAndChildSelected")));
@property (class, readonly) SharedKitErrorCode *invalidPreferredTypeContext __attribute__((swift_name("invalidPreferredTypeContext")));
@property (class, readonly) SharedKitErrorCode *dailyRepetitionWithoutWeekdays __attribute__((swift_name("dailyRepetitionWithoutWeekdays")));
@property (class, readonly) SharedKitErrorCode *deviceFeatureNotActionable __attribute__((swift_name("deviceFeatureNotActionable")));
@property (class, readonly) SharedKitErrorCode *invalidDeviceCommand __attribute__((swift_name("invalidDeviceCommand")));
@property (class, readonly) SharedKitErrorCode *duplicatedRoleName __attribute__((swift_name("duplicatedRoleName")));
@property (class, readonly) SharedKitErrorCode *rolelessUsers __attribute__((swift_name("rolelessUsers")));
@property (class, readonly) SharedKitErrorCode *cannotDeleteDefaultRole __attribute__((swift_name("cannotDeleteDefaultRole")));
@property (class, readonly) SharedKitErrorCode *backofficeInoperabilityError __attribute__((swift_name("backofficeInoperabilityError")));
@property (class, readonly) SharedKitErrorCode *invalidPhoneNumber __attribute__((swift_name("invalidPhoneNumber")));
@property (class, readonly) SharedKitErrorCode *regionNotSupported __attribute__((swift_name("regionNotSupported")));
@property (class, readonly) SharedKitErrorCode *accessCredentialExpired __attribute__((swift_name("accessCredentialExpired")));
@property (class, readonly) SharedKitErrorCode *nonRuledSocialGroup __attribute__((swift_name("nonRuledSocialGroup")));
@property (class, readonly) SharedKitErrorCode *locationFilterOrderOutOfBounds __attribute__((swift_name("locationFilterOrderOutOfBounds")));
@property (class, readonly) SharedKitErrorCode *indexOrderOutOfBounds __attribute__((swift_name("indexOrderOutOfBounds")));
@property (class, readonly) SharedKitErrorCode *invalidCircularRelation __attribute__((swift_name("invalidCircularRelation")));
@property (class, readonly) SharedKitErrorCode *propertyProtected __attribute__((swift_name("propertyProtected")));
@property (class, readonly) SharedKitErrorCode *nonRefundableInvoice __attribute__((swift_name("nonRefundableInvoice")));
@property (class, readonly) SharedKitErrorCode *invalidCreditNoteAmount __attribute__((swift_name("invalidCreditNoteAmount")));
@property (class, readonly) SharedKitErrorCode *noPaymentMethod __attribute__((swift_name("noPaymentMethod")));
@property (class, readonly) SharedKitErrorCode *invalidStatus __attribute__((swift_name("invalidStatus")));
@property (class, readonly) SharedKitErrorCode *ecosystemProtectedNode __attribute__((swift_name("ecosystemProtectedNode")));
@property (class, readonly) SharedKitErrorCode *subscriptionPlanHasPendingPayments __attribute__((swift_name("subscriptionPlanHasPendingPayments")));
@property (class, readonly) SharedKitErrorCode *internalServerError __attribute__((swift_name("internalServerError")));
@property (class, readonly) SharedKitErrorCode *badGateway __attribute__((swift_name("badGateway")));
@property (class, readonly) SharedKitErrorCode *deviceOffline __attribute__((swift_name("deviceOffline")));
@property (class, readonly) SharedKitErrorCode *optimisticLock __attribute__((swift_name("optimisticLock")));
+ (SharedKitKotlinArray<SharedKitErrorCode *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t httpCode __attribute__((swift_name("httpCode")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nExportType")))
@interface SharedKitI18nExportType : SharedKitKotlinEnum<SharedKitI18nExportType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitI18nExportType *ios __attribute__((swift_name("ios")));
@property (class, readonly) SharedKitI18nExportType *android __attribute__((swift_name("android")));
@property (class, readonly) SharedKitI18nExportType *web __attribute__((swift_name("web")));
+ (SharedKitKotlinArray<SharedKitI18nExportType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationResourceType")))
@interface SharedKitNotificationResourceType : SharedKitKotlinEnum<SharedKitNotificationResourceType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitNotificationResourceType *camera __attribute__((swift_name("camera")));
@property (class, readonly) SharedKitNotificationResourceType *chatMessage __attribute__((swift_name("chatMessage")));
@property (class, readonly) SharedKitNotificationResourceType *all __attribute__((swift_name("all")));
+ (SharedKitKotlinArray<SharedKitNotificationResourceType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationType")))
@interface SharedKitNotificationType : SharedKitKotlinEnum<SharedKitNotificationType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitNotificationType *silent __attribute__((swift_name("silent")));
@property (class, readonly) SharedKitNotificationType *alert __attribute__((swift_name("alert")));
@property (class, readonly) SharedKitNotificationType *voip __attribute__((swift_name("voip")));
+ (SharedKitKotlinArray<SharedKitNotificationType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotifyTransportType")))
@interface SharedKitNotifyTransportType : SharedKitKotlinEnum<SharedKitNotifyTransportType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitNotifyTransportType *sse __attribute__((swift_name("sse")));
@property (class, readonly) SharedKitNotifyTransportType *pushNotification __attribute__((swift_name("pushNotification")));
@property (class, readonly) SharedKitNotifyTransportType *sms __attribute__((swift_name("sms")));
+ (SharedKitKotlinArray<SharedKitNotifyTransportType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyMessageAction")))
@interface SharedKitPrivacyMessageAction : SharedKitKotlinEnum<SharedKitPrivacyMessageAction *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPrivacyMessageAction *request __attribute__((swift_name("request")));
@property (class, readonly) SharedKitPrivacyMessageAction *acknowledge __attribute__((swift_name("acknowledge")));
@property (class, readonly) SharedKitPrivacyMessageAction *acknowledgeSuccess __attribute__((swift_name("acknowledgeSuccess")));
@property (class, readonly) SharedKitPrivacyMessageAction *acknowledgeFailure __attribute__((swift_name("acknowledgeFailure")));
+ (SharedKitKotlinArray<SharedKitPrivacyMessageAction *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyAgent")))
@interface SharedKitPropertyAgent : SharedKitKotlinEnum<SharedKitPropertyAgent *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPropertyAgent *dev __attribute__((swift_name("dev")));
@property (class, readonly) SharedKitPropertyAgent *platformAdmin __attribute__((swift_name("platformAdmin")));
@property (class, readonly) SharedKitPropertyAgent *user __attribute__((swift_name("user")));
+ (SharedKitKotlinArray<SharedKitPropertyAgent *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyCategory")))
@interface SharedKitPropertyCategory : SharedKitKotlinEnum<SharedKitPropertyCategory *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPropertyCategory *notifications __attribute__((swift_name("notifications")));
@property (class, readonly) SharedKitPropertyCategory *subscriptions __attribute__((swift_name("subscriptions")));
@property (class, readonly) SharedKitPropertyCategory *settings __attribute__((swift_name("settings")));
+ (SharedKitKotlinArray<SharedKitPropertyCategory *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyFilter")))
@interface SharedKitPropertyFilter : SharedKitKotlinEnum<SharedKitPropertyFilter *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPropertyFilter *agent __attribute__((swift_name("agent")));
@property (class, readonly) SharedKitPropertyFilter *scope __attribute__((swift_name("scope")));
@property (class, readonly) SharedKitPropertyFilter *module __attribute__((swift_name("module")));
@property (class, readonly) SharedKitPropertyFilter *category __attribute__((swift_name("category")));
@property (class, readonly) SharedKitPropertyFilter *propertyLevel __attribute__((swift_name("propertyLevel")));
+ (SharedKitKotlinArray<SharedKitPropertyFilter *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyScope")))
@interface SharedKitPropertyScope : SharedKitKotlinEnum<SharedKitPropertyScope *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPropertyScope *web __attribute__((swift_name("web")));
@property (class, readonly) SharedKitPropertyScope *ios __attribute__((swift_name("ios")));
@property (class, readonly) SharedKitPropertyScope *android __attribute__((swift_name("android")));
@property (class, readonly) SharedKitPropertyScope *server __attribute__((swift_name("server")));
@property (class, readonly) SharedKitPropertyScope *client __attribute__((swift_name("client")));
@property (class, readonly) SharedKitPropertyScope *all __attribute__((swift_name("all")));
+ (SharedKitKotlinArray<SharedKitPropertyScope *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyType")))
@interface SharedKitPropertyType : SharedKitKotlinEnum<SharedKitPropertyType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPropertyType *string __attribute__((swift_name("string")));
@property (class, readonly) SharedKitPropertyType *integer __attribute__((swift_name("integer")));
@property (class, readonly) SharedKitPropertyType *float_ __attribute__((swift_name("float_")));
@property (class, readonly) SharedKitPropertyType *boolean __attribute__((swift_name("boolean")));
@property (class, readonly) SharedKitPropertyType *list __attribute__((swift_name("list")));
@property (class, readonly) SharedKitPropertyType *custom __attribute__((swift_name("custom")));
+ (SharedKitKotlinArray<SharedKitPropertyType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageSeverity")))
@interface SharedKitPushMessageSeverity : SharedKitKotlinEnum<SharedKitPushMessageSeverity *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKitPushMessageSeverityCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SharedKitPushMessageSeverity *info __attribute__((swift_name("info")));
@property (class, readonly) SharedKitPushMessageSeverity *warning __attribute__((swift_name("warning")));
@property (class, readonly) SharedKitPushMessageSeverity *danger __attribute__((swift_name("danger")));
+ (SharedKitKotlinArray<SharedKitPushMessageSeverity *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t severityCode __attribute__((swift_name("severityCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageSeverity.Companion")))
@interface SharedKitPushMessageSeverityCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushMessageSeverityCompanion *shared __attribute__((swift_name("shared")));

/**
 * @note annotations
 *   kotlin.jvm.JvmStatic
*/
- (SharedKitPushMessageSeverity * _Nullable)getBySeverityCodeSeverityCode:(int32_t)severityCode __attribute__((swift_name("getBySeverityCode(severityCode:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageType")))
@interface SharedKitPushMessageType : SharedKitKotlinEnum<SharedKitPushMessageType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPushMessageType *mediaBackgroundProcessing __attribute__((swift_name("mediaBackgroundProcessing")));
@property (class, readonly) SharedKitPushMessageType *welcome __attribute__((swift_name("welcome")));
@property (class, readonly) SharedKitPushMessageType *genericAlert __attribute__((swift_name("genericAlert")));
@property (class, readonly) SharedKitPushMessageType *genericSilent __attribute__((swift_name("genericSilent")));
@property (class, readonly) SharedKitPushMessageType *userNotificationCenterUpdate __attribute__((swift_name("userNotificationCenterUpdate")));
@property (class, readonly) SharedKitPushMessageType *socialUserCreate __attribute__((swift_name("socialUserCreate")));
@property (class, readonly) SharedKitPushMessageType *friendRequest __attribute__((swift_name("friendRequest")));
@property (class, readonly) SharedKitPushMessageType *groupJoinRequest __attribute__((swift_name("groupJoinRequest")));
@property (class, readonly) SharedKitPushMessageType *groupJoinInvite __attribute__((swift_name("groupJoinInvite")));
@property (class, readonly) SharedKitPushMessageType *acceptedFriendRequest __attribute__((swift_name("acceptedFriendRequest")));
@property (class, readonly) SharedKitPushMessageType *acceptedJoinRequest __attribute__((swift_name("acceptedJoinRequest")));
@property (class, readonly) SharedKitPushMessageType *acceptedJoinInvite __attribute__((swift_name("acceptedJoinInvite")));
@property (class, readonly) SharedKitPushMessageType *socialGroupManagerRoleGranted __attribute__((swift_name("socialGroupManagerRoleGranted")));
@property (class, readonly) SharedKitPushMessageType *socialGroupManagerRoleRemoved __attribute__((swift_name("socialGroupManagerRoleRemoved")));
@property (class, readonly) SharedKitPushMessageType *socialGroupMembershipRemoved __attribute__((swift_name("socialGroupMembershipRemoved")));
@property (class, readonly) SharedKitPushMessageType *socialGroupCreated __attribute__((swift_name("socialGroupCreated")));
@property (class, readonly) SharedKitPushMessageType *socialGroupCoverEdit __attribute__((swift_name("socialGroupCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *socialGroupAvatarEdit __attribute__((swift_name("socialGroupAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType *postCreated __attribute__((swift_name("postCreated")));
@property (class, readonly) SharedKitPushMessageType *postAddMedia __attribute__((swift_name("postAddMedia")));
@property (class, readonly) SharedKitPushMessageType *eventCreated __attribute__((swift_name("eventCreated")));
@property (class, readonly) SharedKitPushMessageType *eventAddMedia __attribute__((swift_name("eventAddMedia")));
@property (class, readonly) SharedKitPushMessageType *eventCoverEdit __attribute__((swift_name("eventCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *eventScheduleReminder __attribute__((swift_name("eventScheduleReminder")));
@property (class, readonly) SharedKitPushMessageType *chatRoomChange __attribute__((swift_name("chatRoomChange")));
@property (class, readonly) SharedKitPushMessageType *chatRoomRemove __attribute__((swift_name("chatRoomRemove")));
@property (class, readonly) SharedKitPushMessageType *chatBoardChange __attribute__((swift_name("chatBoardChange")));
@property (class, readonly) SharedKitPushMessageType *chatMeetingCreated __attribute__((swift_name("chatMeetingCreated")));
@property (class, readonly) SharedKitPushMessageType *chatMeetingCreationError __attribute__((swift_name("chatMeetingCreationError")));
@property (class, readonly) SharedKitPushMessageType *chatMessagePublished __attribute__((swift_name("chatMessagePublished")));
@property (class, readonly) SharedKitPushMessageType *chatWebrtcMessagePublished __attribute__((swift_name("chatWebrtcMessagePublished")));
@property (class, readonly) SharedKitPushMessageType *chatStatusMessagePublished __attribute__((swift_name("chatStatusMessagePublished")));
@property (class, readonly) SharedKitPushMessageType *cctvAiEvent __attribute__((swift_name("cctvAiEvent")));
@property (class, readonly) SharedKitPushMessageType *cctvLicensePlateEvent __attribute__((swift_name("cctvLicensePlateEvent")));
@property (class, readonly) SharedKitPushMessageType *organizationsOrganizationCreated __attribute__((swift_name("organizationsOrganizationCreated")));
@property (class, readonly) SharedKitPushMessageType *organizationsOrganizationLogoEdit __attribute__((swift_name("organizationsOrganizationLogoEdit")));
@property (class, readonly) SharedKitPushMessageType *organizationsOrganizationCoverEdit __attribute__((swift_name("organizationsOrganizationCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *organizationsOrganizationNewMedia __attribute__((swift_name("organizationsOrganizationNewMedia")));
@property (class, readonly) SharedKitPushMessageType *organizationsResponsiblePersonCreate __attribute__((swift_name("organizationsResponsiblePersonCreate")));
@property (class, readonly) SharedKitPushMessageType *organizationsResponsiblePersonPictureUpdate __attribute__((swift_name("organizationsResponsiblePersonPictureUpdate")));
@property (class, readonly) SharedKitPushMessageType *profilesSocialProfileUpdate __attribute__((swift_name("profilesSocialProfileUpdate")));
@property (class, readonly) SharedKitPushMessageType *profilesSocialProfileAvatarEdit __attribute__((swift_name("profilesSocialProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesSocialProfileCoverEdit __attribute__((swift_name("profilesSocialProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesSocialProfileAddMedia __attribute__((swift_name("profilesSocialProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType *profilesPoliticalProfileCreate __attribute__((swift_name("profilesPoliticalProfileCreate")));
@property (class, readonly) SharedKitPushMessageType *profilesPoliticalProfileAvatarEdit __attribute__((swift_name("profilesPoliticalProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesPoliticalProfileCoverEdit __attribute__((swift_name("profilesPoliticalProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesPoliticalProfileAddMedia __attribute__((swift_name("profilesPoliticalProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType *profilesProfessionalProfileCreate __attribute__((swift_name("profilesProfessionalProfileCreate")));
@property (class, readonly) SharedKitPushMessageType *profilesProfessionalProfileAvatarEdit __attribute__((swift_name("profilesProfessionalProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesProfessionalProfileCoverEdit __attribute__((swift_name("profilesProfessionalProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesProfessionalProfileAddMedia __attribute__((swift_name("profilesProfessionalProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType *profilesSharedProfileCreate __attribute__((swift_name("profilesSharedProfileCreate")));
@property (class, readonly) SharedKitPushMessageType *profilesSharedProfileAvatarEdit __attribute__((swift_name("profilesSharedProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesSharedProfileCoverEdit __attribute__((swift_name("profilesSharedProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType *profilesSharedProfileAddMedia __attribute__((swift_name("profilesSharedProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType *iotStateUpdateEvent __attribute__((swift_name("iotStateUpdateEvent")));
@property (class, readonly) SharedKitPushMessageType *iotMacroTriggeredEvent __attribute__((swift_name("iotMacroTriggeredEvent")));
@property (class, readonly) SharedKitPushMessageType *iotPropertyTriggeredEvent __attribute__((swift_name("iotPropertyTriggeredEvent")));
@property (class, readonly) SharedKitPushMessageType *iotCreateFirmwareVersion __attribute__((swift_name("iotCreateFirmwareVersion")));
@property (class, readonly) SharedKitPushMessageType *iotZoneCreate __attribute__((swift_name("iotZoneCreate")));
@property (class, readonly) SharedKitPushMessageType *iotZoneUploadMedias __attribute__((swift_name("iotZoneUploadMedias")));
@property (class, readonly) SharedKitPushMessageType *iotUserGroupCreate __attribute__((swift_name("iotUserGroupCreate")));
@property (class, readonly) SharedKitPushMessageType *iotUserGroupUploadMedia __attribute__((swift_name("iotUserGroupUploadMedia")));
@property (class, readonly) SharedKitPushMessageType *cameraStreamReady __attribute__((swift_name("cameraStreamReady")));
@property (class, readonly) SharedKitPushMessageType *cameraActionResponse __attribute__((swift_name("cameraActionResponse")));
@property (class, readonly) SharedKitPushMessageType *cctvAi __attribute__((swift_name("cctvAi")));
@property (class, readonly) SharedKitPushMessageType *cctvLicensePlate __attribute__((swift_name("cctvLicensePlate")));
@property (class, readonly) SharedKitPushMessageType *documentMediaReady __attribute__((swift_name("documentMediaReady")));
@property (class, readonly) SharedKitPushMessageType *legalDocumentCreate __attribute__((swift_name("legalDocumentCreate")));
@property (class, readonly) SharedKitPushMessageType *legalDocumentAddDocument __attribute__((swift_name("legalDocumentAddDocument")));
@property (class, readonly) SharedKitPushMessageType *ticketingCreate __attribute__((swift_name("ticketingCreate")));
@property (class, readonly) SharedKitPushMessageType *ticketingAddMedia __attribute__((swift_name("ticketingAddMedia")));
@property (class, readonly) SharedKitPushMessageType *ticketingCommentCreate __attribute__((swift_name("ticketingCommentCreate")));
@property (class, readonly) SharedKitPushMessageType *sharedSpacesBuildingCreate __attribute__((swift_name("sharedSpacesBuildingCreate")));
@property (class, readonly) SharedKitPushMessageType *sharedSpacesBuildingAddMedia __attribute__((swift_name("sharedSpacesBuildingAddMedia")));
@property (class, readonly) SharedKitPushMessageType *sharedSpacesSpaceCreate __attribute__((swift_name("sharedSpacesSpaceCreate")));
@property (class, readonly) SharedKitPushMessageType *sharedSpacesSpaceAddMedia __attribute__((swift_name("sharedSpacesSpaceAddMedia")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsCreated __attribute__((swift_name("subscriptionsCreated")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsEnded __attribute__((swift_name("subscriptionsEnded")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsPlanCanceled __attribute__((swift_name("subscriptionsPlanCanceled")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsPaymentFailure __attribute__((swift_name("subscriptionsPaymentFailure")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsIncomingPayment __attribute__((swift_name("subscriptionsIncomingPayment")));
@property (class, readonly) SharedKitPushMessageType *subscriptionsImpendingCancellation __attribute__((swift_name("subscriptionsImpendingCancellation")));
@property (class, readonly) SharedKitPushMessageType *genericAll __attribute__((swift_name("genericAll")));
@property (class, readonly) SharedKitPushMessageType *genericMetrics __attribute__((swift_name("genericMetrics")));
@property (class, readonly) SharedKitPushMessageType *genericState __attribute__((swift_name("genericState")));
+ (SharedKitKotlinArray<SharedKitPushMessageType *> *)values __attribute__((swift_name("values()")));
@property (readonly) BOOL persistable __attribute__((swift_name("persistable")));
@property (readonly) SharedKitPushMessageSeverity *severity __attribute__((swift_name("severity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Role")))
@interface SharedKitRole : SharedKitKotlinEnum<SharedKitRole *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) SharedKitRoleCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) SharedKitRole *admin __attribute__((swift_name("admin")));
@property (class, readonly) SharedKitRole *user __attribute__((swift_name("user")));
@property (class, readonly) SharedKitRole *internal __attribute__((swift_name("internal")));
@property (class, readonly) SharedKitRole *editor __attribute__((swift_name("editor")));
@property (class, readonly) SharedKitRole *accesscredential __attribute__((swift_name("accesscredential")));
@property (class, readonly) SharedKitRole *mediaViewer __attribute__((swift_name("mediaViewer")));
@property (class, readonly) SharedKitRole *devicecredential __attribute__((swift_name("devicecredential")));
+ (SharedKitKotlinArray<SharedKitRole *> *)values __attribute__((swift_name("values()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Role.Companion")))
@interface SharedKitRoleCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitRoleCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *ACCESSCREDENTIALROLE __attribute__((swift_name("ACCESSCREDENTIALROLE")));
@property (readonly) NSString *ADMINROLE __attribute__((swift_name("ADMINROLE")));
@property (readonly) NSString *DEVICECREDENTIALROLE __attribute__((swift_name("DEVICECREDENTIALROLE")));
@property (readonly) NSString *EDITORROLE __attribute__((swift_name("EDITORROLE")));
@property (readonly) NSString *INTERNALROLE __attribute__((swift_name("INTERNALROLE")));
@property (readonly) NSString *MEDIAVIEWERROLE __attribute__((swift_name("MEDIAVIEWERROLE")));
@property (readonly) NSString *USERROLE __attribute__((swift_name("USERROLE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SharedEntityType")))
@interface SharedKitSharedEntityType : SharedKitKotlinEnum<SharedKitSharedEntityType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitSharedEntityType *politicalProfile __attribute__((swift_name("politicalProfile")));
@property (class, readonly) SharedKitSharedEntityType *organization __attribute__((swift_name("organization")));
+ (SharedKitKotlinArray<SharedKitSharedEntityType *> *)values __attribute__((swift_name("values()")));
@property (readonly) SharedKitUserClaimScope *scope __attribute__((swift_name("scope")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaType")))
@interface SharedKitSocialMediaType : SharedKitKotlinEnum<SharedKitSocialMediaType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitSocialMediaType *other __attribute__((swift_name("other")));
@property (class, readonly) SharedKitSocialMediaType *facebook __attribute__((swift_name("facebook")));
@property (class, readonly) SharedKitSocialMediaType *youtube __attribute__((swift_name("youtube")));
@property (class, readonly) SharedKitSocialMediaType *instagram __attribute__((swift_name("instagram")));
@property (class, readonly) SharedKitSocialMediaType *tiktok __attribute__((swift_name("tiktok")));
@property (class, readonly) SharedKitSocialMediaType *snapchat __attribute__((swift_name("snapchat")));
@property (class, readonly) SharedKitSocialMediaType *pinterest __attribute__((swift_name("pinterest")));
@property (class, readonly) SharedKitSocialMediaType *reddit __attribute__((swift_name("reddit")));
@property (class, readonly) SharedKitSocialMediaType *twitter __attribute__((swift_name("twitter")));
@property (class, readonly) SharedKitSocialMediaType *linkedin __attribute__((swift_name("linkedin")));
+ (SharedKitKotlinArray<SharedKitSocialMediaType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalRepetitionType")))
@interface SharedKitTemporalRepetitionType : SharedKitKotlinEnum<SharedKitTemporalRepetitionType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitTemporalRepetitionType *days __attribute__((swift_name("days")));
@property (class, readonly) SharedKitTemporalRepetitionType *weeks __attribute__((swift_name("weeks")));
@property (class, readonly) SharedKitTemporalRepetitionType *months __attribute__((swift_name("months")));
@property (class, readonly) SharedKitTemporalRepetitionType *years __attribute__((swift_name("years")));
+ (SharedKitKotlinArray<SharedKitTemporalRepetitionType *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserClaimScope")))
@interface SharedKitUserClaimScope : SharedKitKotlinEnum<SharedKitUserClaimScope *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitUserClaimScope *mediaRead __attribute__((swift_name("mediaRead")));
@property (class, readonly) SharedKitUserClaimScope *mediaWrite __attribute__((swift_name("mediaWrite")));
@property (class, readonly) SharedKitUserClaimScope *cctvStream __attribute__((swift_name("cctvStream")));
@property (class, readonly) SharedKitUserClaimScope *cctvRecord __attribute__((swift_name("cctvRecord")));
@property (class, readonly) SharedKitUserClaimScope *cctvTakeScreenshot __attribute__((swift_name("cctvTakeScreenshot")));
@property (class, readonly) SharedKitUserClaimScope *cctvViewScreenshot __attribute__((swift_name("cctvViewScreenshot")));
@property (class, readonly) SharedKitUserClaimScope *iotZonePermission __attribute__((swift_name("iotZonePermission")));
@property (class, readonly) SharedKitUserClaimScope *sharedProfilesPoliticalProfileEditor __attribute__((swift_name("sharedProfilesPoliticalProfileEditor")));
@property (class, readonly) SharedKitUserClaimScope *sharedProfilesOrganizationEditor __attribute__((swift_name("sharedProfilesOrganizationEditor")));
+ (SharedKitKotlinArray<SharedKitUserClaimScope *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol SharedKitKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol SharedKitKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol SharedKitKotlinx_serialization_coreKSerializer <SharedKitKotlinx_serialization_coreSerializationStrategy, SharedKitKotlinx_serialization_coreDeserializationStrategy>
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AnySerializer")))
@interface SharedKitAnySerializer : SharedKitBase <SharedKitKotlinx_serialization_coreKSerializer>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id _Nullable)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DateSerializer")))
@interface SharedKitDateSerializer : SharedKitBase <SharedKitKotlinx_serialization_coreKSerializer>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedKitKotlinx_datetimeLocalDate *)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(SharedKitKotlinx_datetimeLocalDate *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Headers")))
@interface SharedKitHeaders : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)headers __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitHeaders *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *AUTHORIZATION __attribute__((swift_name("AUTHORIZATION")));
@property (readonly) NSString *X_APPLICATION_LANGUAGE __attribute__((swift_name("X_APPLICATION_LANGUAGE")));
@property (readonly) NSString *X_APPLICATION_NAME __attribute__((swift_name("X_APPLICATION_NAME")));
@property (readonly) NSString *X_CLIENT_PLATFORM_NAME __attribute__((swift_name("X_CLIENT_PLATFORM_NAME")));
@property (readonly) NSString *X_CLIENT_PLATFORM_VERSION __attribute__((swift_name("X_CLIENT_PLATFORM_VERSION")));
@property (readonly) NSString *X_CLIENT_TIMEZONE __attribute__((swift_name("X_CLIENT_TIMEZONE")));
@property (readonly) NSString *X_DEVICE_PUSH_SANDBOX __attribute__((swift_name("X_DEVICE_PUSH_SANDBOX")));
@property (readonly) NSString *X_DEVICE_TOKEN_PUSH __attribute__((swift_name("X_DEVICE_TOKEN_PUSH")));
@property (readonly) NSString *X_DEVICE_UUID __attribute__((swift_name("X_DEVICE_UUID")));
@property (readonly) NSString *X_FILE_NAME __attribute__((swift_name("X_FILE_NAME")));
@property (readonly) NSString *X_FILE_SIZE __attribute__((swift_name("X_FILE_SIZE")));
@property (readonly) NSString *X_MASK_ID __attribute__((swift_name("X_MASK_ID")));
@property (readonly) NSString *X_MEDIA_PROFILE __attribute__((swift_name("X_MEDIA_PROFILE")));
@property (readonly) NSString *X_MEDIA_UPLOAD_ITEM __attribute__((swift_name("X_MEDIA_UPLOAD_ITEM")));
@property (readonly) NSString *X_MEDIA_UPLOAD_MODULE __attribute__((swift_name("X_MEDIA_UPLOAD_MODULE")));
@property (readonly) NSString *X_MEDIA_UPLOAD_TYPE __attribute__((swift_name("X_MEDIA_UPLOAD_TYPE")));
@property (readonly) NSString *X_MEDIA_VIEWPORT __attribute__((swift_name("X_MEDIA_VIEWPORT")));
@property (readonly) NSString *X_MEDIA_VISIBILITY __attribute__((swift_name("X_MEDIA_VISIBILITY")));
@property (readonly) NSString *X_PAGINATION_NEXT __attribute__((swift_name("X_PAGINATION_NEXT")));
@property (readonly) NSString *X_PUSH_ENDPOINT __attribute__((swift_name("X_PUSH_ENDPOINT")));
@property (readonly) NSString *X_PUSH_VOIP __attribute__((swift_name("X_PUSH_VOIP")));
@property (readonly) NSString *X_REFRESH_TOKEN __attribute__((swift_name("X_REFRESH_TOKEN")));
@property (readonly) NSString *X_TENANT_ID __attribute__((swift_name("X_TENANT_ID")));
@property (readonly) NSString *X_TOTAL_COUNT __attribute__((swift_name("X_TOTAL_COUNT")));
@property (readonly) NSString *X_USERID __attribute__((swift_name("X_USERID")));
@property (readonly) NSString *X_USER_COUNTRY __attribute__((swift_name("X_USER_COUNTRY")));
@property (readonly) NSString *X_USER_LANGUAGE __attribute__((swift_name("X_USER_LANGUAGE")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("HourSerializer")))
@interface SharedKitHourSerializer : SharedKitBase <SharedKitKotlinx_serialization_coreKSerializer>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedKitKotlinx_datetimeInstant *)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(SharedKitKotlinx_datetimeInstant *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaConstants")))
@interface SharedKitMediaConstants : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)mediaConstants __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMediaConstants *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *METADATA __attribute__((swift_name("METADATA")));
@property (readonly) NSString *THUMBNAIL __attribute__((swift_name("THUMBNAIL")));
@property (readonly) NSString *TRANSCODING __attribute__((swift_name("TRANSCODING")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaConstants.STATUS")))
@interface SharedKitMediaConstantsSTATUS : SharedKitKotlinEnum<SharedKitMediaConstantsSTATUS *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMediaConstantsSTATUS *error __attribute__((swift_name("error")));
@property (class, readonly) SharedKitMediaConstantsSTATUS *done __attribute__((swift_name("done")));
@property (class, readonly) SharedKitMediaConstantsSTATUS *processing __attribute__((swift_name("processing")));
+ (SharedKitKotlinArray<SharedKitMediaConstantsSTATUS *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaProcessingStatus")))
@interface SharedKitMediaProcessingStatus : SharedKitKotlinEnum<SharedKitMediaProcessingStatus *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitMediaProcessingStatus *error __attribute__((swift_name("error")));
@property (class, readonly) SharedKitMediaProcessingStatus *done __attribute__((swift_name("done")));
@property (class, readonly) SharedKitMediaProcessingStatus *processing __attribute__((swift_name("processing")));
+ (SharedKitKotlinArray<SharedKitMediaProcessingStatus *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeSerializer")))
@interface SharedKitTimeSerializer : SharedKitBase <SharedKitKotlinx_serialization_coreKSerializer>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedKitKotlinx_datetimeInstant *)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(SharedKitKotlinx_datetimeInstant *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UuidSerializer")))
@interface SharedKitUuidSerializer : SharedKitBase <SharedKitKotlinx_serialization_coreKSerializer>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedKitUuidUuid *)deserializeDecoder:(id<SharedKitKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
- (void)serializeEncoder:(id<SharedKitKotlinx_serialization_coreEncoder>)encoder value:(SharedKitUuidUuid *)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKitKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Values")))
@interface SharedKitValues : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)values __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitValues *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *BASE_URL_REGEX __attribute__((swift_name("BASE_URL_REGEX")));
@property (readonly) NSString *DATE_TIME_ISO_8601 __attribute__((swift_name("DATE_TIME_ISO_8601")));
@property (readonly) NSString *DATE_TIME_MILLIS_UTC __attribute__((swift_name("DATE_TIME_MILLIS_UTC")));
@property (readonly) NSString *EMAIL_REGEX __attribute__((swift_name("EMAIL_REGEX")));
@property (readonly) NSString *HTTPS_REGEX __attribute__((swift_name("HTTPS_REGEX")));
@property (readonly) NSString *HTTPS_REGEX_WITH_QUERY_PARAM __attribute__((swift_name("HTTPS_REGEX_WITH_QUERY_PARAM")));
@property (readonly) NSString *HTTPS_REGEX_WITH_RESOURCE __attribute__((swift_name("HTTPS_REGEX_WITH_RESOURCE")));
@property (readonly) NSString *IPV4_REGEX __attribute__((swift_name("IPV4_REGEX")));
@property (readonly) NSString *LOCAL_TIME __attribute__((swift_name("LOCAL_TIME")));
@property (readonly) NSString *SCHEDULE_REGEX __attribute__((swift_name("SCHEDULE_REGEX")));
@property (readonly) NSString *URL_REGEX __attribute__((swift_name("URL_REGEX")));
@property (readonly) NSString *URL_REGEX_WITH_QUERY_PARAM __attribute__((swift_name("URL_REGEX_WITH_QUERY_PARAM")));
@property (readonly) NSString *URL_REGEX_WITH_RESOURCE __attribute__((swift_name("URL_REGEX_WITH_RESOURCE")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Alert")))
@interface SharedKitAlert : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithBody:(NSString *)body title:(NSString *)title __attribute__((swift_name("init(body:title:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAlertCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAlert *)doCopyBody:(NSString *)body title:(NSString *)title __attribute__((swift_name("doCopy(body:title:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *body __attribute__((swift_name("body")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Alert.Companion")))
@interface SharedKitAlertCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAlertCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Aps")))
@interface SharedKitAps : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithAlert:(SharedKitAlert * _Nullable)alert badge:(SharedKitLong * _Nullable)badge __attribute__((swift_name("init(alert:badge:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitApsCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAps *)doCopyAlert:(SharedKitAlert * _Nullable)alert badge:(SharedKitLong * _Nullable)badge __attribute__((swift_name("doCopy(alert:badge:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKitAlert * _Nullable alert __attribute__((swift_name("alert")));
@property (readonly) SharedKitLong * _Nullable badge __attribute__((swift_name("badge")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Aps.Companion")))
@interface SharedKitApsCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitApsCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorDto")))
@interface SharedKitErrorDto : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithName:(NSString *)name obj:(NSString *)obj constraint:(NSString *)constraint message:(NSString *)message value:(NSString *)value min:(SharedKitLong * _Nullable)min max:(SharedKitLong * _Nullable)max __attribute__((swift_name("init(name:obj:constraint:message:value:min:max:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitErrorDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitErrorDto *)doCopyName:(NSString *)name obj:(NSString *)obj constraint:(NSString *)constraint message:(NSString *)message value:(NSString *)value min:(SharedKitLong * _Nullable)min max:(SharedKitLong * _Nullable)max __attribute__((swift_name("doCopy(name:obj:constraint:message:value:min:max:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *constraint __attribute__((swift_name("constraint")));
@property (readonly) SharedKitLong * _Nullable max __attribute__((swift_name("max")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@property (readonly) SharedKitLong * _Nullable min __attribute__((swift_name("min")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *obj __attribute__((swift_name("obj")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ErrorDto.Companion")))
@interface SharedKitErrorDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitErrorDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NameValuePairDto")))
@interface SharedKitNameValuePairDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name value:(NSString * _Nullable)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitNameValuePairDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitNameValuePairDto *)doCopyName:(NSString * _Nullable)name value:(NSString * _Nullable)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NameValuePairDto.Companion")))
@interface SharedKitNameValuePairDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitNameValuePairDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageDto")))
@interface SharedKitPushMessageDto : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithBadge:(int64_t)badge aps:(SharedKitAps * _Nullable)aps messageType:(NSString *)messageType type:(NSString * _Nullable)type extra:(NSString *)extra topic:(NSString * _Nullable)topic __attribute__((swift_name("init(badge:aps:messageType:type:extra:topic:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPushMessageDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPushMessageDto *)doCopyBadge:(int64_t)badge aps:(SharedKitAps * _Nullable)aps messageType:(NSString *)messageType type:(NSString * _Nullable)type extra:(NSString *)extra topic:(NSString * _Nullable)topic __attribute__((swift_name("doCopy(badge:aps:messageType:type:extra:topic:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKitAps * _Nullable aps __attribute__((swift_name("aps")));
@property (readonly) int64_t badge __attribute__((swift_name("badge")));
@property (readonly) NSString *extra __attribute__((swift_name("extra")));
@property (readonly) NSString *messageType __attribute__((swift_name("messageType")));
@property (readonly) NSString * _Nullable topic __attribute__((swift_name("topic")));
@property (readonly) NSString * _Nullable type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageDto.Companion")))
@interface SharedKitPushMessageDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushMessageDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageMediaDto")))
@interface SharedKitPushMessageMediaDto : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithDate:(NSString *)date event:(NSString *)event id:(NSString *)id status:(NSString *)status type:(NSString * _Nullable)type __attribute__((swift_name("init(date:event:id:status:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPushMessageMediaDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPushMessageMediaDto *)doCopyDate:(NSString *)date event:(NSString *)event id:(NSString *)id status:(NSString *)status type:(NSString * _Nullable)type __attribute__((swift_name("doCopy(date:event:id:status:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *date __attribute__((swift_name("date")));
@property (readonly) NSString *event __attribute__((swift_name("event")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString *status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageMediaDto.Companion")))
@interface SharedKitPushMessageMediaDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushMessageMediaDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageTypeDto")))
@interface SharedKitPushMessageTypeDto : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithMessageType:(SharedKitPushMessageType *)messageType type:(NSString *)type extra:(NSString *)extra topic:(NSString *)topic __attribute__((swift_name("init(messageType:type:extra:topic:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPushMessageTypeDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPushMessageTypeDto *)doCopyMessageType:(SharedKitPushMessageType *)messageType type:(NSString *)type extra:(NSString *)extra topic:(NSString *)topic __attribute__((swift_name("doCopy(messageType:type:extra:topic:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *extra __attribute__((swift_name("extra")));
@property (readonly) SharedKitPushMessageType *messageType __attribute__((swift_name("messageType")));
@property (readonly) NSString *topic __attribute__((swift_name("topic")));
@property (readonly) NSString *type __attribute__((swift_name("type")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageTypeDto.Companion")))
@interface SharedKitPushMessageTypeDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushMessageTypeDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushRequestFriendDto")))
@interface SharedKitPushRequestFriendDto : SharedKitBase
- (instancetype)initWithCreatedAt:(NSString * _Nullable)createdAt requestedUser:(SharedKitPushRequestedUserDto * _Nullable)requestedUser requesterUser:(SharedKitPushRequestedUserDto * _Nullable)requesterUser status:(NSString * _Nullable)status uuid:(NSString * _Nullable)uuid __attribute__((swift_name("init(createdAt:requestedUser:requesterUser:status:uuid:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPushRequestFriendDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPushRequestFriendDto *)doCopyCreatedAt:(NSString * _Nullable)createdAt requestedUser:(SharedKitPushRequestedUserDto * _Nullable)requestedUser requesterUser:(SharedKitPushRequestedUserDto * _Nullable)requesterUser status:(NSString * _Nullable)status uuid:(NSString * _Nullable)uuid __attribute__((swift_name("doCopy(createdAt:requestedUser:requesterUser:status:uuid:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) SharedKitPushRequestedUserDto * _Nullable requestedUser __attribute__((swift_name("requestedUser")));
@property (readonly) SharedKitPushRequestedUserDto * _Nullable requesterUser __attribute__((swift_name("requesterUser")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) NSString * _Nullable uuid __attribute__((swift_name("uuid")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushRequestFriendDto.Companion")))
@interface SharedKitPushRequestFriendDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushRequestFriendDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushRequestedUserDto")))
@interface SharedKitPushRequestedUserDto : SharedKitBase
- (instancetype)initWithActive:(SharedKitBoolean * _Nullable)active avatarUrl:(NSString * _Nullable)avatarUrl createdAt:(NSString * _Nullable)createdAt nickname:(NSString * _Nullable)nickname profileId:(SharedKitLong * _Nullable)profileId title:(NSString * _Nullable)title updatedAt:(NSString * _Nullable)updatedAt userId:(SharedKitLong * _Nullable)userId uuid:(NSString * _Nullable)uuid __attribute__((swift_name("init(active:avatarUrl:createdAt:nickname:profileId:title:updatedAt:userId:uuid:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPushRequestedUserDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPushRequestedUserDto *)doCopyActive:(SharedKitBoolean * _Nullable)active avatarUrl:(NSString * _Nullable)avatarUrl createdAt:(NSString * _Nullable)createdAt nickname:(NSString * _Nullable)nickname profileId:(SharedKitLong * _Nullable)profileId title:(NSString * _Nullable)title updatedAt:(NSString * _Nullable)updatedAt userId:(SharedKitLong * _Nullable)userId uuid:(NSString * _Nullable)uuid __attribute__((swift_name("doCopy(active:avatarUrl:createdAt:nickname:profileId:title:updatedAt:userId:uuid:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property NSString * _Nullable avatarUrl __attribute__((swift_name("avatarUrl")));
@property (readonly) NSString * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property (readonly) NSString * _Nullable nickname __attribute__((swift_name("nickname")));
@property (readonly) SharedKitLong * _Nullable profileId __attribute__((swift_name("profileId")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString * _Nullable updatedAt __attribute__((swift_name("updatedAt")));
@property (readonly) SharedKitLong * _Nullable userId __attribute__((swift_name("userId")));
@property (readonly) NSString * _Nullable uuid __attribute__((swift_name("uuid")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushRequestedUserDto.Companion")))
@interface SharedKitPushRequestedUserDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPushRequestedUserDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResponseErrorDto")))
@interface SharedKitResponseErrorDto : SharedKitBase <SharedKitParcelable>
- (instancetype)initWithErrors:(NSArray<SharedKitErrorDto *> *)errors message:(NSString *)message __attribute__((swift_name("init(errors:message:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitResponseErrorDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitResponseErrorDto *)doCopyErrors:(NSArray<SharedKitErrorDto *> *)errors message:(NSString *)message __attribute__((swift_name("doCopy(errors:message:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SharedKitErrorDto *> *errors __attribute__((swift_name("errors")));
@property (readonly) NSString *message __attribute__((swift_name("message")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ResponseErrorDto.Companion")))
@interface SharedKitResponseErrorDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitResponseErrorDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateActiveDto")))
@interface SharedKitUpdateActiveDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithActive:(SharedKitBoolean * _Nullable)active __attribute__((swift_name("init(active:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUpdateActiveDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUpdateActiveDto *)doCopyActive:(SharedKitBoolean * _Nullable)active __attribute__((swift_name("doCopy(active:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UpdateActiveDto.Companion")))
@interface SharedKitUpdateActiveDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUpdateActiveDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCodeLoginDto")))
@interface SharedKitAccessCredentialCodeLoginDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCode:(NSString * _Nullable)code __attribute__((swift_name("init(code:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAccessCredentialCodeLoginDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAccessCredentialCodeLoginDto *)doCopyCode:(NSString * _Nullable)code __attribute__((swift_name("doCopy(code:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCodeLoginDto.Companion")))
@interface SharedKitAccessCredentialCodeLoginDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAccessCredentialCodeLoginDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCreateDto")))
@interface SharedKitAccessCredentialCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithActive:(BOOL)active firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName phone:(NSString * _Nullable)phone phoneCountryCode:(NSString * _Nullable)phoneCountryCode email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodCreateDto * _Nullable)temporalPeriod accessClaims:(NSArray<SharedKitCredentialClaimCreateDto *> *)accessClaims __attribute__((swift_name("init(active:firstName:lastName:phone:phoneCountryCode:email:temporalPeriod:accessClaims:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAccessCredentialCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAccessCredentialCreateDto *)doCopyActive:(BOOL)active firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName phone:(NSString * _Nullable)phone phoneCountryCode:(NSString * _Nullable)phoneCountryCode email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodCreateDto * _Nullable)temporalPeriod accessClaims:(NSArray<SharedKitCredentialClaimCreateDto *> *)accessClaims __attribute__((swift_name("doCopy(active:firstName:lastName:phone:phoneCountryCode:email:temporalPeriod:accessClaims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSArray<SharedKitCredentialClaimCreateDto *> *accessClaims __attribute__((swift_name("accessClaims")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSString * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property SharedKitTemporalPeriodCreateDto * _Nullable temporalPeriod __attribute__((swift_name("temporalPeriod")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCreateDto.Companion")))
@interface SharedKitAccessCredentialCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAccessCredentialCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCreateInternalDto")))
@interface SharedKitAccessCredentialCreateInternalDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithActive:(BOOL)active grantedAccessById:(SharedKitLong * _Nullable)grantedAccessById firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName phone:(NSString * _Nullable)phone phoneCountryCode:(NSString * _Nullable)phoneCountryCode email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodCreateDto * _Nullable)temporalPeriod accessClaims:(NSArray<SharedKitCredentialClaimCreateDto *> *)accessClaims __attribute__((swift_name("init(active:grantedAccessById:firstName:lastName:phone:phoneCountryCode:email:temporalPeriod:accessClaims:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAccessCredentialCreateInternalDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAccessCredentialCreateInternalDto *)doCopyActive:(BOOL)active grantedAccessById:(SharedKitLong * _Nullable)grantedAccessById firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName phone:(NSString * _Nullable)phone phoneCountryCode:(NSString * _Nullable)phoneCountryCode email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodCreateDto * _Nullable)temporalPeriod accessClaims:(NSArray<SharedKitCredentialClaimCreateDto *> *)accessClaims __attribute__((swift_name("doCopy(active:grantedAccessById:firstName:lastName:phone:phoneCountryCode:email:temporalPeriod:accessClaims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSArray<SharedKitCredentialClaimCreateDto *> *accessClaims __attribute__((swift_name("accessClaims")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property SharedKitLong * _Nullable grantedAccessById __attribute__((swift_name("grantedAccessById")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSString * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property SharedKitTemporalPeriodCreateDto * _Nullable temporalPeriod __attribute__((swift_name("temporalPeriod")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialCreateInternalDto.Companion")))
@interface SharedKitAccessCredentialCreateInternalDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAccessCredentialCreateInternalDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialPreviewDto")))
@interface SharedKitAccessCredentialPreviewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id active:(BOOL)active phoneLength:(int32_t)phoneLength phoneLastFourDigits:(NSString *)phoneLastFourDigits phoneCountryCode:(int32_t)phoneCountryCode firstName:(NSString *)firstName lastName:(NSString *)lastName periodExpired:(BOOL)periodExpired periodActive:(BOOL)periodActive temporalPeriod:(SharedKitTemporalPeriodViewDto *)temporalPeriod __attribute__((swift_name("init(id:active:phoneLength:phoneLastFourDigits:phoneCountryCode:firstName:lastName:periodExpired:periodActive:temporalPeriod:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAccessCredentialPreviewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAccessCredentialPreviewDto *)doCopyId:(SharedKitLong * _Nullable)id active:(BOOL)active phoneLength:(int32_t)phoneLength phoneLastFourDigits:(NSString *)phoneLastFourDigits phoneCountryCode:(int32_t)phoneCountryCode firstName:(NSString *)firstName lastName:(NSString *)lastName periodExpired:(BOOL)periodExpired periodActive:(BOOL)periodActive temporalPeriod:(SharedKitTemporalPeriodViewDto *)temporalPeriod __attribute__((swift_name("doCopy(id:active:phoneLength:phoneLastFourDigits:phoneCountryCode:firstName:lastName:periodExpired:periodActive:temporalPeriod:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString *firstName __attribute__((swift_name("firstName")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString *lastName __attribute__((swift_name("lastName")));
@property BOOL periodActive __attribute__((swift_name("periodActive")));
@property BOOL periodExpired __attribute__((swift_name("periodExpired")));
@property int32_t phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString *phoneLastFourDigits __attribute__((swift_name("phoneLastFourDigits")));
@property int32_t phoneLength __attribute__((swift_name("phoneLength")));
@property SharedKitTemporalPeriodViewDto *temporalPeriod __attribute__((swift_name("temporalPeriod")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialPreviewDto.Companion")))
@interface SharedKitAccessCredentialPreviewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAccessCredentialPreviewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialViewDto")))
@interface SharedKitAccessCredentialViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt grantedAccessById:(int64_t)grantedAccessById grantedAccessByFullName:(NSString *)grantedAccessByFullName active:(BOOL)active firstName:(NSString *)firstName lastName:(NSString *)lastName phone:(NSString *)phone phoneCountryCode:(int32_t)phoneCountryCode phoneCountryCodeString:(NSString *)phoneCountryCodeString email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodViewDto *)temporalPeriod accessClaims:(NSArray<SharedKitUserClaimViewDto *> *)accessClaims __attribute__((swift_name("init(id:createdAt:updatedAt:grantedAccessById:grantedAccessByFullName:active:firstName:lastName:phone:phoneCountryCode:phoneCountryCodeString:email:temporalPeriod:accessClaims:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAccessCredentialViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAccessCredentialViewDto *)doCopyId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt grantedAccessById:(int64_t)grantedAccessById grantedAccessByFullName:(NSString *)grantedAccessByFullName active:(BOOL)active firstName:(NSString *)firstName lastName:(NSString *)lastName phone:(NSString *)phone phoneCountryCode:(int32_t)phoneCountryCode phoneCountryCodeString:(NSString *)phoneCountryCodeString email:(NSString * _Nullable)email temporalPeriod:(SharedKitTemporalPeriodViewDto *)temporalPeriod accessClaims:(NSArray<SharedKitUserClaimViewDto *> *)accessClaims __attribute__((swift_name("doCopy(id:createdAt:updatedAt:grantedAccessById:grantedAccessByFullName:active:firstName:lastName:phone:phoneCountryCode:phoneCountryCodeString:email:temporalPeriod:accessClaims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSArray<SharedKitUserClaimViewDto *> *accessClaims __attribute__((swift_name("accessClaims")));
@property BOOL active __attribute__((swift_name("active")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString *firstName __attribute__((swift_name("firstName")));
@property NSString *grantedAccessByFullName __attribute__((swift_name("grantedAccessByFullName")));
@property int64_t grantedAccessById __attribute__((swift_name("grantedAccessById")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString *lastName __attribute__((swift_name("lastName")));
@property NSString *phone __attribute__((swift_name("phone")));
@property int32_t phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString *phoneCountryCodeString __attribute__((swift_name("phoneCountryCodeString")));
@property SharedKitTemporalPeriodViewDto *temporalPeriod __attribute__((swift_name("temporalPeriod")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable updatedAt __attribute__((swift_name("updatedAt")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AccessCredentialViewDto.Companion")))
@interface SharedKitAccessCredentialViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAccessCredentialViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialClaimCreateDto")))
@interface SharedKitCredentialClaimCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithClaimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("init(claimScope:objectId:claimReference:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitCredentialClaimCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitCredentialClaimCreateDto *)doCopyClaimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("doCopy(claimScope:objectId:claimReference:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable claimReference __attribute__((swift_name("claimReference")));
@property SharedKitUserClaimScope * _Nullable claimScope __attribute__((swift_name("claimScope")));
@property NSString * _Nullable objectId __attribute__((swift_name("objectId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CredentialClaimCreateDto.Companion")))
@interface SharedKitCredentialClaimCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitCredentialClaimCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PhoneChangeConfirmation")))
@interface SharedKitPhoneChangeConfirmation : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithNewPhoneNumber:(NSString * _Nullable)newPhoneNumber countryCode:(NSString * _Nullable)countryCode confirmationCode:(NSString * _Nullable)confirmationCode __attribute__((swift_name("init(newPhoneNumber:countryCode:confirmationCode:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPhoneChangeConfirmationCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPhoneChangeConfirmation *)doCopyNewPhoneNumber:(NSString * _Nullable)newPhoneNumber countryCode:(NSString * _Nullable)countryCode confirmationCode:(NSString * _Nullable)confirmationCode __attribute__((swift_name("doCopy(newPhoneNumber:countryCode:confirmationCode:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable confirmationCode __attribute__((swift_name("confirmationCode")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property (getter=doNewPhoneNumber) NSString * _Nullable newPhoneNumber __attribute__((swift_name("newPhoneNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PhoneChangeConfirmation.Companion")))
@interface SharedKitPhoneChangeConfirmationCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPhoneChangeConfirmationCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestCodeDto")))
@interface SharedKitRequestCodeDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString * _Nullable)countryCode phoneNumber:(NSString * _Nullable)phoneNumber token:(NSString * _Nullable)token __attribute__((swift_name("init(countryCode:phoneNumber:token:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitRequestCodeDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitRequestCodeDto *)doCopyCountryCode:(NSString * _Nullable)countryCode phoneNumber:(NSString * _Nullable)phoneNumber token:(NSString * _Nullable)token __attribute__((swift_name("doCopy(countryCode:phoneNumber:token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RequestCodeDto.Companion")))
@interface SharedKitRequestCodeDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitRequestCodeDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DBConnectionCreateDto")))
@interface SharedKitDBConnectionCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithTenantId:(NSString * _Nullable)tenantId hostIp:(NSString * _Nullable)hostIp port:(int32_t)port databaseName:(NSString * _Nullable)databaseName username:(NSString * _Nullable)username password:(NSString * _Nullable)password poolingEnabled:(BOOL)poolingEnabled databaseEncoding:(NSString *)databaseEncoding databaseCollation:(NSString *)databaseCollation databaseCType:(NSString *)databaseCType __attribute__((swift_name("init(tenantId:hostIp:port:databaseName:username:password:poolingEnabled:databaseEncoding:databaseCollation:databaseCType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitDBConnectionCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitDBConnectionCreateDto *)doCopyTenantId:(NSString * _Nullable)tenantId hostIp:(NSString * _Nullable)hostIp port:(int32_t)port databaseName:(NSString * _Nullable)databaseName username:(NSString * _Nullable)username password:(NSString * _Nullable)password poolingEnabled:(BOOL)poolingEnabled databaseEncoding:(NSString *)databaseEncoding databaseCollation:(NSString *)databaseCollation databaseCType:(NSString *)databaseCType __attribute__((swift_name("doCopy(tenantId:hostIp:port:databaseName:username:password:poolingEnabled:databaseEncoding:databaseCollation:databaseCType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *databaseCType __attribute__((swift_name("databaseCType")));
@property NSString *databaseCollation __attribute__((swift_name("databaseCollation")));
@property NSString *databaseEncoding __attribute__((swift_name("databaseEncoding")));
@property NSString * _Nullable databaseName __attribute__((swift_name("databaseName")));
@property NSString * _Nullable hostIp __attribute__((swift_name("hostIp")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property BOOL poolingEnabled __attribute__((swift_name("poolingEnabled")));
@property int32_t port __attribute__((swift_name("port")));
@property NSString * _Nullable tenantId __attribute__((swift_name("tenantId")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DBConnectionCreateDto.Companion")))
@interface SharedKitDBConnectionCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitDBConnectionCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DBConnectionViewDto")))
@interface SharedKitDBConnectionViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id tenantId:(NSString * _Nullable)tenantId hostIp:(NSString * _Nullable)hostIp port:(int32_t)port databaseName:(NSString * _Nullable)databaseName jdbcUrl:(NSString * _Nullable)jdbcUrl username:(NSString * _Nullable)username password:(NSString * _Nullable)password poolingEnabled:(BOOL)poolingEnabled databaseEncoding:(NSString *)databaseEncoding databaseCollation:(NSString *)databaseCollation databaseCType:(NSString *)databaseCType __attribute__((swift_name("init(id:tenantId:hostIp:port:databaseName:jdbcUrl:username:password:poolingEnabled:databaseEncoding:databaseCollation:databaseCType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitDBConnectionViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitDBConnectionViewDto *)doCopyId:(SharedKitLong * _Nullable)id tenantId:(NSString * _Nullable)tenantId hostIp:(NSString * _Nullable)hostIp port:(int32_t)port databaseName:(NSString * _Nullable)databaseName jdbcUrl:(NSString * _Nullable)jdbcUrl username:(NSString * _Nullable)username password:(NSString * _Nullable)password poolingEnabled:(BOOL)poolingEnabled databaseEncoding:(NSString *)databaseEncoding databaseCollation:(NSString *)databaseCollation databaseCType:(NSString *)databaseCType __attribute__((swift_name("doCopy(id:tenantId:hostIp:port:databaseName:jdbcUrl:username:password:poolingEnabled:databaseEncoding:databaseCollation:databaseCType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *baseJdbcUrl __attribute__((swift_name("baseJdbcUrl")));
@property NSString *databaseCType __attribute__((swift_name("databaseCType")));
@property NSString *databaseCollation __attribute__((swift_name("databaseCollation")));
@property NSString *databaseEncoding __attribute__((swift_name("databaseEncoding")));
@property NSString * _Nullable databaseName __attribute__((swift_name("databaseName")));
@property NSString * _Nullable hostIp __attribute__((swift_name("hostIp")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable jdbcUrl __attribute__((swift_name("jdbcUrl")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property BOOL poolingEnabled __attribute__((swift_name("poolingEnabled")));
@property int32_t port __attribute__((swift_name("port")));
@property NSString * _Nullable tenantId __attribute__((swift_name("tenantId")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DBConnectionViewDto.Companion")))
@interface SharedKitDBConnectionViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitDBConnectionViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressValidationDto")))
@interface SharedKitAddressValidationDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude __attribute__((swift_name("init(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressValidationDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressValidationDto *)doCopyCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude __attribute__((swift_name("doCopy(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable addressLine1 __attribute__((swift_name("addressLine1")));
@property NSString * _Nullable addressLine2 __attribute__((swift_name("addressLine2")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property SharedKitDouble * _Nullable latitude __attribute__((swift_name("latitude")));
@property SharedKitDouble * _Nullable longitude __attribute__((swift_name("longitude")));
@property NSString * _Nullable stateCode __attribute__((swift_name("stateCode")));
@property NSString * _Nullable zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressValidationDto.Companion")))
@interface SharedKitAddressValidationDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressValidationDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PhoneValidationDto")))
@interface SharedKitPhoneValidationDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString * _Nullable)countryCode phoneNumber:(NSString * _Nullable)phoneNumber group:(NSString * _Nullable)group __attribute__((swift_name("init(countryCode:phoneNumber:group:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPhoneValidationDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPhoneValidationDto *)doCopyCountryCode:(NSString * _Nullable)countryCode phoneNumber:(NSString * _Nullable)phoneNumber group:(NSString * _Nullable)group __attribute__((swift_name("doCopy(countryCode:phoneNumber:group:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable group __attribute__((swift_name("group")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PhoneValidationDto.Companion")))
@interface SharedKitPhoneValidationDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPhoneValidationDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeZoneValidationDto")))
@interface SharedKitTimeZoneValidationDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithTimezone:(NSString * _Nullable)timezone __attribute__((swift_name("init(timezone:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTimeZoneValidationDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTimeZoneValidationDto *)doCopyTimezone:(NSString * _Nullable)timezone __attribute__((swift_name("doCopy(timezone:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeZoneValidationDto.Companion")))
@interface SharedKitTimeZoneValidationDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTimeZoneValidationDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidPhoneNumber")))
@interface SharedKitValidPhoneNumber : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithPhoneCountryCode:(int32_t)phoneCountryCode nationalPhoneNumber:(NSString *)nationalPhoneNumber __attribute__((swift_name("init(phoneCountryCode:nationalPhoneNumber:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitValidPhoneNumberCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitValidPhoneNumber *)doCopyPhoneCountryCode:(int32_t)phoneCountryCode nationalPhoneNumber:(NSString *)nationalPhoneNumber __attribute__((swift_name("doCopy(phoneCountryCode:nationalPhoneNumber:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString *nationalPhoneNumber __attribute__((swift_name("nationalPhoneNumber")));
@property int32_t phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ValidPhoneNumber.Companion")))
@interface SharedKitValidPhoneNumberCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitValidPhoneNumberCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GeoPointViewDto")))
@interface SharedKitGeoPointViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithLat:(SharedKitDouble * _Nullable)lat lon:(SharedKitDouble * _Nullable)lon __attribute__((swift_name("init(lat:lon:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitGeoPointViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitGeoPointViewDto *)doCopyLat:(SharedKitDouble * _Nullable)lat lon:(SharedKitDouble * _Nullable)lon __attribute__((swift_name("doCopy(lat:lon:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitDouble * _Nullable lat __attribute__((swift_name("lat")));
@property SharedKitDouble * _Nullable lon __attribute__((swift_name("lon")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GeoPointViewDto.Companion")))
@interface SharedKitGeoPointViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitGeoPointViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyCreateDto")))
@interface SharedKitPropertyCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithScope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category name:(NSString * _Nullable)name levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints value:(NSString * _Nullable)value type:(SharedKitPropertyType *)type active:(BOOL)active hidden:(BOOL)hidden apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("init(scope:agent:module:category:name:levelPath:constraints:value:type:active:hidden:apiProtected:overridable:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPropertyCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPropertyCreateDto *)doCopyScope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category name:(NSString * _Nullable)name levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints value:(NSString * _Nullable)value type:(SharedKitPropertyType *)type active:(BOOL)active hidden:(BOOL)hidden apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("doCopy(scope:agent:module:category:name:levelPath:constraints:value:type:active:hidden:apiProtected:overridable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString * _Nullable agent __attribute__((swift_name("agent")));
@property BOOL apiProtected __attribute__((swift_name("apiProtected")));
@property NSString * _Nullable category __attribute__((swift_name("category")));
@property NSString * _Nullable constraints __attribute__((swift_name("constraints")));
@property BOOL hidden __attribute__((swift_name("hidden")));
@property NSString * _Nullable levelPath __attribute__((swift_name("levelPath")));
@property NSString * _Nullable module __attribute__((swift_name("module")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property BOOL overridable __attribute__((swift_name("overridable")));
@property NSString * _Nullable scope __attribute__((swift_name("scope")));
@property SharedKitPropertyType *type __attribute__((swift_name("type")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyCreateDto.Companion")))
@interface SharedKitPropertyCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPropertyCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyDistinctViewDto")))
@interface SharedKitPropertyDistinctViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name count:(SharedKitLong * _Nullable)count __attribute__((swift_name("init(name:count:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPropertyDistinctViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPropertyDistinctViewDto *)doCopyName:(NSString * _Nullable)name count:(SharedKitLong * _Nullable)count __attribute__((swift_name("doCopy(name:count:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitLong * _Nullable count __attribute__((swift_name("count")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyDistinctViewDto.Companion")))
@interface SharedKitPropertyDistinctViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPropertyDistinctViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyInternal")))
@interface SharedKitPropertyInternal : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id scope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category name:(NSString * _Nullable)name uniqueName:(NSString * _Nullable)uniqueName value:(NSString * _Nullable)value levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints type:(SharedKitPropertyType *)type available:(NSString * _Nullable)available hidden:(BOOL)hidden active:(BOOL)active apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("init(id:scope:agent:module:category:name:uniqueName:value:levelPath:constraints:type:available:hidden:active:apiProtected:overridable:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPropertyInternalCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPropertyInternal *)doCopyId:(SharedKitLong * _Nullable)id scope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category name:(NSString * _Nullable)name uniqueName:(NSString * _Nullable)uniqueName value:(NSString * _Nullable)value levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints type:(SharedKitPropertyType *)type available:(NSString * _Nullable)available hidden:(BOOL)hidden active:(BOOL)active apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("doCopy(id:scope:agent:module:category:name:uniqueName:value:levelPath:constraints:type:available:hidden:active:apiProtected:overridable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString * _Nullable agent __attribute__((swift_name("agent")));
@property BOOL apiProtected __attribute__((swift_name("apiProtected")));
@property NSString * _Nullable available __attribute__((swift_name("available")));
@property NSString * _Nullable category __attribute__((swift_name("category")));
@property NSString * _Nullable constraints __attribute__((swift_name("constraints")));
@property BOOL hidden __attribute__((swift_name("hidden")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable levelPath __attribute__((swift_name("levelPath")));
@property NSString * _Nullable module __attribute__((swift_name("module")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property BOOL overridable __attribute__((swift_name("overridable")));
@property NSString * _Nullable scope __attribute__((swift_name("scope")));
@property SharedKitPropertyType *type __attribute__((swift_name("type")));
@property NSString * _Nullable uniqueName __attribute__((swift_name("uniqueName")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyInternal.Companion")))
@interface SharedKitPropertyInternalCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPropertyInternalCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyUpdateDto")))
@interface SharedKitPropertyUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(int64_t)id value:(NSString * _Nullable)value levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints __attribute__((swift_name("init(id:value:levelPath:constraints:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPropertyUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPropertyUpdateDto *)doCopyId:(int64_t)id value:(NSString * _Nullable)value levelPath:(NSString * _Nullable)levelPath constraints:(NSString * _Nullable)constraints __attribute__((swift_name("doCopy(id:value:levelPath:constraints:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable constraints __attribute__((swift_name("constraints")));
@property int64_t id __attribute__((swift_name("id")));
@property NSString * _Nullable levelPath __attribute__((swift_name("levelPath")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyUpdateDto.Companion")))
@interface SharedKitPropertyUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPropertyUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyViewDto")))
@interface SharedKitPropertyViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id scope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category levelPath:(NSString * _Nullable)levelPath name:(NSString * _Nullable)name uniqueName:(NSString * _Nullable)uniqueName constraints:(NSString * _Nullable)constraints value:(NSString * _Nullable)value type:(SharedKitPropertyType * _Nullable)type active:(BOOL)active hidden:(BOOL)hidden apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("init(id:scope:agent:module:category:levelPath:name:uniqueName:constraints:value:type:active:hidden:apiProtected:overridable:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPropertyViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPropertyViewDto *)doCopyId:(SharedKitLong * _Nullable)id scope:(NSString * _Nullable)scope agent:(NSString * _Nullable)agent module:(NSString * _Nullable)module category:(NSString * _Nullable)category levelPath:(NSString * _Nullable)levelPath name:(NSString * _Nullable)name uniqueName:(NSString * _Nullable)uniqueName constraints:(NSString * _Nullable)constraints value:(NSString * _Nullable)value type:(SharedKitPropertyType * _Nullable)type active:(BOOL)active hidden:(BOOL)hidden apiProtected:(BOOL)apiProtected overridable:(BOOL)overridable __attribute__((swift_name("doCopy(id:scope:agent:module:category:levelPath:name:uniqueName:constraints:value:type:active:hidden:apiProtected:overridable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property BOOL active __attribute__((swift_name("active")));
@property NSString * _Nullable agent __attribute__((swift_name("agent")));
@property BOOL apiProtected __attribute__((swift_name("apiProtected")));
@property NSString * _Nullable category __attribute__((swift_name("category")));
@property NSString * _Nullable constraints __attribute__((swift_name("constraints")));
@property BOOL hidden __attribute__((swift_name("hidden")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable levelPath __attribute__((swift_name("levelPath")));
@property NSString * _Nullable module __attribute__((swift_name("module")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property BOOL overridable __attribute__((swift_name("overridable")));
@property NSString * _Nullable scope __attribute__((swift_name("scope")));
@property SharedKitPropertyType * _Nullable type __attribute__((swift_name("type")));
@property NSString * _Nullable uniqueName __attribute__((swift_name("uniqueName")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PropertyViewDto.Companion")))
@interface SharedKitPropertyViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPropertyViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nCreateDto")))
@interface SharedKitI18nCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithKey:(NSString * _Nullable)key value:(NSString * _Nullable)value locale:(NSString * _Nullable)locale __attribute__((swift_name("init(key:value:locale:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitI18nCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitI18nCreateDto *)doCopyKey:(NSString * _Nullable)key value:(NSString * _Nullable)value locale:(NSString * _Nullable)locale __attribute__((swift_name("doCopy(key:value:locale:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable key __attribute__((swift_name("key")));
@property NSString * _Nullable locale __attribute__((swift_name("locale")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nCreateDto.Companion")))
@interface SharedKitI18nCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitI18nCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nUpdateDto")))
@interface SharedKitI18nUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithValue:(NSString * _Nullable)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitI18nUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitI18nUpdateDto *)doCopyValue:(NSString * _Nullable)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nUpdateDto.Companion")))
@interface SharedKitI18nUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitI18nUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nViewDto")))
@interface SharedKitI18nViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithKey:(NSString * _Nullable)key value:(NSString * _Nullable)value locale:(NSString * _Nullable)locale __attribute__((swift_name("init(key:value:locale:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitI18nViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitI18nViewDto *)doCopyKey:(NSString * _Nullable)key value:(NSString * _Nullable)value locale:(NSString * _Nullable)locale __attribute__((swift_name("doCopy(key:value:locale:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable key __attribute__((swift_name("key")));
@property NSString * _Nullable locale __attribute__((swift_name("locale")));
@property NSString * _Nullable value __attribute__((swift_name("value")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("I18nViewDto.Companion")))
@interface SharedKitI18nViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitI18nViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocaleViewDto")))
@interface SharedKitLocaleViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithLocale:(NSString * _Nullable)locale displayName:(NSString * _Nullable)displayName __attribute__((swift_name("init(locale:displayName:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitLocaleViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitLocaleViewDto *)doCopyLocale:(NSString * _Nullable)locale displayName:(NSString * _Nullable)displayName __attribute__((swift_name("doCopy(locale:displayName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable displayName __attribute__((swift_name("displayName")));
@property NSString * _Nullable locale __attribute__((swift_name("locale")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("LocaleViewDto.Companion")))
@interface SharedKitLocaleViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitLocaleViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthClientCreateDto")))
@interface SharedKitOAuthClientCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithClientId:(NSString * _Nullable)clientId name:(NSString * _Nullable)name withSecret:(BOOL)withSecret validRedirectURIs:(NSSet<NSString *> *)validRedirectURIs __attribute__((swift_name("init(clientId:name:withSecret:validRedirectURIs:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitOAuthClientCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitOAuthClientCreateDto *)doCopyClientId:(NSString * _Nullable)clientId name:(NSString * _Nullable)name withSecret:(BOOL)withSecret validRedirectURIs:(NSSet<NSString *> *)validRedirectURIs __attribute__((swift_name("doCopy(clientId:name:withSecret:validRedirectURIs:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable clientId __attribute__((swift_name("clientId")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSSet<NSString *> *validRedirectURIs __attribute__((swift_name("validRedirectURIs")));
@property BOOL withSecret __attribute__((swift_name("withSecret")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthClientCreateDto.Companion")))
@interface SharedKitOAuthClientCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitOAuthClientCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthClientViewDto")))
@interface SharedKitOAuthClientViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt clientId:(NSString * _Nullable)clientId name:(NSString * _Nullable)name secret:(NSString * _Nullable)secret validRedirectURIs:(NSSet<NSString *> *)validRedirectURIs __attribute__((swift_name("init(id:createdAt:updatedAt:clientId:name:secret:validRedirectURIs:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitOAuthClientViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitOAuthClientViewDto *)doCopyId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt clientId:(NSString * _Nullable)clientId name:(NSString * _Nullable)name secret:(NSString * _Nullable)secret validRedirectURIs:(NSSet<NSString *> *)validRedirectURIs __attribute__((swift_name("doCopy(id:createdAt:updatedAt:clientId:name:secret:validRedirectURIs:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable clientId __attribute__((swift_name("clientId")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable secret __attribute__((swift_name("secret")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable updatedAt __attribute__((swift_name("updatedAt")));
@property NSSet<NSString *> *validRedirectURIs __attribute__((swift_name("validRedirectURIs")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthClientViewDto.Companion")))
@interface SharedKitOAuthClientViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitOAuthClientViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthErrorViewDto")))
@interface SharedKitOAuthErrorViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithError:(NSString * _Nullable)error errorDescription:(NSString * _Nullable)errorDescription __attribute__((swift_name("init(error:errorDescription:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitOAuthErrorViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitOAuthErrorViewDto *)doCopyError:(NSString * _Nullable)error errorDescription:(NSString * _Nullable)errorDescription __attribute__((swift_name("doCopy(error:errorDescription:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable error __attribute__((swift_name("error")));
@property NSString * _Nullable errorDescription __attribute__((swift_name("errorDescription")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthErrorViewDto.Companion")))
@interface SharedKitOAuthErrorViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitOAuthErrorViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OAuthTokenRequestDto")))
@interface SharedKitOAuthTokenRequestDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithClientId:(NSString * _Nullable)clientId grantType:(NSString * _Nullable)grantType code:(NSString * _Nullable)code clientSecret:(NSString * _Nullable)clientSecret redirectURI:(NSString * _Nullable)redirectURI __attribute__((swift_name("init(clientId:grantType:code:clientSecret:redirectURI:)"))) __attribute__((objc_designated_initializer));
- (SharedKitOAuthTokenRequestDto *)doCopyClientId:(NSString * _Nullable)clientId grantType:(NSString * _Nullable)grantType code:(NSString * _Nullable)code clientSecret:(NSString * _Nullable)clientSecret redirectURI:(NSString * _Nullable)redirectURI __attribute__((swift_name("doCopy(clientId:grantType:code:clientSecret:redirectURI:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable clientId __attribute__((swift_name("clientId")));
@property NSString * _Nullable clientSecret __attribute__((swift_name("clientSecret")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property NSString * _Nullable grantType __attribute__((swift_name("grantType")));
@property NSString * _Nullable redirectURI __attribute__((swift_name("redirectURI")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenResponseViewDto")))
@interface SharedKitTokenResponseViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithAccessToken:(NSString * _Nullable)accessToken expiresIn:(SharedKitLong * _Nullable)expiresIn refreshExpiresIn:(SharedKitLong * _Nullable)refreshExpiresIn refreshToken:(NSString * _Nullable)refreshToken tokenType:(NSString *)tokenType notBeforePolicy:(int32_t)notBeforePolicy sessionState:(NSString * _Nullable)sessionState scope:(NSString * _Nullable)scope __attribute__((swift_name("init(accessToken:expiresIn:refreshExpiresIn:refreshToken:tokenType:notBeforePolicy:sessionState:scope:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTokenResponseViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTokenResponseViewDto *)doCopyAccessToken:(NSString * _Nullable)accessToken expiresIn:(SharedKitLong * _Nullable)expiresIn refreshExpiresIn:(SharedKitLong * _Nullable)refreshExpiresIn refreshToken:(NSString * _Nullable)refreshToken tokenType:(NSString *)tokenType notBeforePolicy:(int32_t)notBeforePolicy sessionState:(NSString * _Nullable)sessionState scope:(NSString * _Nullable)scope __attribute__((swift_name("doCopy(accessToken:expiresIn:refreshExpiresIn:refreshToken:tokenType:notBeforePolicy:sessionState:scope:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable accessToken __attribute__((swift_name("accessToken")));
@property SharedKitLong * _Nullable expiresIn __attribute__((swift_name("expiresIn")));
@property int32_t notBeforePolicy __attribute__((swift_name("notBeforePolicy")));
@property SharedKitLong * _Nullable refreshExpiresIn __attribute__((swift_name("refreshExpiresIn")));
@property NSString * _Nullable refreshToken __attribute__((swift_name("refreshToken")));
@property NSString * _Nullable scope __attribute__((swift_name("scope")));
@property NSString * _Nullable sessionState __attribute__((swift_name("sessionState")));
@property NSString *tokenType __attribute__((swift_name("tokenType")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TokenResponseViewDto.Companion")))
@interface SharedKitTokenResponseViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTokenResponseViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemovedUserDataViewDto")))
@interface SharedKitRemovedUserDataViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt source:(NSString * _Nullable)source userId:(SharedKitLong * _Nullable)userId processing:(BOOL)processing success:(BOOL)success __attribute__((swift_name("init(id:createdAt:updatedAt:source:userId:processing:success:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitRemovedUserDataViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitRemovedUserDataViewDto *)doCopyId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt source:(NSString * _Nullable)source userId:(SharedKitLong * _Nullable)userId processing:(BOOL)processing success:(BOOL)success __attribute__((swift_name("doCopy(id:createdAt:updatedAt:source:userId:processing:success:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property BOOL processing __attribute__((swift_name("processing")));
@property NSString * _Nullable source __attribute__((swift_name("source")));
@property BOOL success __attribute__((swift_name("success")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable updatedAt __attribute__((swift_name("updatedAt")));
@property SharedKitLong * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RemovedUserDataViewDto.Companion")))
@interface SharedKitRemovedUserDataViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitRemovedUserDataViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("MacroGroup")))
@protocol SharedKitMacroGroup
@required
@end

__attribute__((swift_name("MacroGroupDailyRepetition")))
@protocol SharedKitMacroGroupDailyRepetition
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodCreateDto")))
@interface SharedKitTemporalPeriodCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithStartDate:(SharedKitKotlinx_datetimeInstant * _Nullable)startDate endDate:(SharedKitKotlinx_datetimeInstant * _Nullable)endDate timezoneId:(NSString * _Nullable)timezoneId repetitionEndDate:(SharedKitKotlinx_datetimeLocalDate * _Nullable)repetitionEndDate repetitionType:(SharedKitTemporalRepetitionType * _Nullable)repetitionType dailyRepetitionDays:(SharedKitTemporalPeriodWeekdaysCreateDto * _Nullable)dailyRepetitionDays __attribute__((swift_name("init(startDate:endDate:timezoneId:repetitionEndDate:repetitionType:dailyRepetitionDays:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTemporalPeriodCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTemporalPeriodCreateDto *)doCopyStartDate:(SharedKitKotlinx_datetimeInstant * _Nullable)startDate endDate:(SharedKitKotlinx_datetimeInstant * _Nullable)endDate timezoneId:(NSString * _Nullable)timezoneId repetitionEndDate:(SharedKitKotlinx_datetimeLocalDate * _Nullable)repetitionEndDate repetitionType:(SharedKitTemporalRepetitionType * _Nullable)repetitionType dailyRepetitionDays:(SharedKitTemporalPeriodWeekdaysCreateDto * _Nullable)dailyRepetitionDays __attribute__((swift_name("doCopy(startDate:endDate:timezoneId:repetitionEndDate:repetitionType:dailyRepetitionDays:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitTemporalPeriodWeekdaysCreateDto * _Nullable dailyRepetitionDays __attribute__((swift_name("dailyRepetitionDays")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable endDate __attribute__((swift_name("endDate")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/DateSerializer))
*/
@property SharedKitKotlinx_datetimeLocalDate * _Nullable repetitionEndDate __attribute__((swift_name("repetitionEndDate")));
@property SharedKitTemporalRepetitionType * _Nullable repetitionType __attribute__((swift_name("repetitionType")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable startDate __attribute__((swift_name("startDate")));
@property NSString * _Nullable timezoneId __attribute__((swift_name("timezoneId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodCreateDto.Companion")))
@interface SharedKitTemporalPeriodCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTemporalPeriodCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodViewDto")))
@interface SharedKitTemporalPeriodViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt startDate:(SharedKitKotlinx_datetimeInstant * _Nullable)startDate endDate:(SharedKitKotlinx_datetimeInstant * _Nullable)endDate timezoneId:(NSString * _Nullable)timezoneId repetitionEndDate:(SharedKitKotlinx_datetimeLocalDate * _Nullable)repetitionEndDate repetitionType:(SharedKitTemporalRepetitionType * _Nullable)repetitionType dailyRepetitionDays:(SharedKitTemporalPeriodWeekdaysViewDto * _Nullable)dailyRepetitionDays __attribute__((swift_name("init(id:createdAt:updatedAt:startDate:endDate:timezoneId:repetitionEndDate:repetitionType:dailyRepetitionDays:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTemporalPeriodViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTemporalPeriodViewDto *)doCopyId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt updatedAt:(SharedKitKotlinx_datetimeInstant * _Nullable)updatedAt startDate:(SharedKitKotlinx_datetimeInstant * _Nullable)startDate endDate:(SharedKitKotlinx_datetimeInstant * _Nullable)endDate timezoneId:(NSString * _Nullable)timezoneId repetitionEndDate:(SharedKitKotlinx_datetimeLocalDate * _Nullable)repetitionEndDate repetitionType:(SharedKitTemporalRepetitionType * _Nullable)repetitionType dailyRepetitionDays:(SharedKitTemporalPeriodWeekdaysViewDto * _Nullable)dailyRepetitionDays __attribute__((swift_name("doCopy(id:createdAt:updatedAt:startDate:endDate:timezoneId:repetitionEndDate:repetitionType:dailyRepetitionDays:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property SharedKitTemporalPeriodWeekdaysViewDto * _Nullable dailyRepetitionDays __attribute__((swift_name("dailyRepetitionDays")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable endDate __attribute__((swift_name("endDate")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/DateSerializer))
*/
@property SharedKitKotlinx_datetimeLocalDate * _Nullable repetitionEndDate __attribute__((swift_name("repetitionEndDate")));
@property SharedKitTemporalRepetitionType * _Nullable repetitionType __attribute__((swift_name("repetitionType")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable startDate __attribute__((swift_name("startDate")));
@property NSString * _Nullable timezoneId __attribute__((swift_name("timezoneId")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable updatedAt __attribute__((swift_name("updatedAt")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodViewDto.Companion")))
@interface SharedKitTemporalPeriodViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTemporalPeriodViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodWeekdaysCreateDto")))
@interface SharedKitTemporalPeriodWeekdaysCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithMonday:(SharedKitBoolean * _Nullable)monday tuesday:(SharedKitBoolean * _Nullable)tuesday wednesday:(SharedKitBoolean * _Nullable)wednesday thursday:(SharedKitBoolean * _Nullable)thursday friday:(SharedKitBoolean * _Nullable)friday saturday:(SharedKitBoolean * _Nullable)saturday sunday:(SharedKitBoolean * _Nullable)sunday __attribute__((swift_name("init(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTemporalPeriodWeekdaysCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTemporalPeriodWeekdaysCreateDto *)doCopyMonday:(SharedKitBoolean * _Nullable)monday tuesday:(SharedKitBoolean * _Nullable)tuesday wednesday:(SharedKitBoolean * _Nullable)wednesday thursday:(SharedKitBoolean * _Nullable)thursday friday:(SharedKitBoolean * _Nullable)friday saturday:(SharedKitBoolean * _Nullable)saturday sunday:(SharedKitBoolean * _Nullable)sunday __attribute__((swift_name("doCopy(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable friday __attribute__((swift_name("friday")));
@property SharedKitBoolean * _Nullable monday __attribute__((swift_name("monday")));
@property SharedKitBoolean * _Nullable saturday __attribute__((swift_name("saturday")));
@property SharedKitBoolean * _Nullable sunday __attribute__((swift_name("sunday")));
@property SharedKitBoolean * _Nullable thursday __attribute__((swift_name("thursday")));
@property SharedKitBoolean * _Nullable tuesday __attribute__((swift_name("tuesday")));
@property SharedKitBoolean * _Nullable wednesday __attribute__((swift_name("wednesday")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodWeekdaysCreateDto.Companion")))
@interface SharedKitTemporalPeriodWeekdaysCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTemporalPeriodWeekdaysCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodWeekdaysViewDto")))
@interface SharedKitTemporalPeriodWeekdaysViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithMonday:(SharedKitBoolean * _Nullable)monday tuesday:(SharedKitBoolean * _Nullable)tuesday wednesday:(SharedKitBoolean * _Nullable)wednesday thursday:(SharedKitBoolean * _Nullable)thursday friday:(SharedKitBoolean * _Nullable)friday saturday:(SharedKitBoolean * _Nullable)saturday sunday:(SharedKitBoolean * _Nullable)sunday __attribute__((swift_name("init(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTemporalPeriodWeekdaysViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTemporalPeriodWeekdaysViewDto *)doCopyMonday:(SharedKitBoolean * _Nullable)monday tuesday:(SharedKitBoolean * _Nullable)tuesday wednesday:(SharedKitBoolean * _Nullable)wednesday thursday:(SharedKitBoolean * _Nullable)thursday friday:(SharedKitBoolean * _Nullable)friday saturday:(SharedKitBoolean * _Nullable)saturday sunday:(SharedKitBoolean * _Nullable)sunday __attribute__((swift_name("doCopy(monday:tuesday:wednesday:thursday:friday:saturday:sunday:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable friday __attribute__((swift_name("friday")));
@property SharedKitBoolean * _Nullable monday __attribute__((swift_name("monday")));
@property SharedKitBoolean * _Nullable saturday __attribute__((swift_name("saturday")));
@property SharedKitBoolean * _Nullable sunday __attribute__((swift_name("sunday")));
@property SharedKitBoolean * _Nullable thursday __attribute__((swift_name("thursday")));
@property SharedKitBoolean * _Nullable tuesday __attribute__((swift_name("tuesday")));
@property SharedKitBoolean * _Nullable wednesday __attribute__((swift_name("wednesday")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TemporalPeriodWeekdaysViewDto.Companion")))
@interface SharedKitTemporalPeriodWeekdaysViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTemporalPeriodWeekdaysViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationChannel")))
@interface SharedKitNotificationChannel : SharedKitBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) SharedKitNotificationChannelFactory *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationChannel.Factory")))
@interface SharedKitNotificationChannelFactory : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)factory __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitNotificationChannelFactory *shared __attribute__((swift_name("shared")));
- (NSString *)createCCTVAIChanelDeviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("createCCTVAIChanel(deviceId:)")));
- (NSString *)createCCTVLicensePlateChannelDeviceId:(NSString * _Nullable)deviceId plate:(NSString * _Nullable)plate __attribute__((swift_name("createCCTVLicensePlateChannel(deviceId:plate:)")));
- (NSString *)createChannelResourceType:(SharedKitNotificationResourceType *)resourceType resourceId:(NSString * _Nullable)resourceId messageType:(SharedKitPushMessageType * _Nullable)messageType detail:(NSString * _Nullable)detail __attribute__((swift_name("createChannel(resourceType:resourceId:messageType:detail:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationSourceDto")))
@interface SharedKitNotificationSourceDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithChannel:(NSString * _Nullable)channel description:(NSString * _Nullable)description __attribute__((swift_name("init(channel:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitNotificationSourceDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitNotificationSourceDto *)doCopyChannel:(NSString * _Nullable)channel description:(NSString * _Nullable)description __attribute__((swift_name("doCopy(channel:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable channel __attribute__((swift_name("channel")));
@property (setter=setDescription:) NSString * _Nullable description_ __attribute__((swift_name("description_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("NotificationSourceDto.Companion")))
@interface SharedKitNotificationSourceDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitNotificationSourceDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MultipleUsersValidationDto")))
@interface SharedKitMultipleUsersValidationDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithIds:(id _Nullable)ids active:(SharedKitBoolean * _Nullable)active enforce:(SharedKitBoolean * _Nullable)enforce __attribute__((swift_name("init(ids:active:enforce:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMultipleUsersValidationDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMultipleUsersValidationDto *)doCopyIds:(id _Nullable)ids active:(SharedKitBoolean * _Nullable)active enforce:(SharedKitBoolean * _Nullable)enforce __attribute__((swift_name("doCopy(ids:active:enforce:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property SharedKitBoolean * _Nullable enforce __attribute__((swift_name("enforce")));
@property id _Nullable ids __attribute__((swift_name("ids")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MultipleUsersValidationDto.Companion")))
@interface SharedKitMultipleUsersValidationDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMultipleUsersValidationDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RoleViewDto")))
@interface SharedKitRoleViewDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name assignable:(SharedKitBoolean * _Nullable)assignable __attribute__((swift_name("init(name:assignable:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitRoleViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitRoleViewDto *)doCopyName:(NSString * _Nullable)name assignable:(SharedKitBoolean * _Nullable)assignable __attribute__((swift_name("doCopy(name:assignable:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable assignable __attribute__((swift_name("assignable")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RoleViewDto.Companion")))
@interface SharedKitRoleViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitRoleViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserAdminCreateDto")))
@interface SharedKitUserAdminCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithPassword:(NSString * _Nullable)password firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone roles:(NSArray<SharedKitRole *> * _Nullable)roles __attribute__((swift_name("init(password:firstName:lastName:email:phone:countryCode:timezone:roles:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserAdminCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserAdminCreateDto *)doCopyPassword:(NSString * _Nullable)password firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone roles:(NSArray<SharedKitRole *> * _Nullable)roles __attribute__((swift_name("doCopy(password:firstName:lastName:email:phone:countryCode:timezone:roles:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSArray<SharedKitRole *> * _Nullable roles __attribute__((swift_name("roles")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserAdminCreateDto.Companion")))
@interface SharedKitUserAdminCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserAdminCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserClaimCreateDto")))
@interface SharedKitUserClaimCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithClaimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId userIds:(NSSet<SharedKitLong *> *)userIds claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("init(claimScope:objectId:userIds:claimReference:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserClaimCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserClaimCreateDto *)doCopyClaimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId userIds:(NSSet<SharedKitLong *> *)userIds claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("doCopy(claimScope:objectId:userIds:claimReference:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable claimReference __attribute__((swift_name("claimReference")));
@property SharedKitUserClaimScope * _Nullable claimScope __attribute__((swift_name("claimScope")));
@property NSString * _Nullable objectId __attribute__((swift_name("objectId")));
@property NSSet<SharedKitLong *> *userIds __attribute__((swift_name("userIds")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserClaimCreateDto.Companion")))
@interface SharedKitUserClaimCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserClaimCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserClaimViewDto")))
@interface SharedKitUserClaimViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id claimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId userId:(SharedKitLong * _Nullable)userId claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("init(id:claimScope:objectId:userId:claimReference:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserClaimViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserClaimViewDto *)doCopyId:(SharedKitLong * _Nullable)id claimScope:(SharedKitUserClaimScope * _Nullable)claimScope objectId:(NSString * _Nullable)objectId userId:(SharedKitLong * _Nullable)userId claimReference:(NSString * _Nullable)claimReference __attribute__((swift_name("doCopy(id:claimScope:objectId:userId:claimReference:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable claimReference __attribute__((swift_name("claimReference")));
@property SharedKitUserClaimScope * _Nullable claimScope __attribute__((swift_name("claimScope")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable objectId __attribute__((swift_name("objectId")));
@property SharedKitLong * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserClaimViewDto.Companion")))
@interface SharedKitUserClaimViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserClaimViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCodeLoginDto")))
@interface SharedKitUserCodeLoginDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithPhoneNumber:(NSString * _Nullable)phoneNumber code:(NSString * _Nullable)code __attribute__((swift_name("init(phoneNumber:code:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserCodeLoginDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserCodeLoginDto *)doCopyPhoneNumber:(NSString * _Nullable)phoneNumber code:(NSString * _Nullable)code __attribute__((swift_name("doCopy(phoneNumber:code:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCodeLoginDto.Companion")))
@interface SharedKitUserCodeLoginDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserCodeLoginDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCreateDto")))
@interface SharedKitUserCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithPassword:(NSString * _Nullable)password firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone token:(NSString * _Nullable)token __attribute__((swift_name("init(password:firstName:lastName:email:phone:countryCode:timezone:token:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserCreateDto *)doCopyPassword:(NSString * _Nullable)password firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone token:(NSString * _Nullable)token __attribute__((swift_name("doCopy(password:firstName:lastName:email:phone:countryCode:timezone:token:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@property NSString * _Nullable token __attribute__((swift_name("token")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCreateDto.Companion")))
@interface SharedKitUserCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCreateProfileInternalDto")))
@interface SharedKitUserCreateProfileInternalDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(int64_t)id firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode hidden:(BOOL)hidden roles:(NSArray<SharedKitRoleViewDto *> *)roles __attribute__((swift_name("init(id:firstName:lastName:email:phone:countryCode:hidden:roles:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserCreateProfileInternalDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserCreateProfileInternalDto *)doCopyId:(int64_t)id firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode hidden:(BOOL)hidden roles:(NSArray<SharedKitRoleViewDto *> *)roles __attribute__((swift_name("doCopy(id:firstName:lastName:email:phone:countryCode:hidden:roles:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property BOOL hidden __attribute__((swift_name("hidden")));
@property int64_t id __attribute__((swift_name("id")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSArray<SharedKitRoleViewDto *> *roles __attribute__((swift_name("roles")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserCreateProfileInternalDto.Companion")))
@interface SharedKitUserCreateProfileInternalDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserCreateProfileInternalDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserLoginDto")))
@interface SharedKitUserLoginDto : SharedKitBase
@property (class, readonly, getter=companion) SharedKitUserLoginDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserLoginDto *)doCopyUsername:(NSString * _Nullable)username password:(NSString * _Nullable)password __attribute__((swift_name("doCopy(username:password:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property NSString * _Nullable username __attribute__((swift_name("username")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserLoginDto.Companion")))
@interface SharedKitUserLoginDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserLoginDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserLogoutInternalDto")))
@interface SharedKitUserLogoutInternalDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("init(id:deviceId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserLogoutInternalDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserLogoutInternalDto *)doCopyId:(SharedKitLong * _Nullable)id deviceId:(NSString * _Nullable)deviceId __attribute__((swift_name("doCopy(id:deviceId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable deviceId __attribute__((swift_name("deviceId")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserLogoutInternalDto.Companion")))
@interface SharedKitUserLogoutInternalDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserLogoutInternalDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserUpdateDto")))
@interface SharedKitUserUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithFirstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone oldPassword:(NSString * _Nullable)oldPassword newPassword:(NSString * _Nullable)newPassword __attribute__((swift_name("init(firstName:lastName:email:phone:countryCode:timezone:oldPassword:newPassword:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserUpdateDto *)doCopyFirstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone countryCode:(NSString * _Nullable)countryCode timezone:(NSString * _Nullable)timezone oldPassword:(NSString * _Nullable)oldPassword newPassword:(NSString * _Nullable)newPassword __attribute__((swift_name("doCopy(firstName:lastName:email:phone:countryCode:timezone:oldPassword:newPassword:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property (getter=doNewPassword) NSString * _Nullable newPassword __attribute__((swift_name("newPassword")));
@property NSString * _Nullable oldPassword __attribute__((swift_name("oldPassword")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserUpdateDto.Companion")))
@interface SharedKitUserUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserViewDto")))
@interface SharedKitUserViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone phoneCountryCode:(SharedKitInt * _Nullable)phoneCountryCode inactive:(SharedKitBoolean * _Nullable)inactive timezone:(NSString * _Nullable)timezone countryCode:(NSString * _Nullable)countryCode lastLogin:(SharedKitKotlinx_datetimeInstant * _Nullable)lastLogin authType:(SharedKitAuthType *)authType __attribute__((swift_name("init(id:firstName:lastName:email:phone:phoneCountryCode:inactive:timezone:countryCode:lastLogin:authType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserViewDto *)doCopyId:(SharedKitLong * _Nullable)id firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone phoneCountryCode:(SharedKitInt * _Nullable)phoneCountryCode inactive:(SharedKitBoolean * _Nullable)inactive timezone:(NSString * _Nullable)timezone countryCode:(NSString * _Nullable)countryCode lastLogin:(SharedKitKotlinx_datetimeInstant * _Nullable)lastLogin authType:(SharedKitAuthType *)authType __attribute__((swift_name("doCopy(id:firstName:lastName:email:phone:phoneCountryCode:inactive:timezone:countryCode:lastLogin:authType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitAuthType *authType __attribute__((swift_name("authType")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property SharedKitBoolean * _Nullable inactive __attribute__((swift_name("inactive")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable lastLogin __attribute__((swift_name("lastLogin")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property SharedKitInt * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserViewDto.Companion")))
@interface SharedKitUserViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserViewInternalDto")))
@interface SharedKitUserViewInternalDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone phoneCountryCode:(SharedKitInt * _Nullable)phoneCountryCode inactive:(SharedKitBoolean * _Nullable)inactive hidden:(SharedKitBoolean * _Nullable)hidden timezone:(NSString * _Nullable)timezone countryCode:(NSString * _Nullable)countryCode lastLogin:(SharedKitKotlinx_datetimeInstant * _Nullable)lastLogin roles:(NSArray<SharedKitRoleViewDto *> *)roles __attribute__((swift_name("init(id:createdAt:firstName:lastName:email:phone:phoneCountryCode:inactive:hidden:timezone:countryCode:lastLogin:roles:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserViewInternalDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserViewInternalDto *)doCopyId:(SharedKitLong * _Nullable)id createdAt:(SharedKitKotlinx_datetimeInstant * _Nullable)createdAt firstName:(NSString * _Nullable)firstName lastName:(NSString * _Nullable)lastName email:(NSString * _Nullable)email phone:(NSString * _Nullable)phone phoneCountryCode:(SharedKitInt * _Nullable)phoneCountryCode inactive:(SharedKitBoolean * _Nullable)inactive hidden:(SharedKitBoolean * _Nullable)hidden timezone:(NSString * _Nullable)timezone countryCode:(NSString * _Nullable)countryCode lastLogin:(SharedKitKotlinx_datetimeInstant * _Nullable)lastLogin roles:(NSArray<SharedKitRoleViewDto *> *)roles __attribute__((swift_name("doCopy(id:createdAt:firstName:lastName:email:phone:phoneCountryCode:inactive:hidden:timezone:countryCode:lastLogin:roles:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable createdAt __attribute__((swift_name("createdAt")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable firstName __attribute__((swift_name("firstName")));
@property SharedKitBoolean * _Nullable hidden __attribute__((swift_name("hidden")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property SharedKitBoolean * _Nullable inactive __attribute__((swift_name("inactive")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/TimeSerializer))
*/
@property SharedKitKotlinx_datetimeInstant * _Nullable lastLogin __attribute__((swift_name("lastLogin")));
@property NSString * _Nullable lastName __attribute__((swift_name("lastName")));
@property NSString * _Nullable phone __attribute__((swift_name("phone")));
@property SharedKitInt * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSArray<SharedKitRoleViewDto *> *roles __attribute__((swift_name("roles")));
@property NSString * _Nullable timezone __attribute__((swift_name("timezone")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserViewInternalDto.Companion")))
@interface SharedKitUserViewInternalDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserViewInternalDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UsersWithClaimRequestDto")))
@interface SharedKitUsersWithClaimRequestDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithClaimScopes:(NSSet<SharedKitUserClaimScope *> *)claimScopes __attribute__((swift_name("init(claimScopes:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUsersWithClaimRequestDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUsersWithClaimRequestDto *)doCopyClaimScopes:(NSSet<SharedKitUserClaimScope *> *)claimScopes __attribute__((swift_name("doCopy(claimScopes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitUserClaimScope *> *claimScopes __attribute__((swift_name("claimScopes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UsersWithClaimRequestDto.Companion")))
@interface SharedKitUsersWithClaimRequestDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUsersWithClaimRequestDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UsersWithClaimViewDto")))
@interface SharedKitUsersWithClaimViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithUsers:(NSSet<SharedKitLong *> *)users __attribute__((swift_name("init(users:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUsersWithClaimViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUsersWithClaimViewDto *)doCopyUsers:(NSSet<SharedKitLong *> *)users __attribute__((swift_name("doCopy(users:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<SharedKitLong *> *users __attribute__((swift_name("users")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UsersWithClaimViewDto.Companion")))
@interface SharedKitUsersWithClaimViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUsersWithClaimViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkCreateDto")))
@interface SharedKitSocialMediaLinkCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithUrl:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("init(url:socialMediaType:other:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitSocialMediaLinkCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitSocialMediaLinkCreateDto *)doCopyUrl:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("doCopy(url:socialMediaType:other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable other __attribute__((swift_name("other")));
@property SharedKitSocialMediaType * _Nullable socialMediaType __attribute__((swift_name("socialMediaType")));
@property NSString * _Nullable url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkCreateDto.Companion")))
@interface SharedKitSocialMediaLinkCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitSocialMediaLinkCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkUpdateDto")))
@interface SharedKitSocialMediaLinkUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithUrl:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("init(url:socialMediaType:other:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitSocialMediaLinkUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitSocialMediaLinkUpdateDto *)doCopyUrl:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("doCopy(url:socialMediaType:other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable other __attribute__((swift_name("other")));
@property SharedKitSocialMediaType * _Nullable socialMediaType __attribute__((swift_name("socialMediaType")));
@property NSString * _Nullable url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkUpdateDto.Companion")))
@interface SharedKitSocialMediaLinkUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitSocialMediaLinkUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkViewDto")))
@interface SharedKitSocialMediaLinkViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id url:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("init(id:url:socialMediaType:other:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitSocialMediaLinkViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitSocialMediaLinkViewDto *)doCopyId:(SharedKitLong * _Nullable)id url:(NSString * _Nullable)url socialMediaType:(SharedKitSocialMediaType * _Nullable)socialMediaType other:(NSString * _Nullable)other __attribute__((swift_name("doCopy(id:url:socialMediaType:other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable other __attribute__((swift_name("other")));
@property SharedKitSocialMediaType * _Nullable socialMediaType __attribute__((swift_name("socialMediaType")));
@property NSString * _Nullable url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SocialMediaLinkViewDto.Companion")))
@interface SharedKitSocialMediaLinkViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitSocialMediaLinkViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressCreateDto")))
@interface SharedKitAddressCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("init(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:active:defaultAddress:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressCreateDto *)doCopyCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("doCopy(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:active:defaultAddress:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property NSString * _Nullable addressLine1 __attribute__((swift_name("addressLine1")));
@property NSString * _Nullable addressLine2 __attribute__((swift_name("addressLine2")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property SharedKitBoolean * _Nullable defaultAddress __attribute__((swift_name("defaultAddress")));
@property SharedKitDouble * _Nullable latitude __attribute__((swift_name("latitude")));
@property SharedKitDouble * _Nullable longitude __attribute__((swift_name("longitude")));
@property NSString * _Nullable stateCode __attribute__((swift_name("stateCode")));
@property NSString * _Nullable zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressCreateDto.Companion")))
@interface SharedKitAddressCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressSearchDto")))
@interface SharedKitAddressSearchDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 __attribute__((swift_name("init(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressSearchDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressSearchDto *)doCopyCountryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 __attribute__((swift_name("doCopy(countryCode:stateCode:city:zipCode:addressLine1:addressLine2:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable addressLine1 __attribute__((swift_name("addressLine1")));
@property NSString * _Nullable addressLine2 __attribute__((swift_name("addressLine2")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property NSString * _Nullable stateCode __attribute__((swift_name("stateCode")));
@property NSString * _Nullable zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressSearchDto.Companion")))
@interface SharedKitAddressSearchDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressSearchDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressUpdateDto")))
@interface SharedKitAddressUpdateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCountryCode:(NSString *)countryCode city:(NSString *)city zipCode:(NSString *)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 stateCode:(NSString * _Nullable)stateCode longitude:(double)longitude latitude:(double)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("init(countryCode:city:zipCode:addressLine1:addressLine2:stateCode:longitude:latitude:active:defaultAddress:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressUpdateDto *)doCopyCountryCode:(NSString *)countryCode city:(NSString *)city zipCode:(NSString *)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 stateCode:(NSString * _Nullable)stateCode longitude:(double)longitude latitude:(double)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("doCopy(countryCode:city:zipCode:addressLine1:addressLine2:stateCode:longitude:latitude:active:defaultAddress:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property NSString * _Nullable addressLine1 __attribute__((swift_name("addressLine1")));
@property NSString * _Nullable addressLine2 __attribute__((swift_name("addressLine2")));
@property NSString *city __attribute__((swift_name("city")));
@property NSString *countryCode __attribute__((swift_name("countryCode")));
@property SharedKitBoolean * _Nullable defaultAddress __attribute__((swift_name("defaultAddress")));
@property double latitude __attribute__((swift_name("latitude")));
@property double longitude __attribute__((swift_name("longitude")));
@property NSString * _Nullable stateCode __attribute__((swift_name("stateCode")));
@property NSString *zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressUpdateDto.Companion")))
@interface SharedKitAddressUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressViewDto")))
@interface SharedKitAddressViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id countryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("init(id:countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:active:defaultAddress:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressViewDto *)doCopyId:(SharedKitLong * _Nullable)id countryCode:(NSString * _Nullable)countryCode stateCode:(NSString * _Nullable)stateCode city:(NSString * _Nullable)city zipCode:(NSString * _Nullable)zipCode addressLine1:(NSString * _Nullable)addressLine1 addressLine2:(NSString * _Nullable)addressLine2 longitude:(SharedKitDouble * _Nullable)longitude latitude:(SharedKitDouble * _Nullable)latitude active:(SharedKitBoolean * _Nullable)active defaultAddress:(SharedKitBoolean * _Nullable)defaultAddress __attribute__((swift_name("doCopy(id:countryCode:stateCode:city:zipCode:addressLine1:addressLine2:longitude:latitude:active:defaultAddress:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property NSString * _Nullable addressLine1 __attribute__((swift_name("addressLine1")));
@property NSString * _Nullable addressLine2 __attribute__((swift_name("addressLine2")));
@property NSString * _Nullable city __attribute__((swift_name("city")));
@property NSString * _Nullable countryCode __attribute__((swift_name("countryCode")));
@property SharedKitBoolean * _Nullable defaultAddress __attribute__((swift_name("defaultAddress")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property SharedKitDouble * _Nullable latitude __attribute__((swift_name("latitude")));
@property SharedKitDouble * _Nullable longitude __attribute__((swift_name("longitude")));
@property NSString * _Nullable stateCode __attribute__((swift_name("stateCode")));
@property NSString * _Nullable zipCode __attribute__((swift_name("zipCode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressViewDto.Companion")))
@interface SharedKitAddressViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsCreateDto")))
@interface SharedKitAddressWithContactsCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressCreateDto * _Nullable)address __attribute__((swift_name("init(name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressWithContactsCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressWithContactsCreateDto *)doCopyName:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressCreateDto * _Nullable)address __attribute__((swift_name("doCopy(name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitAddressCreateDto * _Nullable address __attribute__((swift_name("address")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable hours __attribute__((swift_name("hours")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable webAddress __attribute__((swift_name("webAddress")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsCreateDto.Companion")))
@interface SharedKitAddressWithContactsCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressWithContactsCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsUpdateDto")))
@interface SharedKitAddressWithContactsUpdateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressUpdateDto * _Nullable)address __attribute__((swift_name("init(name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressWithContactsUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressWithContactsUpdateDto *)doCopyName:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressUpdateDto * _Nullable)address __attribute__((swift_name("doCopy(name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitAddressUpdateDto * _Nullable address __attribute__((swift_name("address")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable hours __attribute__((swift_name("hours")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable webAddress __attribute__((swift_name("webAddress")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsUpdateDto.Companion")))
@interface SharedKitAddressWithContactsUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressWithContactsUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsViewDto")))
@interface SharedKitAddressWithContactsViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressViewDto * _Nullable)address __attribute__((swift_name("init(id:name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitAddressWithContactsViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitAddressWithContactsViewDto *)doCopyId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name email:(NSString * _Nullable)email webAddress:(NSString * _Nullable)webAddress phoneNumber:(NSString * _Nullable)phoneNumber phoneCountryCode:(NSString * _Nullable)phoneCountryCode hours:(NSString * _Nullable)hours address:(SharedKitAddressViewDto * _Nullable)address __attribute__((swift_name("doCopy(id:name:email:webAddress:phoneNumber:phoneCountryCode:hours:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitAddressViewDto * _Nullable address __attribute__((swift_name("address")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property NSString * _Nullable hours __attribute__((swift_name("hours")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable phoneCountryCode __attribute__((swift_name("phoneCountryCode")));
@property NSString * _Nullable phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString * _Nullable webAddress __attribute__((swift_name("webAddress")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AddressWithContactsViewDto.Companion")))
@interface SharedKitAddressWithContactsViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitAddressWithContactsViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateCreateDto")))
@interface SharedKitStateCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("init(code:name:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitStateCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitStateCreateDto *)doCopyCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("doCopy(code:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateCreateDto.Companion")))
@interface SharedKitStateCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitStateCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateUpdateDto")))
@interface SharedKitStateUpdateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("init(code:name:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitStateUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitStateUpdateDto *)doCopyCode:(NSString * _Nullable)code name:(NSString * _Nullable)name __attribute__((swift_name("doCopy(code:name:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateUpdateDto.Companion")))
@interface SharedKitStateUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitStateUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateViewDto")))
@interface SharedKitStateViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCode:(NSString * _Nullable)code name:(NSString * _Nullable)name stored:(SharedKitBoolean * _Nullable)stored __attribute__((swift_name("init(code:name:stored:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitStateViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitStateViewDto *)doCopyCode:(NSString * _Nullable)code name:(NSString * _Nullable)name stored:(SharedKitBoolean * _Nullable)stored __attribute__((swift_name("doCopy(code:name:stored:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property SharedKitBoolean * _Nullable stored __attribute__((swift_name("stored")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("StateViewDto.Companion")))
@interface SharedKitStateViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitStateViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeZoneViewDto")))
@interface SharedKitTimeZoneViewDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithTimeZone:(NSString * _Nullable)timeZone displayName:(NSString * _Nullable)displayName tzOffset:(NSString * _Nullable)tzOffset tzRegion:(NSString * _Nullable)tzRegion standardName:(NSString * _Nullable)standardName __attribute__((swift_name("init(timeZone:displayName:tzOffset:tzRegion:standardName:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTimeZoneViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTimeZoneViewDto *)doCopyTimeZone:(NSString * _Nullable)timeZone displayName:(NSString * _Nullable)displayName tzOffset:(NSString * _Nullable)tzOffset tzRegion:(NSString * _Nullable)tzRegion standardName:(NSString * _Nullable)standardName __attribute__((swift_name("doCopy(timeZone:displayName:tzOffset:tzRegion:standardName:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable displayName __attribute__((swift_name("displayName")));
@property NSString * _Nullable standardName __attribute__((swift_name("standardName")));
@property NSString * _Nullable timeZone __attribute__((swift_name("timeZone")));
@property NSString * _Nullable tzOffset __attribute__((swift_name("tzOffset")));
@property NSString * _Nullable tzRegion __attribute__((swift_name("tzRegion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TimeZoneViewDto.Companion")))
@interface SharedKitTimeZoneViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTimeZoneViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryUserViewDto")))
@interface SharedKitCountryUserViewDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithCode:(NSString * _Nullable)code name:(NSString * _Nullable)name language:(NSString * _Nullable)language countryCodePhone:(SharedKitInt * _Nullable)countryCodePhone __attribute__((swift_name("init(code:name:language:countryCodePhone:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitCountryUserViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitCountryUserViewDto *)doCopyCode:(NSString * _Nullable)code name:(NSString * _Nullable)name language:(NSString * _Nullable)language countryCodePhone:(SharedKitInt * _Nullable)countryCodePhone __attribute__((swift_name("doCopy(code:name:language:countryCodePhone:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property SharedKitInt * _Nullable countryCodePhone __attribute__((swift_name("countryCodePhone")));
@property NSString * _Nullable language __attribute__((swift_name("language")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryUserViewDto.Companion")))
@interface SharedKitCountryUserViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitCountryUserViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryViewDto")))
@interface SharedKitCountryViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name code:(NSString * _Nullable)code countryCodePhone:(SharedKitInt * _Nullable)countryCodePhone flagUrl:(NSString * _Nullable)flagUrl stored:(SharedKitBoolean * _Nullable)stored language:(NSString * _Nullable)language __attribute__((swift_name("init(name:code:countryCodePhone:flagUrl:stored:language:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitCountryViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitCountryViewDto *)doCopyName:(NSString * _Nullable)name code:(NSString * _Nullable)code countryCodePhone:(SharedKitInt * _Nullable)countryCodePhone flagUrl:(NSString * _Nullable)flagUrl stored:(SharedKitBoolean * _Nullable)stored language:(NSString * _Nullable)language __attribute__((swift_name("doCopy(name:code:countryCodePhone:flagUrl:stored:language:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable code __attribute__((swift_name("code")));
@property SharedKitInt * _Nullable countryCodePhone __attribute__((swift_name("countryCodePhone")));
@property NSString * _Nullable flagUrl __attribute__((swift_name("flagUrl")));
@property NSString * _Nullable language __attribute__((swift_name("language")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property SharedKitBoolean * _Nullable stored __attribute__((swift_name("stored")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CountryViewDto.Companion")))
@interface SharedKitCountryViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitCountryViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserDeviceCredentialCreateDto")))
@interface SharedKitUserDeviceCredentialCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithName:(NSString * _Nullable)name deviceUUID:(NSString * _Nullable)deviceUUID hardwareType:(NSString * _Nullable)hardwareType __attribute__((swift_name("init(name:deviceUUID:hardwareType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserDeviceCredentialCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserDeviceCredentialCreateDto *)doCopyName:(NSString * _Nullable)name deviceUUID:(NSString * _Nullable)deviceUUID hardwareType:(NSString * _Nullable)hardwareType __attribute__((swift_name("doCopy(name:deviceUUID:hardwareType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable deviceUUID __attribute__((swift_name("deviceUUID")));
@property NSString * _Nullable hardwareType __attribute__((swift_name("hardwareType")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserDeviceCredentialCreateDto.Companion")))
@interface SharedKitUserDeviceCredentialCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserDeviceCredentialCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserDeviceCredentialViewDto")))
@interface SharedKitUserDeviceCredentialViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name uuid:(NSString * _Nullable)uuid issuedBy:(NSString * _Nullable)issuedBy active:(SharedKitBoolean * _Nullable)active accessClaims:(NSArray<SharedKitUserClaimViewDto *> *)accessClaims __attribute__((swift_name("init(id:name:uuid:issuedBy:active:accessClaims:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitUserDeviceCredentialViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitUserDeviceCredentialViewDto *)doCopyId:(SharedKitLong * _Nullable)id name:(NSString * _Nullable)name uuid:(NSString * _Nullable)uuid issuedBy:(NSString * _Nullable)issuedBy active:(SharedKitBoolean * _Nullable)active accessClaims:(NSArray<SharedKitUserClaimViewDto *> *)accessClaims __attribute__((swift_name("doCopy(id:name:uuid:issuedBy:active:accessClaims:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSArray<SharedKitUserClaimViewDto *> *accessClaims __attribute__((swift_name("accessClaims")));
@property SharedKitBoolean * _Nullable active __attribute__((swift_name("active")));
@property SharedKitLong * _Nullable id __attribute__((swift_name("id")));
@property NSString * _Nullable issuedBy __attribute__((swift_name("issuedBy")));
@property NSString * _Nullable name __attribute__((swift_name("name")));
@property NSString * _Nullable uuid __attribute__((swift_name("uuid")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserDeviceCredentialViewDto.Companion")))
@interface SharedKitUserDeviceCredentialViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitUserDeviceCredentialViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeUpdateDto")))
@interface SharedKitTreeNodeUpdateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithParentNode:(SharedKitTreeNodeViewLazyDto * _Nullable)parentNode indexOrder:(int64_t)indexOrder __attribute__((swift_name("init(parentNode:indexOrder:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTreeNodeUpdateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTreeNodeUpdateDto *)doCopyParentNode:(SharedKitTreeNodeViewLazyDto * _Nullable)parentNode indexOrder:(int64_t)indexOrder __attribute__((swift_name("doCopy(parentNode:indexOrder:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property int64_t indexOrder __attribute__((swift_name("indexOrder")));
@property SharedKitTreeNodeViewLazyDto * _Nullable parentNode __attribute__((swift_name("parentNode")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeUpdateDto.Companion")))
@interface SharedKitTreeNodeUpdateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTreeNodeUpdateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeViewDto")))
@interface SharedKitTreeNodeViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithLabel:(NSString *)label key:(NSString *)key data:(id _Nullable)data template:(NSString * _Nullable)template_ icon:(NSString * _Nullable)icon leaf:(BOOL)leaf children:(NSArray<SharedKitTreeNodeViewDto *> *)children __attribute__((swift_name("init(label:key:data:template:icon:leaf:children:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTreeNodeViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTreeNodeViewDto *)doCopyLabel:(NSString *)label key:(NSString *)key data:(id _Nullable)data template:(NSString * _Nullable)template_ icon:(NSString * _Nullable)icon leaf:(BOOL)leaf children:(NSArray<SharedKitTreeNodeViewDto *> *)children __attribute__((swift_name("doCopy(label:key:data:template:icon:leaf:children:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSArray<SharedKitTreeNodeViewDto *> *children __attribute__((swift_name("children")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/AnySerializer))
*/
@property id _Nullable data __attribute__((swift_name("data")));
@property NSString * _Nullable icon __attribute__((swift_name("icon")));
@property NSString *key __attribute__((swift_name("key")));
@property NSString *label __attribute__((swift_name("label")));
@property BOOL leaf __attribute__((swift_name("leaf")));
@property (getter=template, setter=setTemplate:) NSString * _Nullable template_ __attribute__((swift_name("template_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeViewDto.Companion")))
@interface SharedKitTreeNodeViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTreeNodeViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeViewLazyDto")))
@interface SharedKitTreeNodeViewLazyDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithLabel:(NSString *)label key:(NSString *)key data:(id _Nullable)data template:(NSString * _Nullable)template_ icon:(NSString * _Nullable)icon leaf:(BOOL)leaf __attribute__((swift_name("init(label:key:data:template:icon:leaf:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitTreeNodeViewLazyDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitTreeNodeViewLazyDto *)doCopyLabel:(NSString *)label key:(NSString *)key data:(id _Nullable)data template:(NSString * _Nullable)template_ icon:(NSString * _Nullable)icon leaf:(BOOL)leaf __attribute__((swift_name("doCopy(label:key:data:template:icon:leaf:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));

/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=com/avancee/shared/core/model/AnySerializer))
*/
@property id _Nullable data __attribute__((swift_name("data")));
@property NSString * _Nullable icon __attribute__((swift_name("icon")));
@property NSString *key __attribute__((swift_name("key")));
@property NSString *label __attribute__((swift_name("label")));
@property BOOL leaf __attribute__((swift_name("leaf")));
@property (getter=template, setter=setTemplate:) NSString * _Nullable template_ __attribute__((swift_name("template_")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TreeNodeViewLazyDto.Companion")))
@interface SharedKitTreeNodeViewLazyDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitTreeNodeViewLazyDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaAuthViewDto")))
@interface SharedKitMediaAuthViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithMediaMap:(NSDictionary<NSString *, NSString *> *)mediaMap __attribute__((swift_name("init(mediaMap:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMediaAuthViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMediaAuthViewDto *)doCopyMediaMap:(NSDictionary<NSString *, NSString *> *)mediaMap __attribute__((swift_name("doCopy(mediaMap:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSDictionary<NSString *, NSString *> *mediaMap __attribute__((swift_name("mediaMap")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaAuthViewDto.Companion")))
@interface SharedKitMediaAuthViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMediaAuthViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaViewerCreateDto")))
@interface SharedKitMediaViewerCreateDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithHashes:(NSSet<NSString *> *)hashes __attribute__((swift_name("init(hashes:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitMediaViewerCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitMediaViewerCreateDto *)doCopyHashes:(NSSet<NSString *> *)hashes __attribute__((swift_name("doCopy(hashes:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSSet<NSString *> *hashes __attribute__((swift_name("hashes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MediaViewerCreateDto.Companion")))
@interface SharedKitMediaViewerCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitMediaViewerCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyMessageInternalDto")))
@interface SharedKitPrivacyMessageInternalDto : SharedKitBase

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithAction:(SharedKitPrivacyMessageAction * _Nullable)action source:(NSString * _Nullable)source userId:(SharedKitLong * _Nullable)userId __attribute__((swift_name("init(action:source:userId:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitPrivacyMessageInternalDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitPrivacyMessageInternalDto *)doCopyAction:(SharedKitPrivacyMessageAction * _Nullable)action source:(NSString * _Nullable)source userId:(SharedKitLong * _Nullable)userId __attribute__((swift_name("doCopy(action:source:userId:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property SharedKitPrivacyMessageAction * _Nullable action __attribute__((swift_name("action")));
@property NSString * _Nullable source __attribute__((swift_name("source")));
@property SharedKitLong * _Nullable userId __attribute__((swift_name("userId")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivacyMessageInternalDto.Companion")))
@interface SharedKitPrivacyMessageInternalDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitPrivacyMessageInternalDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("PreferableEntity")))
@protocol SharedKitPreferableEntity
@required
@end

__attribute__((swift_name("Default")))
@protocol SharedKitDefault
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Flag")))
@interface SharedKitFlag : SharedKitKotlinEnum<SharedKitFlag *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (SharedKitKotlinArray<SharedKitFlag *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((swift_name("Payload")))
@protocol SharedKitPayload
@required
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Greeting")))
@interface SharedKitGreeting : SharedKitBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)greet __attribute__((swift_name("greet()")));
@end

__attribute__((swift_name("Platform")))
@protocol SharedKitPlatform
@required
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PushMessageType_")))
@interface SharedKitPushMessageType_ : SharedKitKotlinEnum<SharedKitPushMessageType_ *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitPushMessageType_ *mediaBackgroundProcessing __attribute__((swift_name("mediaBackgroundProcessing")));
@property (class, readonly) SharedKitPushMessageType_ *welcome __attribute__((swift_name("welcome")));
@property (class, readonly) SharedKitPushMessageType_ *genericAlert __attribute__((swift_name("genericAlert")));
@property (class, readonly) SharedKitPushMessageType_ *genericSilent __attribute__((swift_name("genericSilent")));
@property (class, readonly) SharedKitPushMessageType_ *userNotificationCenterUpdate __attribute__((swift_name("userNotificationCenterUpdate")));
@property (class, readonly) SharedKitPushMessageType_ *socialUserCreate __attribute__((swift_name("socialUserCreate")));
@property (class, readonly) SharedKitPushMessageType_ *friendRequest __attribute__((swift_name("friendRequest")));
@property (class, readonly) SharedKitPushMessageType_ *groupJoinRequest __attribute__((swift_name("groupJoinRequest")));
@property (class, readonly) SharedKitPushMessageType_ *groupJoinInvite __attribute__((swift_name("groupJoinInvite")));
@property (class, readonly) SharedKitPushMessageType_ *acceptedFriendRequest __attribute__((swift_name("acceptedFriendRequest")));
@property (class, readonly) SharedKitPushMessageType_ *acceptedJoinRequest __attribute__((swift_name("acceptedJoinRequest")));
@property (class, readonly) SharedKitPushMessageType_ *acceptedJoinInvite __attribute__((swift_name("acceptedJoinInvite")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupManagerRoleGranted __attribute__((swift_name("socialGroupManagerRoleGranted")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupManagerRoleRemoved __attribute__((swift_name("socialGroupManagerRoleRemoved")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupMembershipRemoved __attribute__((swift_name("socialGroupMembershipRemoved")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupCreated __attribute__((swift_name("socialGroupCreated")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupCoverEdit __attribute__((swift_name("socialGroupCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *socialGroupAvatarEdit __attribute__((swift_name("socialGroupAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType_ *postCreated __attribute__((swift_name("postCreated")));
@property (class, readonly) SharedKitPushMessageType_ *postAddMedia __attribute__((swift_name("postAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *eventCreated __attribute__((swift_name("eventCreated")));
@property (class, readonly) SharedKitPushMessageType_ *eventAddMedia __attribute__((swift_name("eventAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *eventCoverEdit __attribute__((swift_name("eventCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *eventScheduleReminder __attribute__((swift_name("eventScheduleReminder")));
@property (class, readonly) SharedKitPushMessageType_ *chatRoomChange __attribute__((swift_name("chatRoomChange")));
@property (class, readonly) SharedKitPushMessageType_ *chatRoomRemove __attribute__((swift_name("chatRoomRemove")));
@property (class, readonly) SharedKitPushMessageType_ *chatBoardChange __attribute__((swift_name("chatBoardChange")));
@property (class, readonly) SharedKitPushMessageType_ *chatMeetingCreated __attribute__((swift_name("chatMeetingCreated")));
@property (class, readonly) SharedKitPushMessageType_ *chatMeetingCreationError __attribute__((swift_name("chatMeetingCreationError")));
@property (class, readonly) SharedKitPushMessageType_ *chatMessagePublished __attribute__((swift_name("chatMessagePublished")));
@property (class, readonly) SharedKitPushMessageType_ *chatWebrtcMessagePublished __attribute__((swift_name("chatWebrtcMessagePublished")));
@property (class, readonly) SharedKitPushMessageType_ *chatStatusMessagePublished __attribute__((swift_name("chatStatusMessagePublished")));
@property (class, readonly) SharedKitPushMessageType_ *cctvAiEvent __attribute__((swift_name("cctvAiEvent")));
@property (class, readonly) SharedKitPushMessageType_ *cctvLicensePlateEvent __attribute__((swift_name("cctvLicensePlateEvent")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsOrganizationCreated __attribute__((swift_name("organizationsOrganizationCreated")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsOrganizationLogoEdit __attribute__((swift_name("organizationsOrganizationLogoEdit")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsOrganizationCoverEdit __attribute__((swift_name("organizationsOrganizationCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsOrganizationNewMedia __attribute__((swift_name("organizationsOrganizationNewMedia")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsResponsiblePersonCreate __attribute__((swift_name("organizationsResponsiblePersonCreate")));
@property (class, readonly) SharedKitPushMessageType_ *organizationsResponsiblePersonPictureUpdate __attribute__((swift_name("organizationsResponsiblePersonPictureUpdate")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSocialProfileUpdate __attribute__((swift_name("profilesSocialProfileUpdate")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSocialProfileAvatarEdit __attribute__((swift_name("profilesSocialProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSocialProfileCoverEdit __attribute__((swift_name("profilesSocialProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSocialProfileAddMedia __attribute__((swift_name("profilesSocialProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *profilesPoliticalProfileCreate __attribute__((swift_name("profilesPoliticalProfileCreate")));
@property (class, readonly) SharedKitPushMessageType_ *profilesPoliticalProfileAvatarEdit __attribute__((swift_name("profilesPoliticalProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesPoliticalProfileCoverEdit __attribute__((swift_name("profilesPoliticalProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesPoliticalProfileAddMedia __attribute__((swift_name("profilesPoliticalProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *profilesProfessionalProfileCreate __attribute__((swift_name("profilesProfessionalProfileCreate")));
@property (class, readonly) SharedKitPushMessageType_ *profilesProfessionalProfileAvatarEdit __attribute__((swift_name("profilesProfessionalProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesProfessionalProfileCoverEdit __attribute__((swift_name("profilesProfessionalProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesProfessionalProfileAddMedia __attribute__((swift_name("profilesProfessionalProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSharedProfileCreate __attribute__((swift_name("profilesSharedProfileCreate")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSharedProfileAvatarEdit __attribute__((swift_name("profilesSharedProfileAvatarEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSharedProfileCoverEdit __attribute__((swift_name("profilesSharedProfileCoverEdit")));
@property (class, readonly) SharedKitPushMessageType_ *profilesSharedProfileAddMedia __attribute__((swift_name("profilesSharedProfileAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *iotStateUpdateEvent __attribute__((swift_name("iotStateUpdateEvent")));
@property (class, readonly) SharedKitPushMessageType_ *iotMacroTriggeredEvent __attribute__((swift_name("iotMacroTriggeredEvent")));
@property (class, readonly) SharedKitPushMessageType_ *iotPropertyTriggeredEvent __attribute__((swift_name("iotPropertyTriggeredEvent")));
@property (class, readonly) SharedKitPushMessageType_ *iotCreateFirmwareVersion __attribute__((swift_name("iotCreateFirmwareVersion")));
@property (class, readonly) SharedKitPushMessageType_ *iotZoneCreate __attribute__((swift_name("iotZoneCreate")));
@property (class, readonly) SharedKitPushMessageType_ *iotZoneUploadMedias __attribute__((swift_name("iotZoneUploadMedias")));
@property (class, readonly) SharedKitPushMessageType_ *iotUserGroupCreate __attribute__((swift_name("iotUserGroupCreate")));
@property (class, readonly) SharedKitPushMessageType_ *iotUserGroupUploadMedia __attribute__((swift_name("iotUserGroupUploadMedia")));
@property (class, readonly) SharedKitPushMessageType_ *cameraStreamReady __attribute__((swift_name("cameraStreamReady")));
@property (class, readonly) SharedKitPushMessageType_ *cameraActionResponse __attribute__((swift_name("cameraActionResponse")));
@property (class, readonly) SharedKitPushMessageType_ *cctvAi __attribute__((swift_name("cctvAi")));
@property (class, readonly) SharedKitPushMessageType_ *cctvLicensePlate __attribute__((swift_name("cctvLicensePlate")));
@property (class, readonly) SharedKitPushMessageType_ *documentMediaReady __attribute__((swift_name("documentMediaReady")));
@property (class, readonly) SharedKitPushMessageType_ *legalDocumentCreate __attribute__((swift_name("legalDocumentCreate")));
@property (class, readonly) SharedKitPushMessageType_ *legalDocumentAddDocument __attribute__((swift_name("legalDocumentAddDocument")));
@property (class, readonly) SharedKitPushMessageType_ *ticketingCreate __attribute__((swift_name("ticketingCreate")));
@property (class, readonly) SharedKitPushMessageType_ *ticketingAddMedia __attribute__((swift_name("ticketingAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *ticketingCommentCreate __attribute__((swift_name("ticketingCommentCreate")));
@property (class, readonly) SharedKitPushMessageType_ *sharedSpacesBuildingCreate __attribute__((swift_name("sharedSpacesBuildingCreate")));
@property (class, readonly) SharedKitPushMessageType_ *sharedSpacesBuildingAddMedia __attribute__((swift_name("sharedSpacesBuildingAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *sharedSpacesSpaceCreate __attribute__((swift_name("sharedSpacesSpaceCreate")));
@property (class, readonly) SharedKitPushMessageType_ *sharedSpacesSpaceAddMedia __attribute__((swift_name("sharedSpacesSpaceAddMedia")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsCreated __attribute__((swift_name("subscriptionsCreated")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsEnded __attribute__((swift_name("subscriptionsEnded")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsPlanCanceled __attribute__((swift_name("subscriptionsPlanCanceled")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsPaymentFailure __attribute__((swift_name("subscriptionsPaymentFailure")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsIncomingPayment __attribute__((swift_name("subscriptionsIncomingPayment")));
@property (class, readonly) SharedKitPushMessageType_ *subscriptionsImpendingCancellation __attribute__((swift_name("subscriptionsImpendingCancellation")));
@property (class, readonly) SharedKitPushMessageType_ *genericAll __attribute__((swift_name("genericAll")));
@property (class, readonly) SharedKitPushMessageType_ *genericMetrics __attribute__((swift_name("genericMetrics")));
@property (class, readonly) SharedKitPushMessageType_ *genericState __attribute__((swift_name("genericState")));
+ (SharedKitKotlinArray<SharedKitPushMessageType_ *> *)values __attribute__((swift_name("values()")));
@property (readonly) BOOL persistable __attribute__((swift_name("persistable")));
@property (readonly) SharedKitPushMessageSeverity *severity __attribute__((swift_name("severity")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("WhatchOSPlatform")))
@interface SharedKitWhatchOSPlatform : SharedKitBase <SharedKitPlatform>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("MeetingMessageDtoKt")))
@interface SharedKitMeetingMessageDtoKt : SharedKitBase
@property (class, readonly) SharedKitKotlinx_serialization_jsonJson *json __attribute__((swift_name("json")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ExtensionsKt")))
@interface SharedKitExtensionsKt : SharedKitBase
+ (NSString *)toJson:(id _Nullable)receiver serializer:(id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("toJson(_:serializer:)")));
@property (class, readonly) SharedKitKotlinx_serialization_jsonJson *nonStrictJson __attribute__((swift_name("nonStrictJson")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformDateKt")))
@interface SharedKitPlatformDateKt : SharedKitBase
+ (SharedKitKotlinx_datetimeLocalDate *)parseDateValue:(NSString *)value __attribute__((swift_name("parseDate(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformHourKt")))
@interface SharedKitPlatformHourKt : SharedKitBase
+ (SharedKitKotlinx_datetimeInstant *)parseHourValue:(NSString *)value __attribute__((swift_name("parseHour(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformTimeKt")))
@interface SharedKitPlatformTimeKt : SharedKitBase
+ (SharedKitKotlinx_datetimeInstant *)parseTimeValue:(NSString *)value __attribute__((swift_name("parseTime(value:)")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformKt")))
@interface SharedKitPlatformKt : SharedKitBase
+ (id<SharedKitPlatform>)getPlatform __attribute__((swift_name("getPlatform()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Common_dto_mediaPendingMediaResourceCreateDto")))
@interface SharedKitCommon_dto_mediaPendingMediaResourceCreateDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithMediaProfile:(NSString * _Nullable)mediaProfile hash:(NSString * _Nullable)hash __attribute__((swift_name("init(mediaProfile:hash:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitCommon_dto_mediaPendingMediaResourceCreateDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitCommon_dto_mediaPendingMediaResourceCreateDto *)doCopyMediaProfile:(NSString * _Nullable)mediaProfile hash:(NSString * _Nullable)hash __attribute__((swift_name("doCopy(mediaProfile:hash:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (getter=hash_) NSString * _Nullable hash __attribute__((swift_name("hash")));
@property NSString * _Nullable mediaProfile __attribute__((swift_name("mediaProfile")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface SharedKitKotlinEnumCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SharedKitKotlinArray<T> : SharedKitBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SharedKitInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SharedKitKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Common_dto_mediaMediaResourceViewDto")))
@interface SharedKitCommon_dto_mediaMediaResourceViewDto : SharedKitBase <SharedKitParcelable>

/**
 * @note annotations
 *   kotlin.jvm.JvmOverloads
*/
- (instancetype)initWithOriginalFilename:(NSString * _Nullable)originalFilename filename:(NSString * _Nullable)filename url:(NSString * _Nullable)url contentType:(NSString * _Nullable)contentType groupOrder:(SharedKitInt * _Nullable)groupOrder dominantColor:(NSString * _Nullable)dominantColor metadata:(NSArray<SharedKitNameValuePairDto *> * _Nullable)metadata mediaProfile:(NSString * _Nullable)mediaProfile pending:(BOOL)pending uploadUrl:(NSString * _Nullable)uploadUrl thumbnails:(SharedKitBoolean * _Nullable)thumbnails visibility:(SharedKitMediaVisibility * _Nullable)visibility orientation:(SharedKitMediaOrientation * _Nullable)orientation size:(SharedKitLong * _Nullable)size __attribute__((swift_name("init(originalFilename:filename:url:contentType:groupOrder:dominantColor:metadata:mediaProfile:pending:uploadUrl:thumbnails:visibility:orientation:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitCommon_dto_mediaMediaResourceViewDtoCompanion *companion __attribute__((swift_name("companion")));
- (SharedKitCommon_dto_mediaMediaResourceViewDto *)doCopyOriginalFilename:(NSString * _Nullable)originalFilename filename:(NSString * _Nullable)filename url:(NSString * _Nullable)url contentType:(NSString * _Nullable)contentType groupOrder:(SharedKitInt * _Nullable)groupOrder dominantColor:(NSString * _Nullable)dominantColor metadata:(NSArray<SharedKitNameValuePairDto *> * _Nullable)metadata mediaProfile:(NSString * _Nullable)mediaProfile pending:(BOOL)pending uploadUrl:(NSString * _Nullable)uploadUrl thumbnails:(SharedKitBoolean * _Nullable)thumbnails visibility:(SharedKitMediaVisibility * _Nullable)visibility orientation:(SharedKitMediaOrientation * _Nullable)orientation size:(SharedKitLong * _Nullable)size __attribute__((swift_name("doCopy(originalFilename:filename:url:contentType:groupOrder:dominantColor:metadata:mediaProfile:pending:uploadUrl:thumbnails:visibility:orientation:size:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable contentType __attribute__((swift_name("contentType")));
@property NSString * _Nullable dominantColor __attribute__((swift_name("dominantColor")));
@property NSString * _Nullable filename __attribute__((swift_name("filename")));
@property SharedKitInt * _Nullable groupOrder __attribute__((swift_name("groupOrder")));
@property NSString * _Nullable mediaProfile __attribute__((swift_name("mediaProfile")));
@property NSArray<SharedKitNameValuePairDto *> * _Nullable metadata __attribute__((swift_name("metadata")));
@property SharedKitMediaOrientation * _Nullable orientation __attribute__((swift_name("orientation")));
@property NSString * _Nullable originalFilename __attribute__((swift_name("originalFilename")));
@property BOOL pending __attribute__((swift_name("pending")));
@property SharedKitLong * _Nullable size __attribute__((swift_name("size")));
@property SharedKitBoolean * _Nullable thumbnails __attribute__((swift_name("thumbnails")));
@property NSString * _Nullable uploadUrl __attribute__((swift_name("uploadUrl")));
@property NSString * _Nullable url __attribute__((swift_name("url")));
@property SharedKitMediaVisibility * _Nullable visibility __attribute__((swift_name("visibility")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/InstantIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeInstant")))
@interface SharedKitKotlinx_datetimeInstant : SharedKitBase <SharedKitKotlinComparable>
@property (class, readonly, getter=companion) SharedKitKotlinx_datetimeInstantCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(SharedKitKotlinx_datetimeInstant *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (SharedKitKotlinx_datetimeInstant *)minusDuration:(int64_t)duration __attribute__((swift_name("minus(duration:)")));
- (int64_t)minusOther:(SharedKitKotlinx_datetimeInstant *)other __attribute__((swift_name("minus(other:)")));
- (SharedKitKotlinx_datetimeInstant *)plusDuration:(int64_t)duration __attribute__((swift_name("plus(duration:)")));
- (int64_t)toEpochMilliseconds __attribute__((swift_name("toEpochMilliseconds()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t epochSeconds __attribute__((swift_name("epochSeconds")));
@property (readonly) int32_t nanosecondsOfSecond __attribute__((swift_name("nanosecondsOfSecond")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol SharedKitKotlinx_serialization_coreEncoder
@required
- (id<SharedKitKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<SharedKitKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<SharedKitKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol SharedKitKotlinx_serialization_coreSerialDescriptor
@required

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSArray<id<SharedKitKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKitKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSArray<id<SharedKitKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) SharedKitKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol SharedKitKotlinx_serialization_coreDecoder
@required
- (id<SharedKitKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<SharedKitKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (SharedKitKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/datetime/serializers/LocalDateIso8601Serializer))
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate")))
@interface SharedKitKotlinx_datetimeLocalDate : SharedKitBase <SharedKitKotlinComparable>
- (instancetype)initWithYear:(int32_t)year month:(SharedKitKotlinx_datetimeMonth *)month dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:month:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithYear:(int32_t)year monthNumber:(int32_t)monthNumber dayOfMonth:(int32_t)dayOfMonth __attribute__((swift_name("init(year:monthNumber:dayOfMonth:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedKitKotlinx_datetimeLocalDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(SharedKitKotlinx_datetimeLocalDate *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (int32_t)toEpochDays __attribute__((swift_name("toEpochDays()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) SharedKitKotlinx_datetimeDayOfWeek *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) SharedKitKotlinx_datetimeMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t monthNumber __attribute__((swift_name("monthNumber")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UuidUuid")))
@interface SharedKitUuidUuid : SharedKitBase <SharedKitKotlinComparable>
- (instancetype)initWithMsb:(int64_t)msb lsb:(int64_t)lsb __attribute__((swift_name("init(msb:lsb:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithUuidBytes:(SharedKitKotlinByteArray *)uuidBytes __attribute__((swift_name("init(uuidBytes:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use `uuidOf` instead.")));
- (int32_t)compareToOther:(SharedKitUuidUuid *)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int64_t leastSignificantBits __attribute__((swift_name("leastSignificantBits")));
@property (readonly) int64_t mostSignificantBits __attribute__((swift_name("mostSignificantBits")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol SharedKitKotlinx_serialization_coreSerialFormat
@required
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol SharedKitKotlinx_serialization_coreStringFormat <SharedKitKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface SharedKitKotlinx_serialization_jsonJson : SharedKitBase <SharedKitKotlinx_serialization_coreStringFormat>
@property (class, readonly, getter=companion) SharedKitKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(SharedKitKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (SharedKitKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringSerializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (SharedKitKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) SharedKitKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Common_dto_mediaPendingMediaResourceCreateDto.Companion")))
@interface SharedKitCommon_dto_mediaPendingMediaResourceCreateDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitCommon_dto_mediaPendingMediaResourceCreateDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SharedKitKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Common_dto_mediaMediaResourceViewDto.Companion")))
@interface SharedKitCommon_dto_mediaMediaResourceViewDtoCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitCommon_dto_mediaMediaResourceViewDtoCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeInstant.Companion")))
@interface SharedKitKotlinx_datetimeInstantCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitKotlinx_datetimeInstantCompanion *shared __attribute__((swift_name("shared")));
- (SharedKitKotlinx_datetimeInstant *)fromEpochMillisecondsEpochMilliseconds:(int64_t)epochMilliseconds __attribute__((swift_name("fromEpochMilliseconds(epochMilliseconds:)")));
- (SharedKitKotlinx_datetimeInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment:(int32_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment:)")));
- (SharedKitKotlinx_datetimeInstant *)fromEpochSecondsEpochSeconds:(int64_t)epochSeconds nanosecondAdjustment_:(int64_t)nanosecondAdjustment __attribute__((swift_name("fromEpochSeconds(epochSeconds:nanosecondAdjustment_:)")));
- (SharedKitKotlinx_datetimeInstant *)now __attribute__((swift_name("now()"))) __attribute__((unavailable("Use Clock.System.now() instead")));
- (SharedKitKotlinx_datetimeInstant *)parseIsoString:(NSString *)isoString __attribute__((swift_name("parse(isoString:)")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly) SharedKitKotlinx_datetimeInstant *DISTANT_FUTURE __attribute__((swift_name("DISTANT_FUTURE")));
@property (readonly) SharedKitKotlinx_datetimeInstant *DISTANT_PAST __attribute__((swift_name("DISTANT_PAST")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol SharedKitKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<SharedKitKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedKitKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface SharedKitKotlinx_serialization_coreSerializersModule : SharedKitBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<SharedKitKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKitKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<SharedKitKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<SharedKitKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKitKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SharedKitKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKitKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SharedKitKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol SharedKitKotlinAnnotation
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface SharedKitKotlinx_serialization_coreSerialKind : SharedKitBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol SharedKitKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<SharedKitKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<SharedKitKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) SharedKitKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface SharedKitKotlinNothing : SharedKitBase
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeMonth")))
@interface SharedKitKotlinx_datetimeMonth : SharedKitKotlinEnum<SharedKitKotlinx_datetimeMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *january __attribute__((swift_name("january")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *february __attribute__((swift_name("february")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *march __attribute__((swift_name("march")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *april __attribute__((swift_name("april")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *may __attribute__((swift_name("may")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *june __attribute__((swift_name("june")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *july __attribute__((swift_name("july")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *august __attribute__((swift_name("august")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *september __attribute__((swift_name("september")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *october __attribute__((swift_name("october")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *november __attribute__((swift_name("november")));
@property (class, readonly) SharedKitKotlinx_datetimeMonth *december __attribute__((swift_name("december")));
+ (SharedKitKotlinArray<SharedKitKotlinx_datetimeMonth *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeLocalDate.Companion")))
@interface SharedKitKotlinx_datetimeLocalDateCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitKotlinx_datetimeLocalDateCompanion *shared __attribute__((swift_name("shared")));
- (SharedKitKotlinx_datetimeLocalDate *)fromEpochDaysEpochDays:(int32_t)epochDays __attribute__((swift_name("fromEpochDays(epochDays:)")));
- (SharedKitKotlinx_datetimeLocalDate *)parseIsoString:(NSString *)isoString __attribute__((swift_name("parse(isoString:)")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_datetimeDayOfWeek")))
@interface SharedKitKotlinx_datetimeDayOfWeek : SharedKitKotlinEnum<SharedKitKotlinx_datetimeDayOfWeek *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *monday __attribute__((swift_name("monday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *friday __attribute__((swift_name("friday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) SharedKitKotlinx_datetimeDayOfWeek *sunday __attribute__((swift_name("sunday")));
+ (SharedKitKotlinArray<SharedKitKotlinx_datetimeDayOfWeek *> *)values __attribute__((swift_name("values()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface SharedKitKotlinByteArray : SharedKitBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(SharedKitByte *(^)(SharedKitInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (SharedKitKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface SharedKitKotlinx_serialization_jsonJsonDefault : SharedKitKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface SharedKitKotlinx_serialization_jsonJsonElement : SharedKitBase
@property (class, readonly, getter=companion) SharedKitKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface SharedKitKotlinx_serialization_jsonJsonConfiguration : SharedKitBase
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) BOOL explicitNulls __attribute__((swift_name("explicitNulls")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol SharedKitKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<SharedKitKotlinKClass>)kClass provider:(id<SharedKitKotlinx_serialization_coreKSerializer> (^)(NSArray<id<SharedKitKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<SharedKitKotlinKClass>)kClass serializer:(id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<SharedKitKotlinKClass>)baseClass actualClass:(id<SharedKitKotlinKClass>)actualClass actualSerializer:(id<SharedKitKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<SharedKitKotlinKClass>)baseClass defaultDeserializerProvider:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)polymorphicDefaultDeserializerBaseClass:(id<SharedKitKotlinKClass>)baseClass defaultDeserializerProvider:(id<SharedKitKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)polymorphicDefaultSerializerBaseClass:(id<SharedKitKotlinKClass>)baseClass defaultSerializerProvider:(id<SharedKitKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol SharedKitKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol SharedKitKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol SharedKitKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol SharedKitKotlinKClass <SharedKitKotlinKDeclarationContainer, SharedKitKotlinKAnnotatedElement, SharedKitKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

__attribute__((swift_name("KotlinByteIterator")))
@interface SharedKitKotlinByteIterator : SharedKitBase <SharedKitKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (SharedKitByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface SharedKitKotlinx_serialization_jsonJsonElementCompanion : SharedKitBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKitKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKitKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
